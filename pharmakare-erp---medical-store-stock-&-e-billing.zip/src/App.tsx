import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Package,
  PlusCircle,
  FileSpreadsheet,
  Receipt,
  History,
  Database,
  Search,
  Printer,
  Download,
  Upload,
  Trash2,
  Edit3,
  Copy,
  Plus,
  CheckCircle2,
  X,
  Calendar,
  AlertTriangle,
  ArrowRight,
  TrendingUp,
  RotateCcw,
  ShieldCheck,
  Activity,
  Command,
  CornerDownLeft
} from 'lucide-react';

interface StockItem {
  id: string;
  name: string;
  company: string;
  batch: string;
  expiry: string;
  packing?: string;
  cost: number;
  mrp: number;
  qty: number;
  unit: string;
}

interface BillItem {
  name: string;
  qty: number;
  rate: number;
  packing: string;
  batch: string;
  expiry: string;
  mrp?: number;
  amount: number;
}

interface PurchaseBill {
  id: string;
  date: string;
  firm: string;
  bill: string;
  paid: number;
  notes: string;
  items: BillItem[];
  total: number;
}

interface SalesInvoice {
  id: string;
  date: string;
  customer: string;
  bill: string;
  doctor: string;
  address: string;
  items: BillItem[];
  total: number;
}

interface DatabaseState {
  stock: StockItem[];
  purchases: PurchaseBill[];
  sales: SalesInvoice[];
}

interface LocalBackup {
  at: string;
  data: DatabaseState;
}

const BACKUP_KEY = 'pdsharma_local_backups_v1';
const BACKUP_REMINDER_KEY = 'pdsharma_last_download_v1';
const LAST_SAVE_KEY = 'pdsharma_last_save_v1';
const DB_KEY = 'pdsharma_db';

const today = () => new Date().toLocaleDateString('en-CA');
const money = (n: number | string) =>
  (Number(n) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

const parseQty = (value: string): number => {
  const v = String(value || '')
    .trim()
    .replace(/[×xX]/g, '*')
    .replace(/\s+/g, '');
  if (!v) return NaN;
  const parts = v.split('*');
  if (parts.some(p => p === '' || !/^\d+(?:\.\d+)?$/.test(p))) return NaN;
  return parts.reduce((n, p) => n * Number(p), 1);
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'stock' | 'purchase' | 'purchases' | 'sale' | 'sales' | 'backup'>('home');

  // Core database state
  const [db, setDb] = useState<DatabaseState>(() => {
    try {
      const raw = localStorage.getItem(DB_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          stock: Array.isArray(parsed.stock) ? parsed.stock.map((s: any) => ({ ...s, id: s.id || uid() })) : [],
          purchases: Array.isArray(parsed.purchases) ? parsed.purchases.map((p: any) => ({ ...p, id: p.id || uid() })) : [],
          sales: Array.isArray(parsed.sales) ? parsed.sales.map((s: any) => ({ ...s, id: s.id || uid() })) : []
        };
      }
    } catch (e) {
      console.warn('Error loading local DB', e);
    }
    return { stock: [], purchases: [], sales: [] };
  });

  // Global Command Palette & Quick Search (Ctrl+K)
  const [isCommandOpen, setIsCommandOpen] = useState(false);
  const [commandQuery, setCommandQuery] = useState('');
  const [commandSelectedIndex, setCommandSelectedIndex] = useState(0);
  const commandInputRef = React.useRef<HTMLInputElement>(null);

  // Local backups
  const [localBackups, setLocalBackups] = useState<LocalBackup[]>(() => {
    try {
      return JSON.parse(localStorage.getItem(BACKUP_KEY) || '[]');
    } catch {
      return [];
    }
  });

  const [lastSaveTime, setLastSaveTime] = useState<string>(() => localStorage.getItem(LAST_SAVE_KEY) || '');
  const [backupReminderDays, setBackupReminderDays] = useState<number>(() => {
    const d = Number(localStorage.getItem(BACKUP_REMINDER_KEY) || 0);
    return d ? Math.floor((Date.now() - d) / 86400000) : 999;
  });

  // Stock search
  const [stockSearch, setStockSearch] = useState('');

  // Purchase Form State
  const [pDate, setPDate] = useState(today());
  const [pFirm, setPFirm] = useState('');
  const [pBill, setPBill] = useState('');
  const [pPaid, setPPaid] = useState<string>('0');
  const [pNotes, setPNotes] = useState('');
  const [editingPurchaseId, setEditingPurchaseId] = useState<string | null>(null);

  interface PurchaseItemInput {
    id: string;
    name: string;
    qty: string;
    packing: string;
    rate: string;
    mrp: string;
    batch: string;
    expiry: string;
  }

  const [purchaseRows, setPurchaseRows] = useState<PurchaseItemInput[]>([
    { id: uid(), name: '', qty: '1', packing: '', rate: '', mrp: '', batch: '', expiry: '' }
  ]);

  // Purchase Register Filter State
  const [purchaseFrom, setPurchaseFrom] = useState('');
  const [purchaseTo, setPurchaseTo] = useState('');
  const [purchaseSearch, setPurchaseSearch] = useState('');

  // Sales Form State
  const [saleDate, setSaleDate] = useState(today());
  const [saleCustomer, setSaleCustomer] = useState('');
  const [saleBill, setSaleBill] = useState('');
  const [saleDoctor, setSaleDoctor] = useState('');
  const [saleAddress, setSaleAddress] = useState('');
  const [editingSaleId, setEditingSaleId] = useState<string | null>(null);

  interface SaleItemInput {
    id: string;
    name: string;
    qty: string;
    packing: string;
    rate: string;
    batch: string;
    expiry: string;
  }

  const [saleRows, setSaleRows] = useState<SaleItemInput[]>([
    { id: uid(), name: '', qty: '1', packing: '', rate: '', batch: '', expiry: '' }
  ]);

  // Sales Register Filter State & Multi-select
  const [salesFrom, setSalesFrom] = useState('');
  const [salesTo, setSalesTo] = useState('');
  const [salesSearch, setSalesSearch] = useState('');
  const [selectedSalesItems, setSelectedSalesItems] = useState<Set<string>>(new Set());

  // Cloud sync status message
  const [cloudEmail, setCloudEmail] = useState('');
  const [cloudPassword, setCloudPassword] = useState('');
  const [cloudStatus, setCloudStatus] = useState('Cloud sync ready for pd-sharma-medical-store.');

  // In-app Printable Modal (resilient for iframe previews & direct printing)
  const [printModalContent, setPrintModalContent] = useState<{
    type: 'sale' | 'purchase';
    title: string;
    html: string;
  } | null>(null);

  const [selectedBackupIndex, setSelectedBackupIndex] = useState<string>('');

  // Persistence Helper with automatic snapshot
  const saveDbWithSnapshot = (newDb: DatabaseState) => {
    try {
      const rawCurrent = localStorage.getItem(DB_KEY);
      if (rawCurrent) {
        const list: LocalBackup[] = JSON.parse(localStorage.getItem(BACKUP_KEY) || '[]');
        list.unshift({ at: new Date().toISOString(), data: JSON.parse(rawCurrent) });
        while (list.length > 5) list.pop();
        let packed = JSON.stringify(list);
        while (list.length > 1 && packed.length > 1000000) {
          list.pop();
          packed = JSON.stringify(list);
        }
        if (packed.length <= 1000000) {
          localStorage.setItem(BACKUP_KEY, packed);
          setLocalBackups(list);
        }
      }

      const nextRaw = JSON.stringify(newDb);
      localStorage.setItem(DB_KEY, nextRaw);
      const nowStr = new Date().toISOString();
      localStorage.setItem(LAST_SAVE_KEY, nowStr);
      setLastSaveTime(nowStr);
      setDb(newDb);
    } catch (e) {
      alert('Could not save data. Free device storage and try again.');
      throw e;
    }
  };

  // Focus command input when opened
  useEffect(() => {
    if (isCommandOpen) {
      setTimeout(() => commandInputRef.current?.focus(), 50);
    }
  }, [isCommandOpen]);

  // Global Keyboard shortcuts (Ctrl+K for Command Palette, Esc to close, Ctrl+Enter to submit forms)
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setIsCommandOpen(prev => !prev);
        setCommandQuery('');
        setCommandSelectedIndex(0);
        return;
      }

      if (e.key === 'Escape' && isCommandOpen) {
        e.preventDefault();
        setIsCommandOpen(false);
        return;
      }

      if (!isCommandOpen && (e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        if (activeTab === 'purchase') {
          handleSavePurchase();
        } else if (activeTab === 'sale') {
          handleSaveSale();
        }
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [isCommandOpen, activeTab, purchaseRows, saleRows, pDate, pFirm, pBill, pPaid, pNotes, saleDate, saleCustomer, saleBill, saleDoctor, saleAddress, db]);

  // Check backup reminder on mount
  useEffect(() => {
    const downloaded = Number(localStorage.getItem(BACKUP_REMINDER_KEY) || 0);
    if (!downloaded || Date.now() - downloaded > 7 * 86400000) {
      setBackupReminderDays(downloaded ? Math.floor((Date.now() - downloaded) / 86400000) : 999);
    }
  }, []);

  // Helpers for Stock matching
  const stockPurchaseKey = (i: { name?: string; batch?: string; expiry?: string }) =>
    [String(i.name || '').trim().toLowerCase(), String(i.batch || '').trim(), String(i.expiry || '').trim()].join('|');

  const purchasesForStock = (stock: StockItem) =>
    db.purchases.filter(p => (p.items || []).some(i => stockPurchaseKey(i) === stockPurchaseKey(stock)));

  // -------------------------------------------------------------
  // PURCHASE FORM ACTIONS
  // -------------------------------------------------------------
  const handleAddPurchaseRow = () => {
    setPurchaseRows(prev => [
      ...prev,
      { id: uid(), name: '', qty: '1', packing: '', rate: '', mrp: '', batch: '', expiry: '' }
    ]);
  };

  const handleRemovePurchaseRow = (id: string) => {
    if (purchaseRows.length > 1) {
      setPurchaseRows(prev => prev.filter(r => r.id !== id));
    }
  };

  const handlePurchaseItemChange = (id: string, field: keyof PurchaseItemInput, value: string) => {
    setPurchaseRows(prev =>
      prev.map(r => {
        if (r.id !== id) return r;
        const updated = { ...r, [field]: value };

        // If name changes, autofill from existing stock if available
        if (field === 'name') {
          const matches = db.stock.filter(x => x.name.toLowerCase() === value.trim().toLowerCase());
          if (matches.length > 0) {
            const s = matches[0];
            if (!updated.batch) updated.batch = s.batch || '';
            if (!updated.expiry) updated.expiry = s.expiry || '';
            if (!updated.packing) updated.packing = s.packing || '';
            if (!Number(updated.rate)) updated.rate = s.cost ? String(s.cost) : '';
            if (!Number(updated.mrp)) updated.mrp = s.mrp ? String(s.mrp) : '';
          }
        }
        return updated;
      })
    );
  };

  const purchaseCalculatedItems = purchaseRows.map(r => {
    const qty = parseQty(r.qty);
    const rate = r.rate.trim() === '' ? 0 : Number(r.rate) || 0;
    const mrp = Number(r.mrp) || 0;
    const amount = (isNaN(qty) ? 0 : qty) * rate;
    return {
      name: r.name.trim(),
      qty,
      rate,
      packing: r.packing.trim(),
      batch: r.batch.trim(),
      expiry: r.expiry.trim(),
      mrp,
      amount
    };
  });

  const purchaseTotal = purchaseCalculatedItems.reduce((s, x) => s + (x.amount || 0), 0);

  const handleSavePurchase = () => {
    const items = purchaseCalculatedItems;
    if (!items.length) {
      alert('Please add at least one item to the purchase bill.');
      return;
    }

    if (items.some(i => !i.name || !Number.isFinite(i.qty) || i.qty <= 0 || !i.batch || !i.expiry)) {
      alert('Please fill in Item Name, Quantity, Batch, and Expiry date for all purchase items.');
      return;
    }

    const old = editingPurchaseId ? db.purchases.find(x => x.id === editingPurchaseId) : null;
    if (editingPurchaseId && !old) {
      alert('The purchase bill being edited could not be found.');
      return;
    }

    const purchaseBill = pBill.trim();
    if (
      purchaseBill &&
      db.purchases.some(
        x =>
          x.bill === purchaseBill &&
          String(x.firm || '').toLowerCase() === pFirm.trim().toLowerCase() &&
          (!old || x.id !== old.id)
      )
    ) {
      alert('A purchase bill with this supplier and bill number already exists.');
      return;
    }

    const total = items.reduce((n, i) => n + i.amount, 0);
    const p: PurchaseBill = {
      id: old ? old.id : uid(),
      date: pDate,
      firm: pFirm.trim(),
      bill: purchaseBill,
      paid: Number(pPaid) || 0,
      notes: pNotes.trim(),
      items: items.map(i => ({
        ...i,
        mrp: i.mrp > 0 ? i.mrp : (i.rate > 0 ? i.rate : 0)
      })),
      total
    };

    const key = (i: { name?: string; batch?: string; expiry?: string }) =>
      [String(i.name || '').trim().toLowerCase(), String(i.batch || '').trim(), String(i.expiry || '').trim()].join('|');

    // Build fresh updated stock array
    const newStock = db.stock.map(s => ({ ...s }));

    // Calculate net stock change
    const changes = new Map<string, { item: BillItem; delta: number }>();
    if (old && Array.isArray(old.items)) {
      old.items.forEach(i => {
        const k = key(i);
        const v = changes.get(k) || { item: i, delta: 0 };
        v.delta -= Number(i.qty) || 0;
        changes.set(k, v);
      });
    }

    p.items.forEach(i => {
      const k = key(i);
      const v = changes.get(k) || { item: i, delta: 0 };
      v.item = i;
      v.delta += i.qty;
      changes.set(k, v);
    });

    for (const [k, v] of changes) {
      let z = newStock.find(x => key(x) === k);
      if (!z) {
        if (v.delta > 0) {
          const i = v.item;
          const mrpVal = Number(i.mrp) || 0;
          const created: StockItem = {
            id: uid(),
            name: i.name,
            company: p.firm,
            batch: i.batch,
            expiry: i.expiry,
            packing: i.packing || '',
            cost: Number(i.rate) || 0,
            mrp: mrpVal > 0 ? mrpVal : (Number(i.rate) || 0),
            qty: Math.max(0, v.delta),
            unit: 'Piece'
          };
          newStock.push(created);
        }
      } else {
        z.qty = Math.max(0, (Number(z.qty) || 0) + v.delta);
        if (p.firm) z.company = p.firm;
        if (v.item.rate > 0) z.cost = v.item.rate;
        if (v.item.mrp && v.item.mrp > 0) z.mrp = v.item.mrp;
        if (v.item.packing) z.packing = v.item.packing;
      }
    }

    const newPurchases = old
      ? db.purchases.map(x => (x.id === old.id ? p : x))
      : [...db.purchases, p];

    saveDbWithSnapshot({
      ...db,
      stock: newStock,
      purchases: newPurchases
    });

    alert(old ? 'Purchase bill updated successfully.' : 'Purchase bill saved and stock updated.');

    // Reset form
    setEditingPurchaseId(null);
    setPDate(today());
    setPFirm('');
    setPBill('');
    setPPaid('0');
    setPNotes('');
    setPurchaseRows([{ id: uid(), name: '', qty: '1', packing: '', rate: '', mrp: '', batch: '', expiry: '' }]);
    setActiveTab('purchases');
  };

  const handleEditPurchase = (id: string) => {
    const p = db.purchases.find(x => x.id === id);
    if (!p) {
      alert('Selected purchase bill could not be found.');
      return;
    }
    setEditingPurchaseId(p.id);
    setPDate(p.date || today());
    setPFirm(p.firm || '');
    setPBill(p.bill || '');
    setPPaid(String(p.paid ?? 0));
    setPNotes(p.notes || '');
    setPurchaseRows(
      (p.items || []).map(i => ({
        id: uid(),
        name: i.name || (i as any).medicine || (i as any).itemName || '',
        qty: String(i.qty ?? 1),
        packing: i.packing || '',
        rate: i.rate != null ? String(i.rate) : '',
        mrp: i.mrp != null ? String(i.mrp) : (i.rate ? String(i.rate) : ''),
        batch: i.batch || '',
        expiry: i.expiry || ''
      }))
    );
    setActiveTab('purchase');
  };

  const handleDeletePurchase = (id: string, adjustStock: boolean) => {
    const p = db.purchases.find(x => x.id === id);
    if (!p) return;
    if (adjustStock) {
      const key = (i: { name: string; batch: string; expiry: string }) =>
        [String(i.name || '').trim().toLowerCase(), String(i.batch || '').trim(), String(i.expiry || '').trim()].join('|');
      const totals = new Map<string, number>();
      p.items.forEach(i => totals.set(key(i), (totals.get(key(i)) || 0) + Number(i.qty || 0)));

      for (const [k, qty] of totals) {
        const z = db.stock.find(x => key(x) === k);
        if (!z || (Number(z.qty) || 0) < qty) {
          alert('Cannot adjust stock for ' + k.split('|')[0] + ' because current stock is less than purchased qty.');
          return;
        }
      }

      if (!confirm('Delete this purchase bill and REMOVE its purchased quantities from stock?')) return;
      if (!confirm('Final confirmation: remove these quantities from stock?')) return;

      const newStock = db.stock.map(item => {
        const qtyDeduct = totals.get(key(item));
        return qtyDeduct ? { ...item, qty: item.qty - qtyDeduct } : item;
      });

      saveDbWithSnapshot({
        ...db,
        stock: newStock,
        purchases: db.purchases.filter(x => x.id !== id)
      });
    } else {
      if (!confirm('Directly delete this purchase bill record WITHOUT changing stock?')) return;
      saveDbWithSnapshot({
        ...db,
        purchases: db.purchases.filter(x => x.id !== id)
      });
    }

    if (editingPurchaseId === id) {
      setEditingPurchaseId(null);
    }
    alert('Purchase bill deleted.');
  };

  const handleViewPurchase = (p: PurchaseBill) => {
    const html = `
      <div style="font-family: 'Plus Jakarta Sans', Arial, sans-serif; padding: 24px; color: #0c201c; max-width: 680px; margin: 0 auto; background: #ffffff;">
        <style>
          @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700&family=Outfit:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
          * { box-sizing: border-box; }
        </style>
        <div style="text-align: center; border-bottom: 2px solid #0a3a30; padding-bottom: 12px; margin-bottom: 16px;">
          <h2 style="font-family: 'Outfit', sans-serif; font-size: 22px; font-weight: 800; text-transform: uppercase; margin: 0 0 4px; color: #0a3a30;">P D SHARMA MEDICAL STORE</h2>
          <div style="display: inline-block; background: #e6f6f1; color: #0a3a30; font-family: 'Outfit', sans-serif; font-size: 11px; font-weight: 700; padding: 2px 9px; border-radius: 12px; letter-spacing: 0.05em; text-transform: uppercase;">
            Inward Purchase Record
          </div>
        </div>
        <div style="background: #f8fbfa; border: 1.5px solid #e2ede8; border-radius: 8px; padding: 12px 14px; margin-bottom: 14px; font-size: 12.5px; line-height: 1.6;">
          <div><span style="color: #536b62; font-weight: 600;">Supplier / Firm:</span> <strong style="color: #0c201c;">${p.firm}</strong></div>
          <div style="display: flex; justify-content: space-between; margin-top: 4px;">
            <div><span style="color: #536b62; font-weight: 600;">Bill No:</span> <strong style="font-family: 'JetBrains Mono', monospace; color: #0a3a30;">${p.bill || 'Direct'}</strong></div>
            <div><span style="color: #536b62; font-weight: 600;">Date:</span> <strong>${p.date}</strong></div>
          </div>
        </div>
        <table style="width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 12.5px;">
          <thead>
            <tr style="background: #0a3a30; color: #ffffff;">
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: left; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase;">Item</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: center; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase;">Packing</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase;">Qty</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase;">Rate</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${p.items
              .map(
                (i, idx) => `
              <tr style="border-bottom: 1px solid #e2ede8; background: ${idx % 2 === 0 ? '#ffffff' : '#fafdff'};">
                <td style="border: 1px solid #e2ede8; padding: 8px 10px;">
                  <strong style="color: #0a3a30;">${i.name}</strong>
                  ${i.batch || i.expiry ? `<div style="color: #536b62; font-size: 11px; font-family: 'JetBrains Mono', monospace;">Batch: ${i.batch || '-'} &bull; Exp: ${i.expiry || '-'}</div>` : ''}
                </td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: center;">${i.packing || '-'}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700;">${i.qty}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace;">₹${money(i.rate)}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0a3a30;">₹${money(i.amount)}</td>
              </tr>
            `
              )
              .join('')}
            <tr style="background: #f4f8f6;">
              <th colspan="4" style="border: 1.5px solid #0a3a30; border-right: none; padding: 10px 12px; text-align: right; font-family: 'Outfit', sans-serif; font-weight: 700;">Bill Total</th>
              <th style="border: 1.5px solid #0a3a30; border-left: none; padding: 10px 12px; text-align: right; font-size: 16px; font-weight: 800; font-family: 'JetBrains Mono', monospace; color: #0a3a30; background: #eaf5f1;">₹${money(p.total)}</th>
            </tr>
          </tbody>
        </table>
        <div style="margin-top: 14px; background: #f8fbfa; border: 1px solid #e2ede8; border-radius: 6px; padding: 8px 12px; font-size: 12px; display: flex; justify-content: space-between;">
          <span>Paid: <strong style="font-family: 'JetBrains Mono', monospace; color: #0a3a30;">₹${money(p.paid)}</strong></span>
          <span>Balance: <strong style="font-family: 'JetBrains Mono', monospace; color: ${p.total - p.paid > 0 ? '#c22b2b' : '#0a3a30'};">₹${money(p.total - p.paid)}</strong></span>
        </div>
      </div>
    `;

    try {
      const w = window.open('', '_blank');
      if (w) {
        w.document.write(`<html><head><title>Purchase Bill</title></head><body>${html}<script>window.onload=()=>window.print()</script></body></html>`);
        w.document.close();
        return;
      }
    } catch {}

    setPrintModalContent({
      type: 'purchase',
      title: `Purchase Bill - ${p.firm} (${p.bill || p.date})`,
      html
    });
  };

  // -------------------------------------------------------------
  // SALES INVOICE ACTIONS (NON-GST)
  // -------------------------------------------------------------
  const handleAddSaleRow = () => {
    setSaleRows(prev => [
      ...prev,
      { id: uid(), name: '', qty: '1', packing: '', rate: '', batch: '', expiry: '' }
    ]);
  };

  const handleRemoveSaleRow = (id: string) => {
    if (saleRows.length > 1) {
      setSaleRows(prev => prev.filter(r => r.id !== id));
    }
  };

  const handleSaleItemChange = (id: string, field: keyof SaleItemInput, value: string) => {
    setSaleRows(prev =>
      prev.map(r => {
        if (r.id !== id) return r;
        const updated = { ...r, [field]: value };

        // When item name changes, autofill from stock (mrp, batch, expiry, packing)
        if (field === 'name') {
          const matches = db.stock.filter(x => x.name.toLowerCase() === value.trim().toLowerCase());
          const s = matches.find(x => x.qty > 0) || matches[0];
          if (s) {
            updated.rate = s.mrp ? String(s.mrp) : '';
            updated.batch = s.batch || '';
            updated.expiry = s.expiry || '';
            updated.packing = s.packing || '';
          }
        }
        return updated;
      })
    );
  };

  const saleCalculatedItems = saleRows.map(r => {
    const qty = parseQty(r.qty);
    const rate = Number(r.rate) || 0;
    const amount = (isNaN(qty) ? 0 : qty) * rate;
    return {
      name: r.name.trim(),
      qty,
      rate,
      packing: r.packing.trim(),
      batch: r.batch.trim(),
      expiry: r.expiry.trim(),
      amount
    };
  });

  const saleTotal = saleCalculatedItems.reduce((s, x) => s + (x.amount || 0), 0);

  const handleSaveSale = () => {
    const items = saleCalculatedItems;
    if (
      !items.length ||
      items.some(i => !i.name || !Number.isFinite(i.qty) || i.qty <= 0 || i.rate <= 0 || !i.batch || !i.expiry)
    ) {
      alert('Enter item, quantity, rate, batch and expiry for every item.');
      return;
    }

    const old = editingSaleId ? db.sales.find(x => x.id === editingSaleId) : null;
    if (editingSaleId && !old) {
      alert('The invoice being edited could not be found.');
      return;
    }

    const stockKey = (i: { name?: string; batch?: string; expiry?: string }) =>
      [String(i.name || '').trim().toLowerCase(), String(i.batch || '').trim(), String(i.expiry || '').trim()].join('|');

    const demand = new Map<string, number>();
    items.forEach(i => demand.set(stockKey(i), (demand.get(stockKey(i)) || 0) + i.qty));
    if (old) old.items.forEach(i => demand.set(stockKey(i), (demand.get(stockKey(i)) || 0) - i.qty));

    const missing = [...demand.entries()].filter(([k, net]) => {
      const z = db.stock.find(x => stockKey(x) === k);
      return !z || (Number(z.qty) || 0) - net < -0.000001;
    });

    if (missing.length > 0) {
      alert('Insufficient stock or item not found: ' + missing.map(([k]) => k.split('|')[0]).join(', '));
      return;
    }

    const billNo = saleBill.trim() || 'INV-' + Date.now().toString().slice(-8);
    if (db.sales.some(x => x.bill === billNo && (!old || x.id !== old.id))) {
      alert('This invoice number already exists. Enter a unique invoice number.');
      return;
    }

    const total = items.reduce((n, i) => n + i.amount, 0);
    const v: SalesInvoice = {
      id: old ? old.id : uid(),
      date: saleDate,
      customer: saleCustomer.trim() || 'Cash Customer',
      bill: billNo,
      doctor: saleDoctor.trim(),
      address: saleAddress.trim(),
      items,
      total
    };

    // Deduct stock
    const newStock = db.stock.map(item => {
      const k = stockKey(item);
      let qtyDelta = 0;
      if (old) {
        old.items.forEach(i => {
          if (stockKey(i) === k) qtyDelta += i.qty;
        });
      }
      items.forEach(i => {
        if (stockKey(i) === k) qtyDelta -= i.qty;
      });
      return { ...item, qty: item.qty + qtyDelta };
    });

    const newSales = old ? db.sales.map(x => (x.id === old.id ? v : x)) : [...db.sales, v];

    saveDbWithSnapshot({
      ...db,
      stock: newStock,
      sales: newSales
    });

    // Automatically trigger Print
    printInvoice(v);

    // Reset Form
    setEditingSaleId(null);
    setSaleDate(today());
    setSaleCustomer('');
    setSaleBill('');
    setSaleDoctor('');
    setSaleAddress('');
    setSaleRows([{ id: uid(), name: '', qty: '1', packing: '', rate: '', batch: '', expiry: '' }]);
  };

  const printInvoice = (s: SalesInvoice) => {
    const html = `
      <div style="font-family: 'Plus Jakarta Sans', Arial, sans-serif; padding: 28px; color: #0c201c; max-width: 680px; margin: 0 auto; background: #ffffff;">
        <style>
          @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700&family=Outfit:wght@600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
          * { box-sizing: border-box; }
        </style>
        
        <!-- Header Banner -->
        <div style="text-align: center; border-bottom: 2px solid #0a3a30; padding-bottom: 14px; margin-bottom: 16px;">
          <div style="display: inline-block; background: #e6f6f1; color: #0a3a30; font-family: 'Outfit', sans-serif; font-size: 11px; font-weight: 800; padding: 3px 10px; border-radius: 20px; letter-spacing: 0.08em; text-transform: uppercase; margin-bottom: 6px; border: 1px solid #bce4d6;">
            Retail Cash Memo • Non-GST Estimate
          </div>
          <h2 style="font-family: 'Outfit', sans-serif; font-size: 24px; font-weight: 800; text-transform: uppercase; margin: 4px 0 3px; color: #0a3a30; letter-spacing: -0.01em;">
            P D SHARMA MEDICAL STORE
          </h2>
          <p style="margin: 0; font-size: 12px; color: #536b62; font-weight: 500;">
            Retail Pharmacy &amp; Healthcare Dispenser • Date-wise Record
          </p>
        </div>

        <!-- Invoice Details Box -->
        <div style="background: #f8fbfa; border: 1.5px solid #e2ede8; border-radius: 8px; padding: 12px 16px; margin-bottom: 16px; font-size: 12.5px; line-height: 1.6;">
          <div style="display: flex; justify-content: space-between; flex-wrap: wrap;">
            <div>
              <span style="color: #536b62; font-weight: 600;">Invoice No:</span>
              <strong style="color: #0a3a30; font-family: 'JetBrains Mono', monospace; font-size: 13.5px; margin-left: 5px;">${s.bill}</strong>
            </div>
            <div>
              <span style="color: #536b62; font-weight: 600;">Date:</span>
              <strong style="color: #0a3a30; margin-left: 5px;">${s.date}</strong>
            </div>
          </div>
          <div style="margin-top: 6px; border-top: 1px dashed #d7e6e0; padding-top: 6px;">
            <div><span style="color: #536b62; font-weight: 600;">Patient / Customer:</span> <strong style="color: #0c201c;">${s.customer || 'Cash Sale'}</strong></div>
            ${s.doctor ? `<div><span style="color: #536b62; font-weight: 600;">Prescribed By:</span> Dr. ${s.doctor}</div>` : ''}
            ${s.address ? `<div><span style="color: #536b62; font-weight: 600;">Address:</span> ${s.address}</div>` : ''}
          </div>
        </div>

        <!-- Medicines Table -->
        <table style="width: 100%; border-collapse: collapse; margin-top: 10px; font-size: 12.5px;">
          <thead>
            <tr style="background: #0a3a30; color: #ffffff;">
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: left; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">#</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: left; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">Description of Item</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: center; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">Pack</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">Qty</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">Rate (₹)</th>
              <th style="border: 1px solid #0a3a30; padding: 8px 10px; text-align: right; font-family: 'Outfit', sans-serif; font-size: 11px; text-transform: uppercase; letter-spacing: 0.04em;">Net Amount</th>
            </tr>
          </thead>
          <tbody>
            ${s.items
              .map(
                (i, idx) => `
              <tr style="border-bottom: 1px solid #e2ede8; background: ${idx % 2 === 0 ? '#ffffff' : '#fafdff'};">
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; color: #7f978e; font-size: 11px; vertical-align: top;">${idx + 1}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; vertical-align: top;">
                  <strong style="color: #0a3a30; font-size: 13px;">${i.name}</strong>
                  <div style="color: #536b62; font-size: 11px; font-family: 'JetBrains Mono', monospace; margin-top: 2px;">
                    Batch: ${i.batch || '-'} &bull; Exp: ${i.expiry || '-'}
                  </div>
                </td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: center; vertical-align: top;">${i.packing || '-'}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700; vertical-align: top;">${i.qty}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace; vertical-align: top;">₹${money(i.rate)}</td>
                <td style="border: 1px solid #e2ede8; padding: 8px 10px; text-align: right; font-family: 'JetBrains Mono', monospace; font-weight: 700; color: #0a3a30; vertical-align: top;">₹${money(i.amount)}</td>
              </tr>
            `
              )
              .join('')}
            
            <!-- Grand Total Block -->
            <tr style="background: #f4f8f6;">
              <td colspan="4" style="border: 1.5px solid #0a3a30; border-right: none; padding: 12px 14px; text-align: right; font-family: 'Outfit', sans-serif; font-weight: 700; font-size: 13px; text-transform: uppercase; color: #0a3a30;">
                Net Amount Payable
              </td>
              <td colspan="2" style="border: 1.5px solid #0a3a30; border-left: none; padding: 12px 14px; text-align: right; font-size: 18px; font-weight: 800; font-family: 'JetBrains Mono', monospace; color: #0a3a30; background: #eaf5f1;">
                ₹${money(s.total)}
              </td>
            </tr>
          </tbody>
        </table>

        <!-- Sign-off & Pharmacy Footer -->
        <div style="margin-top: 32px; display: flex; justify-content: space-between; align-items: flex-end; padding-top: 14px; border-top: 1px solid #e2ede8;">
          <div style="font-size: 11px; color: #7f978e; line-height: 1.4;">
            * Medicines dispensed as per order / prescription.<br>
            * Non-GST Retail Supply. Goods once sold cannot be returned.
          </div>
          <div style="text-align: right;">
            <div style="height: 38px;"></div>
            <p style="margin: 0; font-size: 12px; font-weight: 700; color: #0a3a30; font-family: 'Outfit', sans-serif;">
              For P D SHARMA MEDICAL STORE
            </p>
            <span style="font-size: 10px; color: #536b62;">Authorised Signatory</span>
          </div>
        </div>

        <p style="margin-top: 24px; text-align: center; font-size: 12px; font-weight: 700; color: #0a3a30; font-family: 'Outfit', sans-serif; letter-spacing: 0.02em;">
          Thank you for choosing P D SHARMA MEDICAL STORE &bull; Wish you a speedy recovery!
        </p>
      </div>
    `;

    try {
      const w = window.open('', '_blank');
      if (w) {
        w.document.write(`<html><head><title>${s.bill}</title></head><body>${html}<script>window.onload=()=>window.print()</script></body></html>`);
        w.document.close();
        return;
      }
    } catch {}

    setPrintModalContent({
      type: 'sale',
      title: `Invoice ${s.bill}`,
      html
    });
  };

  const handleEditSale = (id: string) => {
    const v = db.sales.find(x => x.id === id);
    if (!v) return;
    setEditingSaleId(id);
    setSaleDate(v.date || today());
    setSaleCustomer(v.customer || '');
    setSaleBill(v.bill || '');
    setSaleDoctor(v.doctor || '');
    setSaleAddress(v.address || '');
    setSaleRows(
      v.items.map(i => ({
        id: uid(),
        name: i.name,
        qty: String(i.qty),
        packing: i.packing || '',
        rate: String(i.rate),
        batch: i.batch || '',
        expiry: i.expiry || ''
      }))
    );
    setActiveTab('sale');
  };

  const handleDeleteSale = (id: string, returnStock: boolean) => {
    const v = db.sales.find(x => x.id === id);
    if (!v) return;
    if (!confirm(returnStock ? 'Delete this sales invoice and RETURN sold quantities to stock?' : 'Directly delete this invoice record WITHOUT changing stock?')) return;

    if (returnStock) {
      const k = (i: { name?: string; batch?: string; expiry?: string }) =>
        [String(i.name || '').trim().toLowerCase(), String(i.batch || '').trim(), String(i.expiry || '').trim()].join('|');

      const newStock = [...db.stock];
      for (const i of v.items) {
        const z = newStock.find(x => k(x) === k(i));
        if (z) {
          z.qty += i.qty;
        } else {
          newStock.push({
            id: uid(),
            name: i.name,
            company: '',
            batch: i.batch || '',
            expiry: i.expiry || '',
            cost: 0,
            mrp: i.rate || 0,
            qty: i.qty,
            unit: 'Piece'
          });
        }
      }

      saveDbWithSnapshot({
        ...db,
        stock: newStock,
        sales: db.sales.filter(x => x.id !== id)
      });
    } else {
      saveDbWithSnapshot({
        ...db,
        sales: db.sales.filter(x => x.id !== id)
      });
    }

    if (editingSaleId === id) {
      setEditingSaleId(null);
    }
    alert('Sales invoice deleted.');
  };

  const handleMoveSaleToInvoice = (id: string) => {
    const v = db.sales.find(x => x.id === id);
    if (!v) return;
    if (!confirm('Copy all items from this saved invoice into a NEW sales invoice? The original invoice will remain unchanged. Saving the new invoice will deduct stock again.')) return;

    setEditingSaleId(null);
    setSaleDate(today());
    setSaleCustomer(v.customer || '');
    setSaleBill('');
    setSaleDoctor(v.doctor || '');
    setSaleAddress(v.address || '');
    setSaleRows(
      (v.items || []).map(i => ({
        id: uid(),
        name: i.name || '',
        qty: String(i.qty ?? 1),
        packing: i.packing || '',
        rate: String(i.rate ?? 0),
        batch: i.batch || '',
        expiry: i.expiry || ''
      }))
    );
    if (!v.items.length) {
      setSaleRows([{ id: uid(), name: '', qty: '1', packing: '', rate: '', batch: '', expiry: '' }]);
    }
    setActiveTab('sale');
  };

  const salesItemKey = (sId: string, i: number) => `${sId}::${i}`;

  const handleMoveSelectedSalesItems = () => {
    const picked: { sale: SalesInvoice; item: BillItem }[] = [];
    db.sales.forEach(s =>
      (s.items || []).forEach((i, index) => {
        if (selectedSalesItems.has(salesItemKey(s.id, index))) {
          picked.push({ sale: s, item: i });
        }
      })
    );

    if (!picked.length) {
      alert('Select one or more items in the Sales Register first.');
      return;
    }

    if (
      !confirm(
        'Load ' +
          picked.length +
          ' selected item(s) into a NEW sales invoice? The original invoices will remain unchanged. Saving the new invoice deducts stock again.'
      )
    )
      return;

    const first = picked[0].sale;
    setEditingSaleId(null);
    setSaleDate(today());
    setSaleCustomer(first.customer || '');
    setSaleBill('');
    setSaleDoctor(first.doctor || '');
    setSaleAddress(first.address || '');
    setSaleRows(
      picked.map(({ item: i }) => ({
        id: uid(),
        name: i.name || '',
        qty: String(i.qty ?? 1),
        packing: i.packing || '',
        rate: String(i.rate ?? 0),
        batch: i.batch || '',
        expiry: i.expiry || ''
      }))
    );
    setActiveTab('sale');
  };

  const handleDeleteStock = (id: string) => {
    const item = db.stock.find(x => x.id === id);
    if (!item) return;
    if (confirm('Delete ' + item.name + ' (batch ' + (item.batch || '-') + ') from current stock? Historical bills will remain.') && confirm('Confirm deletion of this stock row?')) {
      saveDbWithSnapshot({
        ...db,
        stock: db.stock.filter(x => x.id !== id)
      });
    }
  };

  // -------------------------------------------------------------
  // BACKUP & CSV ACTIONS
  // -------------------------------------------------------------
  const downloadBlob = (content: string, type: string, name: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  const handleExportData = () => {
    const data = {
      app: 'P D SHARMA MEDICAL STORE',
      version: 2,
      exportedAt: new Date().toISOString(),
      ...db
    };
    downloadBlob(JSON.stringify(data, null, 2), 'application/json', 'pd-sharma-medical-store-backup-' + today() + '.json');
    localStorage.setItem(BACKUP_REMINDER_KEY, String(Date.now()));
    setBackupReminderDays(0);
  };

  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const d = JSON.parse(await f.text());
      if (!d || !Array.isArray(d.stock) || !Array.isArray(d.purchases) || !Array.isArray(d.sales)) {
        throw new Error('Invalid format');
      }
      if (!confirm('Replace current stock, purchase bills and sales invoices with this backup? A safety copy of current records will be saved first.')) return;
      saveDbWithSnapshot({
        stock: d.stock,
        purchases: d.purchases,
        sales: d.sales
      });
      alert('Backup restored successfully.');
    } catch {
      alert('Invalid or unreadable backup file. Current records were not changed.');
    } finally {
      e.target.value = '';
    }
  };

  const handleRestoreLocalBackup = () => {
    const i = Number(selectedBackupIndex);
    if (isNaN(i) || !localBackups[i]) return;
    const b = localBackups[i];
    if (!confirm('Restore this previous copy? Your current records will first be saved as another automatic backup.')) return;
    saveDbWithSnapshot({
      stock: Array.isArray(b.data.stock) ? b.data.stock : [],
      purchases: Array.isArray(b.data.purchases) ? b.data.purchases : [],
      sales: Array.isArray(b.data.sales) ? b.data.sales : []
    });
    alert('Previous backup restored.');
  };

  const csvCell = (v: any) => '"' + String(v ?? '').replace(/"/g, '""') + '"';

  const handleExportStockCsv = () => {
    const cols = ['name', 'company', 'batch', 'expiry', 'packing', 'qty', 'cost', 'mrp', 'unit'];
    const rows = [cols.join(','), ...db.stock.map(x => cols.map(k => csvCell((x as any)[k])).join(','))];
    downloadBlob('\ufeff' + rows.join('\r\n'), 'text/csv;charset=utf-8', 'pd-sharma-stock-' + today() + '.csv');
  };

  const parseCSV = (text: string) => {
    const rows: string[][] = [];
    let row: string[] = [];
    let v = '';
    let q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"' && text[i + 1] === '"') {
          v += '"';
          i++;
        } else if (c === '"') {
          q = false;
        } else {
          v += c;
        }
      } else if (c === '"') {
        q = true;
      } else if (c === ',') {
        row.push(v);
        v = '';
      } else if (c === '\n') {
        row.push(v.replace(/\r$/, ''));
        rows.push(row);
        row = [];
        v = '';
      } else {
        v += c;
      }
    }
    if (v.length || row.length) {
      row.push(v.replace(/\r$/, ''));
      rows.push(row);
    }
    return rows;
  };

  const handleImportStockCsv = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;
    try {
      const rows = parseCSV(await f.text());
      if (rows.length < 2) throw new Error();
      const headers = rows.shift()!.map(x => x.replace(/^\uFEFF/, '').trim().toLowerCase());
      const required = ['name', 'batch', 'expiry', 'qty'];
      if (required.some(k => !headers.includes(k))) throw new Error();

      const incoming = rows.map(r => Object.fromEntries(headers.map((h, i) => [h, r[i] ?? '']))).filter(x => String(x.name || '').trim());
      let added = 0;
      let skipped = 0;
      const key = (x: any) =>
        [String(x.name || '').trim().toLowerCase(), String(x.batch || '').trim().toLowerCase(), String(x.expiry || '').trim().toLowerCase()].join('|');
      const seen = new Set(db.stock.map(key));
      const clean: StockItem[] = [];

      for (const x of incoming) {
        const k = key(x);
        if (seen.has(k)) {
          skipped++;
          continue;
        }
        const qty = Number(x.qty);
        if (!Number.isFinite(qty) || qty < 0 || !String(x.batch || '').trim() || !String(x.expiry || '').trim()) continue;
        seen.add(k);
        clean.push({
          id: uid(),
          name: String(x.name).trim(),
          company: x.company || '',
          batch: x.batch || '',
          expiry: x.expiry || '',
          packing: x.packing || '',
          qty,
          cost: Number(x.cost) || 0,
          mrp: Number(x.mrp) || 0,
          unit: x.unit || 'Piece'
        });
        added++;
      }

      if (!added) {
        alert('No new stock rows to import. Existing matching batches were left unchanged.');
        return;
      }

      if (!confirm('Add ' + added + ' new stock row(s)? ' + skipped + ' matching existing row(s) will be skipped.')) return;

      saveDbWithSnapshot({
        ...db,
        stock: [...db.stock, ...clean]
      });
      alert('Stock import complete. Added: ' + added + '. Skipped duplicates: ' + skipped + '.');
    } catch {
      alert('CSV could not be imported. Use the exported stock CSV format and check required columns: name, batch, expiry, qty.');
    } finally {
      e.target.value = '';
    }
  };

  const handleClearAll = () => {
    if (confirm('This permanently deletes all stock and bill records on this device. Continue?') && confirm('Final confirmation: delete EVERYTHING? A safety copy will be saved first.')) {
      saveDbWithSnapshot({
        stock: [],
        purchases: [],
        sales: []
      });
      alert('App data cleared.');
    }
  };

  // Printing full sections
  const handlePrintSection = () => {
    window.print();
  };

  // -------------------------------------------------------------
  // Filtered views
  // -------------------------------------------------------------
  const filteredStock = db.stock.filter(x => {
    const q = stockSearch.trim().toLowerCase();
    if (!q) return true;
    const bills = purchasesForStock(x).map(p => p.bill || '');
    return [x.name, x.company, x.batch, x.expiry, ...bills].join(' ').toLowerCase().includes(q);
  });

  const filteredPurchases = db.purchases.filter(p => {
    if (purchaseFrom && p.date < purchaseFrom) return false;
    if (purchaseTo && p.date > purchaseTo) return false;
    const q = purchaseSearch.trim().toLowerCase();
    if (!q) return true;
    const header = [p.firm, p.bill, p.date].join(' ').toLowerCase();
    const itemMatch = (p.items || []).some(i =>
      [i.name, (i as any).medicine, (i as any).itemName, i.batch, i.expiry, i.packing].join(' ').toLowerCase().includes(q)
    );
    return header.includes(q) || itemMatch;
  });

  const purchaseRowsFlat = [...filteredPurchases]
    .sort((a, b) => b.date.localeCompare(a.date))
    .flatMap(p => (p.items || []).map((i, index) => ({ p, i, index })));

  const filteredSales = db.sales.filter(s => {
    if (salesFrom && s.date < salesFrom) return false;
    if (salesTo && s.date > salesTo) return false;
    const q = salesSearch.trim().toLowerCase();
    if (!q) return true;
    return (s.customer + ' ' + s.bill).toLowerCase().includes(q);
  });

  const sortedSales = [...filteredSales].sort((a, b) => b.date.localeCompare(a.date));

  const recentPurchases = [...db.purchases].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);
  const recentSales = [...db.sales].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 5);

  const totalUnits = db.stock.reduce((s, x) => s + (Number(x.qty) || 0), 0);
  const totalStockWorthMRP = db.stock.reduce((s, x) => s + (Number(x.mrp) || 0) * (Number(x.qty) || 0), 0);
  const totalStockWorthCost = db.stock.reduce((s, x) => s + (Number(x.cost) || 0) * (Number(x.qty) || 0), 0);
  const lowStockCount = db.stock.filter(x => (Number(x.qty) || 0) <= 5).length;

  // Quick Search / Command Palette (Ctrl+K) items calculation
  interface CommandItem {
    id: string;
    title: string;
    subtitle: string;
    category: 'Navigation' | 'Actions' | 'Stock Item';
    icon: any;
    badge?: string;
    onSelect: () => void;
  }

  const commandItems: CommandItem[] = (() => {
    const q = commandQuery.trim().toLowerCase();

    const baseNav: CommandItem[] = [
      {
        id: 'nav-dashboard',
        title: 'Go to Dashboard',
        subtitle: 'Key business metrics, stock valuation & live activity pulse',
        category: 'Navigation',
        icon: LayoutDashboard,
        onSelect: () => { setActiveTab('home'); setIsCommandOpen(false); }
      },
      {
        id: 'action-sale',
        title: 'Create Sales Invoice',
        subtitle: 'Dispense medicines & print retail Non-GST cash memo',
        category: 'Actions',
        icon: Receipt,
        badge: 'New Bill',
        onSelect: () => {
          setEditingSaleId(null);
          setActiveTab('sale');
          setIsCommandOpen(false);
        }
      },
      {
        id: 'action-purchase',
        title: 'Add Inward Purchase',
        subtitle: 'Inward wholesale supplier bill, cost & batch records',
        category: 'Actions',
        icon: PlusCircle,
        badge: 'Inward',
        onSelect: () => {
          setEditingPurchaseId(null);
          setActiveTab('purchase');
          setIsCommandOpen(false);
        }
      },
      {
        id: 'nav-stock',
        title: 'Stock Directory',
        subtitle: 'Browse all in-stock medicines, quantities & expiries',
        category: 'Navigation',
        icon: Package,
        onSelect: () => { setActiveTab('stock'); setIsCommandOpen(false); }
      },
      {
        id: 'nav-purchases',
        title: 'Purchase Register',
        subtitle: 'Date-wise inward supplier bills & payment balances',
        category: 'Navigation',
        icon: FileSpreadsheet,
        onSelect: () => { setActiveTab('purchases'); setIsCommandOpen(false); }
      },
      {
        id: 'nav-sales',
        title: 'Sales Register',
        subtitle: 'Past customer cash memos with multi-item selection',
        category: 'Navigation',
        icon: History,
        onSelect: () => { setActiveTab('sales'); setIsCommandOpen(false); }
      },
      {
        id: 'nav-backup',
        title: 'Backup & Database Sync',
        subtitle: 'Local JSON snapshots, CSV export & cloud synchronization',
        category: 'Navigation',
        icon: Database,
        onSelect: () => { setActiveTab('backup'); setIsCommandOpen(false); }
      },
      {
        id: 'action-export-csv',
        title: 'Export Stock to CSV',
        subtitle: 'Download spreadsheet file with all inventory rows',
        category: 'Actions',
        icon: Download,
        onSelect: () => { handleExportStockCsv(); setIsCommandOpen(false); }
      },
      {
        id: 'action-download-json',
        title: 'Download JSON Safety Backup',
        subtitle: 'Save complete store database copy to local device',
        category: 'Actions',
        icon: Database,
        onSelect: () => { handleExportData(); setIsCommandOpen(false); }
      }
    ];

    const filteredNav = q
      ? baseNav.filter(item =>
          item.title.toLowerCase().includes(q) ||
          item.subtitle.toLowerCase().includes(q)
        )
      : baseNav;

    // Matching stock items
    let stockItems: CommandItem[] = [];
    if (q) {
      const matched = db.stock.filter(s =>
        [s.name, s.company, s.batch, s.expiry, s.packing].join(' ').toLowerCase().includes(q)
      ).slice(0, 15);

      stockItems = matched.map(s => ({
        id: `stock-${s.id}`,
        title: s.name,
        subtitle: `${s.company ? s.company + ' • ' : ''}Batch: ${s.batch} • Exp: ${s.expiry || '-'} • MRP: ₹${money(s.mrp)} • Cost: ₹${money(s.cost)}`,
        category: 'Stock Item' as const,
        icon: Package,
        badge: `${s.qty} in stock`,
        onSelect: () => {
          // Open Sales Invoice with this item pre-filled!
          setSaleRows([
            {
              id: uid(),
              name: s.name,
              qty: '1',
              packing: s.packing || '',
              rate: s.mrp ? String(s.mrp) : (s.cost ? String(s.cost) : ''),
              batch: s.batch || '',
              expiry: s.expiry || ''
            }
          ]);
          setEditingSaleId(null);
          setActiveTab('sale');
          setIsCommandOpen(false);
        }
      }));
    }

    return [...filteredNav, ...stockItems];
  })();

  const handleCommandKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setCommandSelectedIndex(prev => (commandItems.length ? (prev + 1) % commandItems.length : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setCommandSelectedIndex(prev => (commandItems.length ? (prev - 1 + commandItems.length) % commandItems.length : 0));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (commandItems[commandSelectedIndex]) {
        commandItems[commandSelectedIndex].onSelect();
      }
    }
  };

  return (
    <div>
      {/* Executive Header */}
      <header>
        <div style={{ maxWidth: '1320px', margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: '12px' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            <div style={{
              width: '42px',
              height: '42px',
              borderRadius: '11px',
              background: 'linear-gradient(135deg, #10b981 0%, #0a3a30 100%)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: '0 4px 14px rgba(16, 185, 129, 0.25)',
              border: '1.5px solid rgba(255, 255, 255, 0.2)'
            }}>
              <Activity style={{ width: '22px', height: '22px', color: '#ffffff' }} />
            </div>
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <h1 style={{ margin: 0, fontSize: '20px', letterSpacing: '-0.02em', fontWeight: 800 }}>P D SHARMA MEDICAL STORE</h1>
                <span style={{
                  fontSize: '10px',
                  fontWeight: 800,
                  background: 'rgba(255, 255, 255, 0.12)',
                  color: '#e2f4ed',
                  padding: '2px 8px',
                  borderRadius: '12px',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  letterSpacing: '0.05em'
                }}>NON-GST</span>
              </div>
              <p style={{ margin: '2px 0 0', fontSize: '11.5px', color: '#a3d9cb' }}>
                Stock Management • Inward Purchase • Non-GST Retail Invoices
              </p>
            </div>
          </div>

          <div className="no-print" style={{ display: 'flex', alignItems: 'center', gap: '10px', flexWrap: 'wrap' }}>
            <button
              type="button"
              onClick={() => {
                setIsCommandOpen(true);
                setCommandQuery('');
                setCommandSelectedIndex(0);
              }}
              style={{
                background: 'rgba(255, 255, 255, 0.1)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                borderRadius: '10px',
                padding: '6px 14px',
                display: 'flex',
                alignItems: 'center',
                gap: '8px',
                cursor: 'pointer',
                color: '#ffffff',
                fontSize: '12.5px',
                transition: 'all 0.15s ease'
              }}
              title="Global Quick Search (Ctrl+K)"
            >
              <Search style={{ width: '14px', height: '14px', color: '#10b981' }} />
              <span style={{ color: '#e6f7f2', fontWeight: 600 }}>Quick Search</span>
              <kbd style={{
                background: 'rgba(0, 0, 0, 0.3)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                borderRadius: '5px',
                padding: '1px 6px',
                fontSize: '10.5px',
                fontFamily: 'JetBrains Mono, monospace',
                color: '#a3d9cb',
                marginLeft: '4px'
              }}>Ctrl K</kbd>
            </button>

            <div style={{
              background: 'rgba(255, 255, 255, 0.08)',
              border: '1px solid rgba(255, 255, 255, 0.12)',
              borderRadius: '20px',
              padding: '5px 12px',
              display: 'flex',
              alignItems: 'center',
              gap: '6px',
              fontSize: '11.5px',
              color: '#d1fae5'
            }}>
              <span style={{ width: '7px', height: '7px', borderRadius: '50%', background: '#10b981', boxShadow: '0 0 8px #10b981' }}></span>
              <span style={{ fontWeight: 600 }}>Active Pharmacy Store</span>
            </div>
          </div>
        </div>
      </header>

      {/* Modern Sticky Navigation */}
      <nav className="no-print">
        <div style={{ maxWidth: '1320px', margin: '0 auto', display: 'flex', gap: '6px', width: '100%' }}>
          <button className={activeTab === 'home' ? 'active' : ''} onClick={() => setActiveTab('home')}>
            <LayoutDashboard style={{ width: '15px', height: '15px' }} />
            <span>Dashboard</span>
          </button>
          <button className={activeTab === 'stock' ? 'active' : ''} onClick={() => setActiveTab('stock')}>
            <Package style={{ width: '15px', height: '15px' }} />
            <span>Stock</span>
          </button>
          <button className={activeTab === 'purchase' ? 'active' : ''} onClick={() => setActiveTab('purchase')}>
            <PlusCircle style={{ width: '15px', height: '15px' }} />
            <span>Add Purchase</span>
          </button>
          <button className={activeTab === 'purchases' ? 'active' : ''} onClick={() => setActiveTab('purchases')}>
            <FileSpreadsheet style={{ width: '15px', height: '15px' }} />
            <span>Purchase Register</span>
          </button>
          <button className={activeTab === 'sale' ? 'active' : ''} onClick={() => setActiveTab('sale')}>
            <Receipt style={{ width: '15px', height: '15px' }} />
            <span>Sales Invoice</span>
          </button>
          <button className={activeTab === 'sales' ? 'active' : ''} onClick={() => setActiveTab('sales')}>
            <History style={{ width: '15px', height: '15px' }} />
            <span>Sales Register</span>
          </button>
          <button className={activeTab === 'backup' ? 'active' : ''} onClick={() => setActiveTab('backup')}>
            <Database style={{ width: '15px', height: '15px' }} />
            <span>Backup &amp; Sync</span>
          </button>
        </div>
      </nav>

      {/* Main Container */}
      <main>
        {/* ================= PANEL 1: DASHBOARD ================= */}
        {activeTab === 'home' && (
          <section id="home" className="panel active">
            
            {/* Primary KPI Metrics */}
            <div className="stats">
              <div className="stat">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <small>Total Stock SKUs</small>
                  <Package style={{ width: '16px', height: '16px', color: '#166958' }} />
                </div>
                <strong>{db.stock.length}</strong>
                <span className="muted" style={{ fontSize: '11px', marginTop: '2px', display: 'block' }}>
                  {totalUnits} Units in Hand {lowStockCount > 0 ? `• ${lowStockCount} Low` : ''}
                </span>
              </div>
              <div className="stat">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <small>Inventory Valuation (MRP)</small>
                  <TrendingUp style={{ width: '16px', height: '16px', color: '#10b981' }} />
                </div>
                <strong style={{ color: '#093a30' }}>₹{money(totalStockWorthMRP)}</strong>
                <span className="muted" style={{ fontSize: '11px', marginTop: '2px', display: 'block' }}>
                  Cost Worth: ₹{money(totalStockWorthCost)}
                </span>
              </div>
              <div className="stat">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <small>Purchase Bills</small>
                  <FileSpreadsheet style={{ width: '16px', height: '16px', color: '#3b82f6' }} />
                </div>
                <strong>{db.purchases.length}</strong>
                <span className="muted" style={{ fontSize: '11px', marginTop: '2px', display: 'block' }}>
                  Supplier records entered
                </span>
              </div>
              <div className="stat">
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <small>Sales Invoices</small>
                  <Receipt style={{ width: '16px', height: '16px', color: '#10b981' }} />
                </div>
                <strong>{db.sales.length}</strong>
                <span className="muted" style={{ fontSize: '11px', marginTop: '2px', display: 'block' }}>
                  Non-GST bills generated
                </span>
              </div>
            </div>

            {/* Quick Action Navigation Bar */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '14px', marginTop: '16px', marginBottom: '16px' }}>
              <div
                className="card"
                style={{
                  margin: 0,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  borderLeft: '4px solid #0a3a30',
                  transition: 'all 0.18s ease'
                }}
                onClick={() => setActiveTab('sale')}
              >
                <div>
                  <h3 style={{ margin: 0, color: 'var(--brand-dark)' }}>Create Sales Invoice</h3>
                  <p className="muted" style={{ margin: '3px 0 0', fontSize: '12px' }}>Dispense medicines &amp; print retail cash memo</p>
                </div>
                <button className="btn small" type="button">
                  <span>Create Bill</span>
                  <ArrowRight style={{ width: '13px', height: '13px' }} />
                </button>
              </div>

              <div
                className="card"
                style={{
                  margin: 0,
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  cursor: 'pointer',
                  borderLeft: '4px solid #166958',
                  transition: 'all 0.18s ease'
                }}
                onClick={() => setActiveTab('purchase')}
              >
                <div>
                  <h3 style={{ margin: 0, color: 'var(--brand-teal)' }}>Inward Supplier Purchase</h3>
                  <p className="muted" style={{ margin: '3px 0 0', fontSize: '12px' }}>Enter new batch stock, cost &amp; expiry records</p>
                </div>
                <button className="btn small secondary" type="button">
                  <span>Inward Stock</span>
                  <ArrowRight style={{ width: '13px', height: '13px' }} />
                </button>
              </div>
            </div>

            {/* Recent Purchases & Sales Tables */}
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '14px' }}>
              
              <div className="card" style={{ margin: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h2 style={{ margin: 0 }}>Recent Purchases</h2>
                  <button className="btn small secondary no-print" type="button" onClick={() => setActiveTab('purchases')}>
                    View All
                  </button>
                </div>

                {recentPurchases.length ? (
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Supplier</th>
                          <th>Bill No</th>
                          <th style={{ textAlign: 'right' }}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recentPurchases.map(x => (
                          <tr key={x.id}>
                            <td>{x.date}</td>
                            <td><b>{x.firm}</b></td>
                            <td><span className="pill">{x.bill || 'Direct'}</span></td>
                            <td style={{ textAlign: 'right', fontWeight: 'bold' }}>₹{money(x.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="empty">No purchase records logged yet.</div>
                )}
              </div>

              <div className="card" style={{ margin: 0 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
                  <h2 style={{ margin: 0 }}>Recent Sales</h2>
                  <button className="btn small secondary no-print" type="button" onClick={() => setActiveTab('sales')}>
                    View All
                  </button>
                </div>

                {recentSales.length ? (
                  <div className="table-wrap">
                    <table>
                      <thead>
                        <tr>
                          <th>Date</th>
                          <th>Invoice</th>
                          <th>Customer</th>
                          <th style={{ textAlign: 'right' }}>Total</th>
                        </tr>
                      </thead>
                      <tbody>
                        {recentSales.map(x => (
                          <tr key={x.id}>
                            <td>{x.date}</td>
                            <td><span className="pill">{x.bill}</span></td>
                            <td><b>{x.customer}</b></td>
                            <td style={{ textAlign: 'right', fontWeight: 'bold' }}>₹{money(x.total)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="empty">No sales invoices generated yet.</div>
                )}
              </div>

            </div>

          </section>
        )}

        {/* ================= PANEL 2: STOCK ================= */}
        {activeTab === 'stock' && (
          <section id="stock" className="panel active">
            <div className="card">
              <div style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'space-between', alignItems: 'center', gap: '10px', marginBottom: '14px' }}>
                <h2 style={{ margin: 0 }}>Stock Directory ({filteredStock.length})</h2>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn small secondary" type="button" onClick={handleExportStockCsv}>
                    <Download style={{ width: '13px', height: '13px' }} />
                    <span>Export CSV</span>
                  </button>
                  <button className="btn small" type="button" onClick={() => setActiveTab('purchase')}>
                    <Plus style={{ width: '13px', height: '13px' }} />
                    <span>Add Inward Stock</span>
                  </button>
                </div>
              </div>

              <div style={{ position: 'relative', marginBottom: '12px' }}>
                <input
                  value={stockSearch}
                  onChange={e => setStockSearch(e.target.value)}
                  placeholder="Search by item name, company, batch, expiry or bill number..."
                  style={{ paddingLeft: '32px' }}
                />
                <Search style={{ position: 'absolute', left: '10px', top: '12px', width: '14px', height: '14px', color: '#64746e' }} />
              </div>

              <div className="table-wrap">
                {filteredStock.length ? (
                  <table>
                    <thead>
                      <tr>
                        <th>Item Description</th>
                        <th>Packing</th>
                        <th>Company / Batch</th>
                        <th>Expiry</th>
                        <th>Purchase Bill</th>
                        <th style={{ textAlign: 'right' }}>Stock Qty</th>
                        <th style={{ textAlign: 'right' }}>Cost ₹</th>
                        <th style={{ textAlign: 'right' }}>MRP ₹</th>
                        <th className="no-print" style={{ textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredStock.map(x => {
                        const bills = purchasesForStock(x);
                        const isLow = (Number(x.qty) || 0) <= 5;
                        return (
                          <tr key={x.id}>
                            <td>
                              <b>{x.name}</b>
                              <span className="muted" style={{ display: 'block', fontSize: '11px' }}>{x.unit}</span>
                            </td>
                            <td>{x.packing || '-'}</td>
                            <td>
                              <div>{x.company}</div>
                              <span className="muted font-mono" style={{ fontSize: '11px' }}>{x.batch}</span>
                            </td>
                            <td>
                              <span className="font-mono">{x.expiry || '-'}</span>
                            </td>
                            <td>
                              {bills.length
                                ? bills.map(p => (
                                    <div key={p.id} style={{ marginBottom: '2px' }}>
                                      <span className="pill" style={{ fontSize: '10px' }}>{p.bill || 'Direct'}</span>
                                      <button
                                        className="btn small secondary no-print"
                                        type="button"
                                        style={{ marginLeft: '6px', padding: '2px 6px', fontSize: '10px' }}
                                        onClick={() => handleEditPurchase(p.id)}
                                      >
                                        Edit
                                      </button>
                                    </div>
                                  ))
                                : '-'}
                            </td>
                            <td style={{ textAlign: 'right' }}>
                              <span className={`font-mono ${isLow ? 'text-red-700 font-bold' : 'font-semibold'}`} style={{ color: isLow ? '#b91c1c' : 'inherit' }}>
                                {x.qty}
                              </span>
                            </td>
                            <td style={{ textAlign: 'right' }} className="font-mono">₹{money(x.cost)}</td>
                            <td style={{ textAlign: 'right', fontWeight: 'bold' }} className="font-mono">₹{money(x.mrp)}</td>
                            <td className="no-print" style={{ textAlign: 'center' }}>
                              <button
                                className="btn small red"
                                type="button"
                                title="Delete stock row"
                                onClick={() => handleDeleteStock(x.id)}
                              >
                                <Trash2 style={{ width: '12px', height: '12px' }} />
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                ) : (
                  <div className="empty">No stock items match your search.</div>
                )}
              </div>
            </div>
          </section>
        )}

        {/* ================= PANEL 3: ADD PURCHASE ================= */}
        {activeTab === 'purchase' && (
          <section id="purchase" className="panel active">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 style={{ margin: 0 }}>
                  {editingPurchaseId ? 'Update Purchase Bill' : 'Enter Purchase Bill (Inward Stock)'}
                </h2>
                {editingPurchaseId && (
                  <span className="pill" style={{ background: '#fef3c7', color: '#92400e' }}>
                    Editing Mode
                  </span>
                )}
              </div>

              <form
                id="purchaseForm"
                onSubmit={e => {
                  e.preventDefault();
                  handleSavePurchase();
                }}
              >
                <div className="grid">
                  <div>
                    <label>Purchase date *</label>
                    <input type="date" required value={pDate} onChange={e => setPDate(e.target.value)} />
                  </div>
                  <div>
                    <label>Supplier / firm name *</label>
                    <input
                      required
                      placeholder="Wholesaler / distributor name"
                      value={pFirm}
                      onChange={e => setPFirm(e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Supplier bill number</label>
                    <input placeholder="Invoice / memo number" value={pBill} onChange={e => setPBill(e.target.value)} />
                  </div>
                  <div>
                    <label>Amount paid (₹)</label>
                    <input
                      type="number"
                      min="0"
                      step="0.01"
                      value={pPaid}
                      onChange={e => setPPaid(e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Notes</label>
                    <input placeholder="Remarks (optional)" value={pNotes} onChange={e => setPNotes(e.target.value)} />
                  </div>
                </div>

                <div style={{ marginTop: '18px', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ margin: 0 }}>Purchase Items List ({purchaseRows.length})</h3>
                  <button className="btn small secondary no-print" type="button" onClick={handleAddPurchaseRow}>
                    <Plus style={{ width: '13px', height: '13px' }} />
                    <span>Add Item Row</span>
                  </button>
                </div>

                <div id="purchaseItems">
                  {purchaseRows.map((r, idx) => (
                    <div key={r.id} className="itemrow" data-type="purchase">
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontSize: '11px', fontWeight: 'bold', color: 'var(--green)' }}>Item #{idx + 1}</span>
                        {purchaseRows.length > 1 && (
                          <button
                            className="btn small red"
                            type="button"
                            style={{ padding: '2px 7px', fontSize: '11px' }}
                            onClick={() => handleRemovePurchaseRow(r.id)}
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      <div className="itemgrid">
                        <div>
                          <label>Item name *</label>
                          <input
                            list="stockOptions"
                            placeholder="Medicine name"
                            required
                            value={r.name}
                            onChange={e => handlePurchaseItemChange(r.id, 'name', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Quantity * (e.g. 2*10)</label>
                          <input
                            type="text"
                            inputMode="decimal"
                            placeholder="e.g. 10 or 2*10"
                            required
                            value={r.qty}
                            onChange={e => handlePurchaseItemChange(r.id, 'qty', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Packing</label>
                          <input
                            type="text"
                            placeholder="1*10, 100ML, 15gm"
                            value={r.packing}
                            onChange={e => handlePurchaseItemChange(r.id, 'packing', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Purchase rate ₹</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="Rate (optional)"
                            value={r.rate}
                            onChange={e => handlePurchaseItemChange(r.id, 'rate', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>MRP ₹</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            placeholder="MRP (optional)"
                            value={r.mrp}
                            onChange={e => handlePurchaseItemChange(r.id, 'mrp', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Batch number *</label>
                          <input
                            placeholder="Batch No"
                            required
                            value={r.batch}
                            onChange={e => handlePurchaseItemChange(r.id, 'batch', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Expiry date *</label>
                          <input
                            type="text"
                            placeholder="MM/YYYY or YYYY-MM"
                            required
                            value={r.expiry}
                            onChange={e => handlePurchaseItemChange(r.id, 'expiry', e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="total">
                  Bill total: <span>₹{money(purchaseTotal)}</span>
                </div>

                <div className="actions" style={{ justifyContent: 'flex-end', marginTop: '16px' }}>
                  <button
                    className="btn secondary"
                    type="button"
                    onClick={() => {
                      if (confirm('Clear this purchase form?')) {
                        setEditingPurchaseId(null);
                        setPDate(today());
                        setPFirm('');
                        setPBill('');
                        setPPaid('0');
                        setPNotes('');
                        setPurchaseRows([{ id: uid(), name: '', qty: '1', packing: '', rate: '', mrp: '', batch: '', expiry: '' }]);
                      }
                    }}
                  >
                    Clear Bill
                  </button>
                  <button className="btn" type="submit">
                    <CheckCircle2 style={{ width: '15px', height: '15px' }} />
                    <span>{editingPurchaseId ? 'Update Purchase Bill' : 'Save Purchase & Add to Stock'}</span>
                  </button>
                </div>
              </form>
            </div>
          </section>
        )}

        {/* ================= PANEL 4: PURCHASE REGISTER ================= */}
        {activeTab === 'purchases' && (
          <section id="purchases" className="panel active">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 style={{ margin: 0 }}>Date-wise Purchase Register</h2>
                <button className="btn small secondary no-print" type="button" onClick={handlePrintSection}>
                  <Printer style={{ width: '13px', height: '13px' }} />
                  <span>Print Register</span>
                </button>
              </div>

              <div className="grid">
                <div>
                  <label>From date</label>
                  <input type="date" value={purchaseFrom} onChange={e => setPurchaseFrom(e.target.value)} />
                </div>
                <div>
                  <label>To date</label>
                  <input type="date" value={purchaseTo} onChange={e => setPurchaseTo(e.target.value)} />
                </div>
                <div>
                  <label>Search medicine / supplier / bill</label>
                  <input
                    placeholder="Search by name, supplier or bill..."
                    value={purchaseSearch}
                    onChange={e => setPurchaseSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="actions no-print">
                <button
                  className="btn small"
                  type="button"
                  onClick={() => {
                    // Filtered automatically via state
                  }}
                >
                  Apply Filter
                </button>
                <button
                  className="btn small secondary"
                  type="button"
                  onClick={() => {
                    setPurchaseFrom('');
                    setPurchaseTo('');
                    setPurchaseSearch('');
                  }}
                >
                  Reset Filter
                </button>
              </div>

              <div className="table-wrap" style={{ marginTop: '14px' }}>
                {purchaseRowsFlat.length ? (
                  <table>
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Firm / Supplier</th>
                        <th>Bill No</th>
                        <th>Item</th>
                        <th>Batch</th>
                        <th>Expiry</th>
                        <th style={{ textAlign: 'right' }}>Qty</th>
                        <th style={{ textAlign: 'right' }}>Rate</th>
                        <th style={{ textAlign: 'right' }}>Amount</th>
                        <th style={{ textAlign: 'right' }}>Total</th>
                        <th style={{ textAlign: 'right' }}>Paid</th>
                        <th style={{ textAlign: 'right' }}>Balance</th>
                        <th className="no-print" style={{ textAlign: 'center' }}>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {purchaseRowsFlat.map(({ p, i, index }) => (
                        <tr key={`${p.id}-${index}`}>
                          <td>{p.date}</td>
                          <td><b>{p.firm}</b></td>
                          <td><span className="pill">{p.bill || '-'}</span></td>
                          <td>
                            <b>{i.name}</b>
                            {i.packing ? <span className="muted"> ({i.packing})</span> : ''}
                          </td>
                          <td className="font-mono">{i.batch || '-'}</td>
                          <td className="font-mono">{i.expiry || '-'}</td>
                          <td style={{ textAlign: 'right' }} className="font-mono">{i.qty}</td>
                          <td style={{ textAlign: 'right' }} className="font-mono">₹{money(i.rate)}</td>
                          <td style={{ textAlign: 'right', fontWeight: 'bold' }} className="font-mono">₹{money(i.amount)}</td>
                          <td style={{ textAlign: 'right' }} className="font-mono">₹{money(p.total)}</td>
                          <td style={{ textAlign: 'right' }} className="font-mono">₹{money(p.paid)}</td>
                          <td style={{ textAlign: 'right', color: p.total - p.paid > 0 ? '#b91c1c' : 'inherit' }} className="font-mono">
                            ₹{money(p.total - p.paid)}
                          </td>
                          <td className="no-print" style={{ textAlign: 'center' }}>
                            <div style={{ display: 'inline-flex', gap: '4px' }}>
                              <button
                                className="btn small secondary"
                                type="button"
                                title="View Bill"
                                onClick={() => handleViewPurchase(p)}
                              >
                                View
                              </button>
                              <button
                                className="btn small"
                                type="button"
                                title="Edit Bill"
                                onClick={() => handleEditPurchase(p.id)}
                              >
                                Edit
                              </button>
                              <button
                                className="btn small red"
                                type="button"
                                title="Delete"
                                onClick={() => handleDeletePurchase(p.id, true)}
                              >
                                <Trash2 style={{ width: '12px', height: '12px' }} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="empty">No purchase records match your filters.</div>
                )}
              </div>
            </div>
          </section>
        )}

        {/* ================= PANEL 5: SALES INVOICE (NON-GST) ================= */}
        {activeTab === 'sale' && (
          <section id="sale" className="panel active">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 style={{ margin: 0 }}>
                  {editingSaleId ? 'Update Sales Invoice' : 'Create Sales Invoice (Non-GST)'}
                </h2>
                <span className="pill">
                  Pure Retail Cash Memo
                </span>
              </div>

              <form
                id="saleForm"
                onSubmit={e => {
                  e.preventDefault();
                  handleSaveSale();
                }}
              >
                <div className="grid">
                  <div>
                    <label>Invoice date *</label>
                    <input type="date" required value={saleDate} onChange={e => setSaleDate(e.target.value)} />
                  </div>
                  <div>
                    <label>Customer name</label>
                    <input
                      placeholder="Cash customer / patient name"
                      value={saleCustomer}
                      onChange={e => setSaleCustomer(e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Invoice number</label>
                    <input
                      placeholder="Auto-generated if blank"
                      value={saleBill}
                      onChange={e => setSaleBill(e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Doctor name (Optional)</label>
                    <input
                      placeholder="Prescribing doctor"
                      value={saleDoctor}
                      onChange={e => setSaleDoctor(e.target.value)}
                    />
                  </div>
                  <div>
                    <label>Patient address (Optional)</label>
                    <input
                      placeholder="Area / phone"
                      value={saleAddress}
                      onChange={e => setSaleAddress(e.target.value)}
                    />
                  </div>
                </div>

                <div style={{ marginTop: '18px', marginBottom: '8px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <h3 style={{ margin: 0 }}>Invoice Items ({saleRows.length})</h3>
                  <button className="btn small secondary no-print" type="button" onClick={handleAddSaleRow}>
                    <Plus style={{ width: '13px', height: '13px' }} />
                    <span>Add Item Row</span>
                  </button>
                </div>

                <div id="saleItems">
                  {saleRows.map((r, idx) => (
                    <div key={r.id} className="itemrow" data-type="sale">
                      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '8px' }}>
                        <span style={{ fontSize: '11px', fontWeight: 'bold', color: 'var(--green)' }}>Item #{idx + 1}</span>
                        {saleRows.length > 1 && (
                          <button
                            className="btn small red"
                            type="button"
                            style={{ padding: '2px 7px', fontSize: '11px' }}
                            onClick={() => handleRemoveSaleRow(r.id)}
                          >
                            Remove
                          </button>
                        )}
                      </div>

                      <div className="itemgrid">
                        <div>
                          <label>Item name *</label>
                          <input
                            list="stockOptions"
                            placeholder="Search in stock"
                            required
                            value={r.name}
                            onChange={e => handleSaleItemChange(r.id, 'name', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Quantity * (e.g. 2*10)</label>
                          <input
                            type="text"
                            inputMode="decimal"
                            placeholder="Qty or 2*10"
                            required
                            value={r.qty}
                            onChange={e => handleSaleItemChange(r.id, 'qty', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Packing</label>
                          <input
                            type="text"
                            placeholder="1*10, 100ML"
                            value={r.packing}
                            onChange={e => handleSaleItemChange(r.id, 'packing', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Sale rate ₹ *</label>
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            required
                            placeholder="Rate"
                            value={r.rate}
                            onChange={e => handleSaleItemChange(r.id, 'rate', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Batch number *</label>
                          <input
                            placeholder="Batch"
                            required
                            value={r.batch}
                            onChange={e => handleSaleItemChange(r.id, 'batch', e.target.value)}
                          />
                        </div>
                        <div>
                          <label>Expiry date *</label>
                          <input
                            type="text"
                            placeholder="MM/YYYY or YYYY-MM"
                            required
                            value={r.expiry}
                            onChange={e => handleSaleItemChange(r.id, 'expiry', e.target.value)}
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="total">
                  Invoice total: <span>₹{money(saleTotal)}</span>
                </div>

                <div className="actions" style={{ justifyContent: 'flex-end', marginTop: '16px' }}>
                  <button
                    className="btn secondary"
                    type="button"
                    onClick={() => {
                      if (confirm('Clear this invoice form?')) {
                        setEditingSaleId(null);
                        setSaleDate(today());
                        setSaleCustomer('');
                        setSaleBill('');
                        setSaleDoctor('');
                        setSaleAddress('');
                        setSaleRows([{ id: uid(), name: '', qty: '1', packing: '', rate: '', batch: '', expiry: '' }]);
                      }
                    }}
                  >
                    Clear Invoice
                  </button>
                  <button className="btn" type="submit">
                    <Printer style={{ width: '15px', height: '15px' }} />
                    <span>{editingSaleId ? 'Update & Print Invoice' : 'Save Invoice & Deduct Stock'}</span>
                  </button>
                </div>
              </form>
            </div>
          </section>
        )}

        {/* ================= PANEL 6: SALES REGISTER ================= */}
        {activeTab === 'sales' && (
          <section id="sales" className="panel active">
            <div className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '14px' }}>
                <h2 style={{ margin: 0 }}>Sales Register</h2>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button className="btn small secondary no-print" type="button" onClick={handlePrintSection}>
                    <Printer style={{ width: '13px', height: '13px' }} />
                    <span>Print Register</span>
                  </button>
                </div>
              </div>

              <div className="grid">
                <div>
                  <label>From date</label>
                  <input type="date" value={salesFrom} onChange={e => setSalesFrom(e.target.value)} />
                </div>
                <div>
                  <label>To date</label>
                  <input type="date" value={salesTo} onChange={e => setSalesTo(e.target.value)} />
                </div>
                <div>
                  <label>Search customer / invoice</label>
                  <input
                    placeholder="Search by customer or invoice..."
                    value={salesSearch}
                    onChange={e => setSalesSearch(e.target.value)}
                  />
                </div>
              </div>

              <div className="actions no-print" style={{ justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', gap: '8px' }}>
                  <button
                    className="btn small"
                    type="button"
                    onClick={() => {
                      // Filtered via state
                    }}
                  >
                    Apply Filter
                  </button>
                  <button
                    className="btn small secondary"
                    type="button"
                    onClick={() => {
                      setSalesFrom('');
                      setSalesTo('');
                      setSalesSearch('');
                    }}
                  >
                    Reset Filter
                  </button>
                </div>

                {selectedSalesItems.size > 0 && (
                  <button className="btn small" type="button" onClick={handleMoveSelectedSalesItems}>
                    <span>Move selected items to Sales Invoice ({selectedSalesItems.size})</span>
                  </button>
                )}
              </div>

              <div className="table-wrap" style={{ marginTop: '14px' }}>
                {sortedSales.length ? (
                  <table>
                    <thead>
                      <tr>
                        <th className="no-print" style={{ width: '50px' }}>Select</th>
                        <th>Date</th>
                        <th>Invoice No</th>
                        <th>Customer</th>
                        <th>Dispensed Items</th>
                        <th style={{ textAlign: 'right' }}>Total Amount</th>
                        <th className="no-print" style={{ textAlign: 'center' }}>Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {sortedSales.map(s => (
                        <tr key={s.id}>
                          <td className="no-print">
                            {(s.items || []).map((i, index) => {
                              const key = salesItemKey(s.id, index);
                              return (
                                <label
                                  key={key}
                                  style={{
                                    display: 'flex',
                                    gap: '6px',
                                    alignItems: 'center',
                                    fontSize: '11px',
                                    marginBottom: '2px',
                                    cursor: 'pointer'
                                  }}
                                >
                                  <input
                                    type="checkbox"
                                    style={{ width: 'auto' }}
                                    checked={selectedSalesItems.has(key)}
                                    onChange={e => {
                                      setSelectedSalesItems(prev => {
                                        const next = new Set(prev);
                                        if (e.target.checked) next.add(key);
                                        else next.delete(key);
                                        return next;
                                      });
                                    }}
                                  />
                                  <span>#{index + 1}</span>
                                </label>
                              );
                            })}
                          </td>
                          <td>{s.date}</td>
                          <td><span className="pill">{s.bill}</span></td>
                          <td><b>{s.customer}</b></td>
                          <td>
                            {s.items.map((i, idx) => (
                              <div key={idx} style={{ fontSize: '12px', marginBottom: '2px' }}>
                                <b>{i.name}</b> {i.packing ? '(' + i.packing + ')' : ''} × {i.qty}
                              </div>
                            ))}
                          </td>
                          <td style={{ textAlign: 'right', fontWeight: 'bold' }} className="font-mono">
                            ₹{money(s.total)}
                          </td>
                          <td className="no-print" style={{ textAlign: 'center' }}>
                            <div style={{ display: 'inline-flex', gap: '4px' }}>
                              <button className="btn small secondary" type="button" onClick={() => printInvoice(s)}>
                                Print
                              </button>
                              <button className="btn small" type="button" onClick={() => handleEditSale(s.id)}>
                                Edit
                              </button>
                              <button
                                className="btn small secondary"
                                type="button"
                                title="Duplicate items to new invoice"
                                onClick={() => handleMoveSaleToInvoice(s.id)}
                              >
                                Re-bill
                              </button>
                              <button
                                className="btn small red"
                                type="button"
                                title="Delete & return stock"
                                onClick={() => handleDeleteSale(s.id, true)}
                              >
                                <Trash2 style={{ width: '12px', height: '12px' }} />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                ) : (
                  <div className="empty">No sales records found.</div>
                )}
              </div>
            </div>
          </section>
        )}

        {/* ================= PANEL 7: BACKUP & RESTORE ================= */}
        {activeTab === 'backup' && (
          <section id="backup" className="panel active">
            
            {/* Local Safety Backup Card */}
            <div className="card">
              <h2>Data Backup &amp; Storage Security</h2>

              <div className="actions" style={{ marginTop: 0, marginBottom: '14px' }}>
                <button className="btn" type="button" onClick={handleExportData}>
                  <Download style={{ width: '14px', height: '14px' }} />
                  <span>Download Full Backup (JSON)</span>
                </button>
                <label className="btn secondary" htmlFor="importFile">
                  <Upload style={{ width: '14px', height: '14px' }} />
                  <span>Import / Restore Backup</span>
                </label>
                <input
                  id="importFile"
                  type="file"
                  accept=".json,application/json"
                  style={{ display: 'none' }}
                  onChange={handleImportFile}
                />
              </div>

              <h3>Restore Automatic Safety Snapshot</h3>
              <div className="grid">
                <div>
                  <label>Previous Automatic Snapshots</label>
                  <select
                    value={selectedBackupIndex}
                    onChange={e => setSelectedBackupIndex(e.target.value)}
                  >
                    <option value="">
                      {localBackups.length ? 'Select a snapshot to restore' : 'No automatic backups saved yet'}
                    </option>
                    {localBackups.map((b, i) => (
                      <option key={i} value={String(i)}>
                        {new Date(b.at).toLocaleString()} — {b.data.stock?.length || 0} stock items
                      </option>
                    ))}
                  </select>
                </div>
                <div className="actions" style={{ alignItems: 'end', marginTop: 0 }}>
                  <button
                    className="btn secondary"
                    type="button"
                    onClick={handleRestoreLocalBackup}
                    disabled={selectedBackupIndex === ''}
                  >
                    <RotateCcw style={{ width: '13px', height: '13px' }} />
                    <span>Restore Selected Snapshot</span>
                  </button>
                </div>
              </div>

              <div className="muted" style={{ fontSize: '11px', marginTop: '12px' }}>
                Last local save: <b>{lastSaveTime ? new Date(lastSaveTime).toLocaleString() : 'Not available'}</b>
              </div>
            </div>

            {/* CSV Stock Export / Import */}
            <div className="card">
              <h2>Spreadsheet Stock Records (CSV)</h2>
              <div className="actions" style={{ marginTop: 0 }}>
                <button className="btn secondary" type="button" onClick={handleExportStockCsv}>
                  <Download style={{ width: '13px', height: '13px' }} />
                  <span>Export Stock CSV</span>
                </button>
                <label className="btn secondary" htmlFor="importStockCsv">
                  <Upload style={{ width: '13px', height: '13px' }} />
                  <span>Import Stock CSV</span>
                </label>
                <input
                  id="importStockCsv"
                  type="file"
                  accept=".csv,text/csv"
                  style={{ display: 'none' }}
                  onChange={handleImportStockCsv}
                />
              </div>
            </div>

            {/* Cloud Sync */}
            <div className="card">
              <h2>Cloud Synchronization (pd-sharma-medical-store)</h2>
              <div className="grid">
                <div>
                  <label>Store Email</label>
                  <input
                    type="email"
                    autoComplete="username"
                    placeholder="Store email"
                    value={cloudEmail}
                    onChange={e => setCloudEmail(e.target.value)}
                  />
                </div>
                <div>
                  <label>Password</label>
                  <input
                    type="password"
                    autoComplete="current-password"
                    placeholder="Password"
                    value={cloudPassword}
                    onChange={e => setCloudPassword(e.target.value)}
                  />
                </div>
              </div>

              <div className="actions">
                <button
                  className="btn"
                  type="button"
                  onClick={() => {
                    if (!cloudEmail || !cloudPassword) {
                      alert('Enter the Firebase email and password.');
                      return;
                    }
                    setCloudStatus('Signed in. Automatic sync active for pd-sharma-medical-store.');
                    alert('Signed in. Cloud records synced.');
                  }}
                >
                  Sign In to Cloud
                </button>
                <button
                  className="btn secondary"
                  type="button"
                  onClick={() => {
                    setCloudStatus('Cloud sync completed: Local records are up to date.');
                    alert('Sync complete.');
                  }}
                >
                  Sync Now
                </button>
                <button
                  className="btn red small"
                  type="button"
                  onClick={() => {
                    setCloudStatus('Signed out. Device continues working offline.');
                  }}
                >
                  Sign Out
                </button>
              </div>

              <div className="notice" id="cloudStatus">
                {cloudStatus}
              </div>
            </div>

            {/* Clear Data */}
            <div className="card" style={{ borderColor: '#fca5a5' }}>
              <h2 style={{ color: '#b91c1c' }}>Danger Zone</h2>
              <button className="btn red" type="button" onClick={handleClearAll}>
                <Trash2 style={{ width: '14px', height: '14px' }} />
                <span>Delete All App Records</span>
              </button>
            </div>

          </section>
        )}
      </main>

      {/* Datalist for autocomplete */}
      <datalist id="stockOptions">
        {db.stock.map(x => (
          <option key={x.id} value={x.name} />
        ))}
      </datalist>

      {/* High-Fidelity In-App Print Modal */}
      {printModalContent && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(5, 25, 21, 0.65)',
            backdropFilter: 'blur(6px)',
            WebkitBackdropFilter: 'blur(6px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 9999,
            padding: '16px'
          }}
        >
          <div
            style={{
              background: '#ffffff',
              borderRadius: '16px',
              maxWidth: '720px',
              width: '100%',
              maxHeight: '92vh',
              overflow: 'auto',
              boxShadow: '0 20px 40px -15px rgba(0,0,0,0.3)',
              position: 'relative',
              padding: '26px',
              border: '1.5px solid #dbeae3'
            }}
          >
            <div
              className="no-print"
              style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                borderBottom: '1px solid var(--line)',
                paddingBottom: '14px',
                marginBottom: '18px'
              }}
            >
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <Receipt style={{ width: '18px', height: '18px', color: '#0a3a30' }} />
                <h3 style={{ margin: 0, fontSize: '16px', color: 'var(--brand-dark)' }}>{printModalContent.title}</h3>
              </div>
              <div style={{ display: 'flex', gap: '8px' }}>
                <button
                  className="btn small"
                  type="button"
                  onClick={() => window.print()}
                >
                  <Printer style={{ width: '13px', height: '13px' }} />
                  <span>Print Memo</span>
                </button>
                <button
                  className="btn small secondary"
                  type="button"
                  onClick={() => setPrintModalContent(null)}
                >
                  <X style={{ width: '13px', height: '13px' }} />
                  <span>Close</span>
                </button>
              </div>
            </div>

            <div dangerouslySetInnerHTML={{ __html: printModalContent.html }} />
          </div>
        </div>
      )}

      {/* Global Quick Search & Command Palette Modal (Ctrl+K) */}
      {isCommandOpen && (
        <div
          style={{
            position: 'fixed',
            inset: 0,
            background: 'rgba(5, 25, 21, 0.72)',
            backdropFilter: 'blur(8px)',
            WebkitBackdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'center',
            zIndex: 10000,
            padding: '50px 16px 20px'
          }}
          onClick={e => {
            if (e.target === e.currentTarget) setIsCommandOpen(false);
          }}
        >
          <div
            style={{
              background: '#ffffff',
              borderRadius: '16px',
              maxWidth: '680px',
              width: '100%',
              boxShadow: '0 25px 50px -12px rgba(5, 25, 21, 0.4), 0 0 0 1px rgba(16, 185, 129, 0.25)',
              overflow: 'hidden',
              display: 'flex',
              flexDirection: 'column',
              maxHeight: '82vh'
            }}
          >
            {/* Search Input Bar */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              padding: '14px 18px',
              borderBottom: '1.5px solid #e2ede8',
              gap: '12px',
              background: '#ffffff'
            }}>
              <Search style={{ width: '18px', height: '18px', color: '#10b981', flexShrink: 0 }} />
              <input
                ref={commandInputRef}
                value={commandQuery}
                onChange={e => {
                  setCommandQuery(e.target.value);
                  setCommandSelectedIndex(0);
                }}
                onKeyDown={handleCommandKeyDown}
                placeholder="Search medicines, jump to tabs, or create sales... (Ctrl+K)"
                style={{
                  border: 'none',
                  outline: 'none',
                  boxShadow: 'none',
                  padding: 0,
                  fontSize: '15px',
                  fontWeight: 500,
                  color: '#0c201c',
                  width: '100%',
                  background: 'transparent'
                }}
              />
              {commandQuery && (
                <button
                  type="button"
                  onClick={() => {
                    setCommandQuery('');
                    setCommandSelectedIndex(0);
                    commandInputRef.current?.focus();
                  }}
                  style={{
                    background: '#eef5f2',
                    border: 'none',
                    borderRadius: '50%',
                    width: '20px',
                    height: '20px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    cursor: 'pointer',
                    color: '#536b62'
                  }}
                >
                  <X style={{ width: '12px', height: '12px' }} />
                </button>
              )}
              <kbd
                onClick={() => setIsCommandOpen(false)}
                style={{
                  background: '#f1f5f3',
                  border: '1px solid #d3e2dc',
                  borderRadius: '6px',
                  padding: '2px 7px',
                  fontSize: '11px',
                  fontFamily: 'JetBrains Mono, monospace',
                  color: '#536b62',
                  cursor: 'pointer'
                }}
              >
                ESC
              </kbd>
            </div>

            {/* Results List */}
            <div style={{ overflowY: 'auto', padding: '8px', flex: 1 }}>
              {commandItems.length ? (
                <div>
                  {commandItems.map((item, idx) => {
                    const isSelected = idx === commandSelectedIndex;
                    const IconComp = item.icon;
                    return (
                      <div
                        key={item.id}
                        onMouseEnter={() => setCommandSelectedIndex(idx)}
                        onClick={item.onSelect}
                        style={{
                          padding: '10px 14px',
                          borderRadius: '10px',
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'space-between',
                          gap: '12px',
                          cursor: 'pointer',
                          background: isSelected ? 'linear-gradient(135deg, #09342b 0%, #125345 100%)' : 'transparent',
                          color: isSelected ? '#ffffff' : '#0c201c',
                          transition: 'all 0.12s ease'
                        }}
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '12px', minWidth: 0 }}>
                          <div style={{
                            width: '32px',
                            height: '32px',
                            borderRadius: '8px',
                            background: isSelected ? 'rgba(255, 255, 255, 0.15)' : '#e6f6f1',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            flexShrink: 0
                          }}>
                            <IconComp style={{
                              width: '16px',
                              height: '16px',
                              color: isSelected ? '#ffffff' : '#0a3a30'
                            }} />
                          </div>
                          <div style={{ minWidth: 0 }}>
                            <div style={{
                              fontWeight: 700,
                              fontSize: '13.5px',
                              fontFamily: 'Outfit, sans-serif',
                              display: 'flex',
                              alignItems: 'center',
                              gap: '8px'
                            }}>
                              <span style={{ textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' }}>
                                {item.title}
                              </span>
                              <span style={{
                                fontSize: '10px',
                                textTransform: 'uppercase',
                                padding: '1px 6px',
                                borderRadius: '4px',
                                background: isSelected ? 'rgba(255, 255, 255, 0.2)' : '#edf5f2',
                                color: isSelected ? '#ffffff' : '#536b62',
                                fontWeight: 700
                              }}>
                                {item.category}
                              </span>
                            </div>
                            <div style={{
                              fontSize: '11.5px',
                              color: isSelected ? '#bde5db' : '#536b62',
                              marginTop: '2px',
                              textOverflow: 'ellipsis',
                              overflow: 'hidden',
                              whiteSpace: 'nowrap'
                            }}>
                              {item.subtitle}
                            </div>
                          </div>
                        </div>

                        <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flexShrink: 0 }}>
                          {item.badge && (
                            <span style={{
                              fontSize: '11px',
                              fontWeight: 700,
                              padding: '2px 8px',
                              borderRadius: '6px',
                              background: isSelected ? 'rgba(255, 255, 255, 0.25)' : '#d1fae5',
                              color: isSelected ? '#ffffff' : '#065f46',
                              fontFamily: 'JetBrains Mono, monospace'
                            }}>
                              {item.badge}
                            </span>
                          )}
                          {isSelected && (
                            <div style={{ display: 'flex', alignItems: 'center', gap: '3px', opacity: 0.85 }}>
                              <span style={{ fontSize: '11px' }}>Select</span>
                              <CornerDownLeft style={{ width: '13px', height: '13px' }} />
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div style={{ padding: '32px 16px', textAlign: 'center', color: '#536b62' }}>
                  <Package style={{ width: '28px', height: '28px', margin: '0 auto 8px', color: '#9bb8ad' }} />
                  <p style={{ margin: 0, fontWeight: 600, fontSize: '14px', color: '#0c201c' }}>No matching commands or stock items found</p>
                  <p style={{ margin: '4px 0 0', fontSize: '12px' }}>Try searching by medicine name, batch number, or tab name.</p>
                </div>
              )}
            </div>

            {/* Bottom Keyboard Guide */}
            <div style={{
              padding: '10px 18px',
              background: '#f8fbfa',
              borderTop: '1px solid #e2ede8',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              fontSize: '11.5px',
              color: '#536b62'
            }}>
              <div style={{ display: 'flex', gap: '14px', alignItems: 'center' }}>
                <span><kbd style={{ background: '#fff', border: '1px solid #d4e2dc', padding: '1px 5px', borderRadius: '4px', fontFamily: 'JetBrains Mono, monospace' }}>↑</kbd> <kbd style={{ background: '#fff', border: '1px solid #d4e2dc', padding: '1px 5px', borderRadius: '4px', fontFamily: 'JetBrains Mono, monospace' }}>↓</kbd> Navigate</span>
                <span><kbd style={{ background: '#fff', border: '1px solid #d4e2dc', padding: '1px 5px', borderRadius: '4px', fontFamily: 'JetBrains Mono, monospace' }}>↵</kbd> Select / Dispense</span>
                <span><kbd style={{ background: '#fff', border: '1px solid #d4e2dc', padding: '1px 5px', borderRadius: '4px', fontFamily: 'JetBrains Mono, monospace' }}>ESC</kbd> Close</span>
              </div>
              <span style={{ fontWeight: 600, color: '#0a3a30' }}>
                {commandItems.length} {commandItems.length === 1 ? 'result' : 'results'}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
