import { MedicineItem } from '../types/pharmacy';

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatCompactNumber = (num: number): string => {
  return new Intl.NumberFormat('en-IN', {
    notation: 'compact',
    maximumFractionDigits: 1
  }).format(num);
};

export const formatDate = (dateStr: string): string => {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric'
    });
  } catch {
    return dateStr;
  }
};

export const formatDateTime = (dateStr: string): string => {
  try {
    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return dateStr;
    return d.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  } catch {
    return dateStr;
  }
};

export interface ExpiryStatus {
  status: 'expired' | 'critical' | 'near-expiry' | 'safe';
  label: string;
  daysRemaining: number;
  textColor: string;
  badgeBg: string;
}

export const getExpiryStatus = (expiryDateStr: string): ExpiryStatus => {
  if (!expiryDateStr) {
    return { status: 'safe', label: 'Valid', daysRemaining: 999, textColor: 'text-slate-600', badgeBg: 'bg-slate-100 dark:bg-slate-800' };
  }

  // Handle YYYY-MM or YYYY-MM-DD
  const parts = expiryDateStr.split('-');
  const year = parseInt(parts[0], 10);
  const month = parseInt(parts[1], 10);
  // Last day of that expiry month
  const lastDay = new Date(year, month, 0);
  const now = new Date();

  const diffTime = lastDay.getTime() - now.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays <= 0) {
    return {
      status: 'expired',
      label: 'Expired',
      daysRemaining: diffDays,
      textColor: 'text-rose-600 dark:text-rose-400',
      badgeBg: 'bg-rose-50 border border-rose-200 dark:bg-rose-950/40 dark:border-rose-900'
    };
  } else if (diffDays <= 30) {
    return {
      status: 'critical',
      label: `< ${diffDays}d Expiry`,
      daysRemaining: diffDays,
      textColor: 'text-rose-600 dark:text-rose-400',
      badgeBg: 'bg-rose-50 border border-rose-200 dark:bg-rose-950/30 dark:border-rose-800'
    };
  } else if (diffDays <= 90) {
    return {
      status: 'near-expiry',
      label: `Exp in ${Math.ceil(diffDays / 30)}mo`,
      daysRemaining: diffDays,
      textColor: 'text-amber-600 dark:text-amber-400',
      badgeBg: 'bg-amber-50 border border-amber-200 dark:bg-amber-950/30 dark:border-amber-800'
    };
  } else {
    return {
      status: 'safe',
      label: expiryDateStr,
      daysRemaining: diffDays,
      textColor: 'text-emerald-700 dark:text-emerald-400',
      badgeBg: 'bg-emerald-50/50 dark:bg-emerald-950/20'
    };
  }
};

export const numberToWords = (num: number): string => {
  const a = [
    '', 'One ', 'Two ', 'Three ', 'Four ', 'Five ', 'Six ', 'Seven ', 'Eight ', 'Nine ', 'Ten ',
    'Eleven ', 'Twelve ', 'Thirteen ', 'Fourteen ', 'Fifteen ', 'Sixteen ', 'Seventeen ', 'Eighteen ', 'Nineteen '
  ];
  const b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

  const inWords = (n: number): string => {
    let str = '';
    if (n > 9999999) {
      str += inWords(Math.floor(n / 10000000)) + 'Crore ';
      n %= 10000000;
    }
    if (n > 99999) {
      str += inWords(Math.floor(n / 100000)) + 'Lakh ';
      n %= 100000;
    }
    if (n > 999) {
      str += inWords(Math.floor(n / 1000)) + 'Thousand ';
      n %= 1000;
    }
    if (n > 99) {
      str += inWords(Math.floor(n / 100)) + 'Hundred ';
      n %= 100;
    }
    if (n > 19) {
      str += b[Math.floor(n / 10)] + ' ' + a[n % 10];
    } else if (n > 0) {
      str += a[n];
    }
    return str;
  };

  const rounded = Math.round(num);
  if (rounded === 0) return 'Zero Rupees Only';
  return (inWords(rounded).trim() + ' Rupees Only');
};

export const exportToCSV = (medicines: MedicineItem[]): void => {
  const headers = [
    'Name',
    'Generic',
    'Category',
    'Dosage',
    'Manufacturer',
    'Batch No',
    'Expiry (YYYY-MM)',
    'Stock Qty',
    'Min Level',
    'Unit',
    'Pack Size',
    'Cost Price',
    'MRP',
    'Sale Price',
    'GST %',
    'HSN',
    'Schedule',
    'Shelf Rack',
    'Supplier'
  ];

  const rows = medicines.map(m => [
    `"${m.name.replace(/"/g, '""')}"`,
    `"${m.generic.replace(/"/g, '""')}"`,
    `"${m.category}"`,
    `"${m.dosage}"`,
    `"${m.manufacturer.replace(/"/g, '""')}"`,
    `"${m.batchNumber}"`,
    `"${m.expiryDate}"`,
    m.stockQuantity,
    m.minStockLevel,
    `"${m.unit}"`,
    `"${m.packSize}"`,
    m.costPrice,
    m.mrp,
    m.salePrice,
    m.gstRate,
    `"${m.hsnCode}"`,
    `"${m.schedule}"`,
    `"${m.shelfLocation}"`,
    `"${m.supplierName.replace(/"/g, '""')}"`
  ]);

  const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement('a');
  link.setAttribute('href', encodedUri);
  link.setAttribute('download', `pharmakare_inventory_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};
