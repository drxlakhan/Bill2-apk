import React from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { 
  Receipt, 
  Package, 
  Truck, 
  Users, 
  BarChart3, 
  Settings, 
  Sun, 
  Moon, 
  AlertTriangle,
  Plus
} from 'lucide-react';

export type ActiveTab = 'billing' | 'inventory' | 'purchases' | 'khata' | 'analytics' | 'settings';

interface NavbarProps {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  onOpenNewSale: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, onOpenNewSale }) => {
  const { profile, darkMode, toggleDarkMode, lowStockItems, nearExpiryItems, expiredItems } = usePharmacy();
  const totalAlerts = lowStockItems.length + nearExpiryItems.length + expiredItems.length;

  const navItems = [
    { id: 'billing' as ActiveTab, label: 'E-Billing POS', icon: Receipt },
    { id: 'inventory' as ActiveTab, label: 'Stock Inventory', icon: Package, badge: totalAlerts > 0 ? totalAlerts : undefined },
    { id: 'purchases' as ActiveTab, label: 'Distributor Inward', icon: Truck },
    { id: 'khata' as ActiveTab, label: 'Patient Khata', icon: Users },
    { id: 'analytics' as ActiveTab, label: 'Schedule H Reports', icon: BarChart3 },
    { id: 'settings' as ActiveTab, label: 'Store Config', icon: Settings },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Zone 1: Brand Wordmark */}
          <div className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
              <span className="text-xl leading-none">Rx</span>
            </div>
            <div className="flex flex-col">
              <span className="font-bold text-slate-900 dark:text-white text-base tracking-tight leading-none whitespace-nowrap">
                {profile.storeName}
              </span>
              <span className="text-[11px] text-slate-600 dark:text-slate-400 font-mono tracking-tight mt-0.5 leading-none">
                DL: {profile.drugLicenseNo.split('/')[0]?.trim()}
              </span>
            </div>
          </div>

          {/* Zone 2: Navigation Links */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map(item => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md transition-all whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 font-semibold'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                  {item.badge !== undefined && (
                    <span className="ml-1 text-[11px] font-mono px-1.5 py-0.2 rounded bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions & Dark Mode */}
          <div className="flex items-center gap-2.5 shrink-0">
            {/* Quick alert indicator if any critical batch needs attention */}
            {expiredItems.length > 0 && (
              <button
                onClick={() => setActiveTab('inventory')}
                title={`${expiredItems.length} expired medicines in stock! Click to review`}
                className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-rose-700 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-md"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>{expiredItems.length} Expired</span>
              </button>
            )}

            <button
              onClick={toggleDarkMode}
              className="p-2 rounded-md text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              aria-label="Toggle theme"
              title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </button>

            <button
              onClick={onOpenNewSale}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-lg shadow-sm transition-all whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>New Bill (F2)</span>
            </button>
          </div>
        </div>

        {/* Mobile Sub-Navigation Bar */}
        <div className="lg:hidden flex items-center gap-1 overflow-x-auto py-2 border-t border-slate-100 dark:border-slate-800 no-scrollbar">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-slate-100 dark:bg-slate-800 text-emerald-700 dark:text-emerald-400 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
                {item.badge !== undefined && (
                  <span className="text-[10px] font-mono px-1 py-0.2 rounded bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-400">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
