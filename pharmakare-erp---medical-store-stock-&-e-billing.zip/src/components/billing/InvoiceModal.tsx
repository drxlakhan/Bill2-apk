import React, { useState } from 'react';
import { Invoice } from '../../types/pharmacy';
import { usePharmacy } from '../../context/PharmacyContext';
import { formatCurrency, formatDateTime, numberToWords } from '../../utils/formatters';
import { Printer, X, Share2, FileText, Check } from 'lucide-react';

interface InvoiceModalProps {
  invoice: Invoice | null;
  onClose: () => void;
}

export const InvoiceModal: React.FC<InvoiceModalProps> = ({ invoice, onClose }) => {
  const { profile } = usePharmacy();
  const [printFormat, setPrintFormat] = useState<'a4' | 'thermal'>('a4');
  
  // Non-GST vs GST invoice view toggle (defaults to Non-GST as configured)
  const [billType, setBillType] = useState<'NON_GST' | 'GST'>(() => {
    return (invoice?.invoiceType as ('NON_GST' | 'GST')) || profile.defaultInvoiceType || 'NON_GST';
  });

  const [copiedLink, setCopiedLink] = useState(false);

  if (!invoice) return null;

  const handlePrint = () => {
    window.print();
  };

  const isNonGst = billType === 'NON_GST';

  const handleShareWhatsApp = () => {
    const billHeading = isNonGst 
      ? `*${profile.storeName}*\n🧾 *RETAIL CASH MEMO (NON-GST)*` 
      : `*${profile.storeName}*\n🧾 *TAX INVOICE (GST)*`;

    const text = `${billHeading}\n` +
      `Bill No: ${invoice.invoiceNumber}\n` +
      `Date: ${new Date(invoice.date).toLocaleDateString()}\n` +
      `Patient: ${invoice.customerName}\n` +
      (invoice.doctorName ? `Prescribed by: ${invoice.doctorName}\n` : '') +
      `------------------------\n` +
      invoice.items.map(it => `• ${it.name} (${it.quantity} ${it.unit}) - ₹${it.totalAmount.toFixed(2)} [Exp: ${it.expiryDate}]`).join('\n') +
      `\n------------------------\n` +
      `*Grand Total: ₹${invoice.grandTotal.toFixed(2)}* (${invoice.paymentMode})\n` +
      `DL: ${profile.drugLicenseNo}\n` +
      `Thank you! Get well soon.`;

    const encoded = encodeURIComponent(text);
    const url = invoice.customerPhone
      ? `https://wa.me/${invoice.customerPhone.replace(/[^0-9]/g, '')}?text=${encoded}`
      : `https://api.whatsapp.com/send?text=${encoded}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 my-6 overflow-hidden">
        
        {/* Modal Toolbar (hidden on print) */}
        <div className="no-print flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {isNonGst ? 'Non-GST Retail Cash Memo' : 'GST Tax Invoice'}: {invoice.invoiceNumber}
            </span>
            <span className="text-xs text-slate-500 font-mono">
              ({formatDateTime(invoice.date)})
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            
            {/* Bill Mode Switcher: Non-GST vs GST */}
            <div className="inline-flex rounded-lg p-0.5 bg-slate-200 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setBillType('NON_GST')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  isNonGst
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Non-GST Bill
              </button>
              <button
                type="button"
                onClick={() => setBillType('GST')}
                className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors ${
                  !isNonGst
                    ? 'bg-slate-900 dark:bg-slate-700 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                GST Invoice
              </button>
            </div>

            {/* Paper Format Switcher: A4 vs Thermal 80mm */}
            <div className="inline-flex rounded-lg p-0.5 bg-slate-200 dark:bg-slate-800">
              <button
                type="button"
                onClick={() => setPrintFormat('a4')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  printFormat === 'a4'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Standard A4
              </button>
              <button
                type="button"
                onClick={() => setPrintFormat('thermal')}
                className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                  printFormat === 'thermal'
                    ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                80mm POS Slip
              </button>
            </div>

            <button
              onClick={handleShareWhatsApp}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg hover:bg-emerald-100 transition-colors"
              title="Share bill on WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">WhatsApp</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 dark:hover:bg-emerald-500 rounded-lg shadow-xs transition-colors cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print {isNonGst ? 'Non-GST Bill' : 'GST Bill'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Area */}
        <div className="p-6 max-h-[80vh] overflow-y-auto bg-slate-100/50 dark:bg-slate-950/50 flex justify-center">
          
          {/* ================= A4 FORMAT ================= */}
          {printFormat === 'a4' && (
            <div className="print-container w-full max-w-3xl bg-white text-slate-900 p-8 rounded-lg shadow-sm border border-slate-200 print:border-none print:shadow-none print:p-0">
              
              {/* Header Lockup */}
              <div className="border-b-2 border-slate-900 pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xl font-bold font-serif text-emerald-800">Rx</span>
                      <h1 className="text-2xl font-extrabold uppercase tracking-tight text-slate-900">
                        {profile.storeName}
                      </h1>
                    </div>
                    <p className="text-xs text-slate-600 font-medium mt-0.5">{profile.tagline}</p>
                    <p className="text-xs text-slate-600 mt-1">
                      {profile.addressLine1}, {profile.addressLine2}, {profile.cityStateZip}
                    </p>
                    <p className="text-xs text-slate-600">
                      Phone: <span className="font-semibold text-slate-800">{profile.phone}</span>
                      {profile.alternatePhone && ` · Alt: ${profile.alternatePhone}`} · Email: {profile.email}
                    </p>
                  </div>

                  <div className="text-right text-xs space-y-0.5 bg-slate-50 p-2.5 rounded border border-slate-200">
                    <div><span className="font-semibold">D.L. No:</span> <span className="font-mono">{profile.drugLicenseNo}</span></div>
                    {(!isNonGst || profile.showGstinOnBill) && (
                      <div><span className="font-semibold">GSTIN:</span> <span className="font-mono">{profile.gstin}</span></div>
                    )}
                    {isNonGst && !profile.showGstinOnBill && (
                      <div className="text-[11px] text-slate-500 font-medium">Retail Supply (Non-GST)</div>
                    )}
                    <div><span className="font-semibold">FSSAI:</span> <span className="font-mono">{profile.fssai}</span></div>
                    <div className="pt-1 text-[11px] text-emerald-800 font-semibold">
                      Pharmacist: {profile.ownerName} ({profile.pharmacistRegNo})
                    </div>
                  </div>
                </div>

                <div className="mt-3 pt-2 border-t border-dashed border-slate-300 flex justify-between items-center text-xs font-semibold">
                  <div className="flex items-center gap-2">
                    <span className="uppercase text-slate-800 tracking-wider font-bold">
                      {isNonGst ? 'RETAIL CASH MEMO / BILL OF SUPPLY' : 'TAX INVOICE / CASH MEMO'}
                    </span>
                    {isNonGst && (
                      <span className="text-[10px] text-emerald-800 bg-emerald-50 px-1.5 py-0.2 rounded border border-emerald-200 font-normal">
                        Non-GST
                      </span>
                    )}
                  </div>
                  <span className="font-mono bg-slate-100 px-2 py-0.5 rounded text-slate-900">
                    {isNonGst ? 'MEMO NO:' : 'INVOICE NO:'} {invoice.invoiceNumber}
                  </span>
                </div>
              </div>

              {/* Patient & Doctor Meta Grid */}
              <div className="grid grid-cols-2 gap-4 py-3 text-xs border-b border-slate-200">
                <div className="space-y-1">
                  <div><span className="text-slate-500">Patient Name:</span> <span className="font-semibold text-slate-900">{invoice.customerName}</span></div>
                  <div><span className="text-slate-500">Contact No:</span> <span className="font-mono">{invoice.customerPhone || 'N/A'}</span></div>
                  {(invoice.customerAge || invoice.customerGender) && (
                    <div><span className="text-slate-500">Age / Gender:</span> <span>{invoice.customerAge || '-'} Yrs / {invoice.customerGender || '-'}</span></div>
                  )}
                </div>

                <div className="space-y-1 text-right">
                  <div><span className="text-slate-500">Date &amp; Time:</span> <span className="font-mono">{formatDateTime(invoice.date)}</span></div>
                  <div><span className="text-slate-500">Prescribed By:</span> <span className="font-semibold text-slate-900">{invoice.doctorName || 'Self / OTC'}</span></div>
                  {invoice.doctorRegNo && (
                    <div><span className="text-slate-500">Doctor Reg No:</span> <span className="font-mono">{invoice.doctorRegNo}</span></div>
                  )}
                  <div><span className="text-slate-500">Payment Mode:</span> <span className="font-semibold">{invoice.paymentMode}</span></div>
                </div>
              </div>

              {/* Medicine Table (HSN & GST% hidden if Non-GST!) */}
              <table className="w-full text-xs mt-3 border-collapse">
                <thead>
                  <tr className="border-b border-slate-300 text-slate-600 bg-slate-50">
                    <th className="py-2 text-left font-semibold w-8">#</th>
                    <th className="py-2 text-left font-semibold">Medicine Description</th>
                    {!isNonGst && <th className="py-2 text-left font-semibold">HSN</th>}
                    <th className="py-2 text-left font-semibold">Batch</th>
                    <th className="py-2 text-center font-semibold">Exp</th>
                    <th className="py-2 text-right font-semibold">Qty</th>
                    <th className="py-2 text-right font-semibold">MRP</th>
                    <th className="py-2 text-right font-semibold">Rate</th>
                    {!isNonGst && <th className="py-2 text-center font-semibold">GST%</th>}
                    <th className="py-2 text-right font-semibold">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {invoice.items.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/50">
                      <td className="py-2 text-slate-400 font-mono">{idx + 1}</td>
                      <td className="py-2">
                        <div className="font-semibold text-slate-900">{item.name}</div>
                        <div className="text-[11px] text-slate-500 truncate max-w-xs">{item.generic}</div>
                        {item.schedule && item.schedule !== 'OTC' && (
                          <span className="text-[10px] text-amber-800 font-medium">[{item.schedule}]</span>
                        )}
                      </td>
                      {!isNonGst && <td className="py-2 font-mono text-slate-600">{item.hsnCode}</td>}
                      <td className="py-2 font-mono text-slate-700">{item.batchNumber}</td>
                      <td className="py-2 text-center font-mono text-slate-700">{item.expiryDate}</td>
                      <td className="py-2 text-right font-mono font-medium">{item.quantity} {item.unit}</td>
                      <td className="py-2 text-right font-mono text-slate-500">₹{item.mrp.toFixed(2)}</td>
                      <td className="py-2 text-right font-mono font-medium">₹{item.salePrice.toFixed(2)}</td>
                      {!isNonGst && <td className="py-2 text-center font-mono text-slate-600">{item.gstRate}%</td>}
                      <td className="py-2 text-right font-mono font-bold text-slate-900">₹{item.totalAmount.toFixed(2)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {/* Totals & Tax Breakup */}
              <div className="mt-4 pt-3 border-t-2 border-slate-900 grid grid-cols-2 gap-4">
                <div className="text-xs space-y-2">
                  <div className="text-slate-700">
                    <span className="font-semibold">Amount in Words:</span>
                    <p className="font-medium italic text-slate-900 mt-0.5">{numberToWords(invoice.grandTotal)}</p>
                  </div>

                  {/* GST summary only shown in GST mode */}
                  {!isNonGst ? (
                    <div className="bg-slate-50 p-2 rounded border border-slate-200 text-[11px]">
                      <div className="font-semibold text-slate-700 mb-1">Tax Breakdown (GST Compliant):</div>
                      <div className="flex justify-between text-slate-600 font-mono">
                        <span>Taxable: ₹{invoice.taxableAmount.toFixed(2)}</span>
                        <span>CGST: ₹{invoice.totalCgst.toFixed(2)}</span>
                        <span>SGST: ₹{invoice.totalSgst.toFixed(2)}</span>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-emerald-50/60 p-2 rounded border border-emerald-200/80 text-[11px] text-emerald-900">
                      <span className="font-semibold">Non-GST Medical Retail Memo:</span>
                      <p className="text-[10px] text-emerald-800 mt-0.5">
                        Supply under Composition / Non-GST Retail Scheme. Not eligible to charge separate tax.
                      </p>
                    </div>
                  )}

                  {invoice.notes && (
                    <div className="text-[11px] text-slate-500">
                      <span className="font-semibold">Notes:</span> {invoice.notes}
                    </div>
                  )}
                </div>

                <div className="space-y-1.5 text-xs text-right">
                  <div className="flex justify-between text-slate-600">
                    <span>Subtotal:</span>
                    <span className="font-mono">₹{invoice.subtotal.toFixed(2)}</span>
                  </div>
                  {invoice.totalDiscount > 0 && (
                    <div className="flex justify-between text-emerald-700">
                      <span>Special Discount:</span>
                      <span className="font-mono">-₹{invoice.totalDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  {!isNonGst && (
                    <div className="flex justify-between text-slate-600">
                      <span>Applicable GST (Included):</span>
                      <span className="font-mono">₹{invoice.totalGst.toFixed(2)}</span>
                    </div>
                  )}
                  {invoice.roundOff !== 0 && (
                    <div className="flex justify-between text-slate-500">
                      <span>Round Off:</span>
                      <span className="font-mono">{invoice.roundOff > 0 ? `+₹${invoice.roundOff.toFixed(2)}` : `-₹${Math.abs(invoice.roundOff).toFixed(2)}`}</span>
                    </div>
                  )}
                  <div className="flex justify-between pt-2 border-t border-slate-300 text-sm font-extrabold text-slate-900">
                    <span>NET PAYABLE:</span>
                    <span className="font-mono text-base">{formatCurrency(invoice.grandTotal)}</span>
                  </div>
                  {invoice.paymentMode === 'Cash' && invoice.cashTendered && (
                    <div className="text-[11px] text-slate-600 pt-1">
                      Cash Tendered: ₹{invoice.cashTendered} · Change Return: ₹{invoice.changeDue || 0}
                    </div>
                  )}
                </div>
              </div>

              {/* Terms & Signatures */}
              <div className="mt-8 pt-4 border-t border-dashed border-slate-300 flex justify-between items-end text-[11px] text-slate-500">
                <div className="max-w-md space-y-0.5">
                  <span className="font-semibold text-slate-700 block">Terms &amp; Conditions:</span>
                  {profile.billTerms.slice(0, 3).map((term, i) => (
                    <p key={i}>• {term}</p>
                  ))}
                </div>

                <div className="text-center">
                  <div className="w-36 border-b border-slate-900 pb-8 text-slate-400 italic">
                    [Seal &amp; Signature]
                  </div>
                  <div className="font-semibold text-slate-800 mt-1">For {profile.storeName}</div>
                  <div className="text-[10px] text-slate-500">Authorized Pharmacist</div>
                </div>
              </div>

            </div>
          )}

          {/* ================= 80MM POS THERMAL FORMAT ================= */}
          {printFormat === 'thermal' && (
            <div className="print-container w-[80mm] max-w-full bg-white text-slate-900 p-4 font-mono text-[11px] shadow-sm border border-slate-300 print:border-none print:shadow-none print:p-0">
              <div className="text-center pb-2 border-b border-black">
                <div className="text-sm font-bold uppercase">{profile.storeName}</div>
                <div className="text-[10px]">{profile.addressLine1}</div>
                <div className="text-[10px]">{profile.cityStateZip}</div>
                <div className="text-[10px]">Ph: {profile.phone}</div>
                <div className="text-[9px] mt-1">DL: {profile.drugLicenseNo}</div>
                {(!isNonGst || profile.showGstinOnBill) && (
                  <div className="text-[9px]">GSTIN: {profile.gstin}</div>
                )}
                {isNonGst && (
                  <div className="text-[10px] font-bold mt-1 uppercase border-t border-b border-black py-0.5">
                    *** RETAIL CASH MEMO (NON-GST) ***
                  </div>
                )}
              </div>

              <div className="py-2 border-b border-dashed border-black text-[10px] space-y-0.5">
                <div className="flex justify-between">
                  <span>Bill: {invoice.invoiceNumber}</span>
                  <span>{new Date(invoice.date).toLocaleDateString()}</span>
                </div>
                <div>Pt: {invoice.customerName} {invoice.customerPhone ? `(${invoice.customerPhone.slice(-4)})` : ''}</div>
                {invoice.doctorName && <div>Doc: {invoice.doctorName}</div>}
              </div>

              {/* Items List */}
              <div className="py-2 border-b border-black">
                <div className="flex justify-between font-bold border-b border-dashed border-black pb-1 mb-1 text-[10px]">
                  <span>ITEM</span>
                  <span>QTY x RATE</span>
                  <span>AMT</span>
                </div>
                {invoice.items.map((item, idx) => (
                  <div key={idx} className="mb-1 text-[10px]">
                    <div className="font-semibold truncate">{item.name}</div>
                    <div className="flex justify-between text-slate-600 text-[9px]">
                      <span>B:{item.batchNumber} E:{item.expiryDate}</span>
                      <span>{item.quantity} x {item.salePrice}</span>
                      <span className="font-semibold text-black">₹{item.totalAmount.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* Summary */}
              <div className="py-2 space-y-1 text-[11px] border-b border-black">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>₹{invoice.subtotal.toFixed(2)}</span>
                </div>
                {invoice.totalDiscount > 0 && (
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-₹{invoice.totalDiscount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between font-bold text-sm pt-1 border-t border-dashed border-black">
                  <span>NET TOTAL:</span>
                  <span>₹{invoice.grandTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-[10px] text-slate-600">
                  <span>Mode: {invoice.paymentMode}</span>
                  {invoice.cashTendered && <span>Bal: ₹{invoice.changeDue}</span>}
                </div>
              </div>

              <div className="text-center pt-2 text-[9px] text-slate-600">
                <p>{isNonGst ? 'Pure Retail Cash Memo. Consult Doc before use.' : 'Tax Included in MRP. Consult Doc before use.'}</p>
                <p className="font-semibold text-black mt-1">*** GET WELL SOON ***</p>
                <p>Pharmacist: {profile.ownerName}</p>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
