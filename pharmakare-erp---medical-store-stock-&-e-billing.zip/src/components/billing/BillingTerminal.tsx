import React, { useState, useEffect, useRef } from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { MedicineItem, InvoiceItem, Invoice } from '../../types/pharmacy';
import { formatCurrency, getExpiryStatus } from '../../utils/formatters';
import { 
  Search, 
  Trash2, 
  Plus, 
  Minus, 
  CheckCircle2, 
  AlertCircle, 
  QrCode, 
  Receipt, 
  User, 
  Phone, 
  Stethoscope, 
  CreditCard, 
  Banknote, 
  Clock, 
  FileText,
  RotateCcw
} from 'lucide-react';

interface BillingTerminalProps {
  onViewInvoice: (invoice: Invoice) => void;
}

export const BillingTerminal: React.FC<BillingTerminalProps> = ({ onViewInvoice }) => {
  const { medicines, createInvoice, profile, invoices, khataList } = usePharmacy();

  // Search & Cart state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedMedicine, setSelectedMedicine] = useState<MedicineItem | null>(null);
  const [cartItems, setCartItems] = useState<InvoiceItem[]>([]);
  const [focusedIndex, setFocusedIndex] = useState(0);

  // Customer & Doctor info
  const [customerName, setCustomerName] = useState('Counter Walk-in');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerAge, setCustomerAge] = useState('');
  const [customerGender, setCustomerGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [doctorName, setDoctorName] = useState('');
  const [doctorRegNo, setDoctorRegNo] = useState('');

  // Discount & Payment
  const [billType, setBillType] = useState<'NON_GST' | 'GST'>(profile.defaultInvoiceType || 'NON_GST');
  const [overallDiscountPercent, setOverallDiscountPercent] = useState<number>(0);
  const [paymentMode, setPaymentMode] = useState<'Cash' | 'UPI' | 'Card' | 'Credit/Khata'>('Cash');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [showUpiModal, setShowUpiModal] = useState(false);
  const [notes, setNotes] = useState('');

  const searchInputRef = useRef<HTMLInputElement>(null);

  // Hotkey listener (F2 to focus search, F9 to finalize checkout)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F2') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filter search results
  const searchResults = searchQuery.trim() === ''
    ? []
    : medicines
        .filter(m => 
          m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          m.generic.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (m.barcode && m.barcode.includes(searchQuery)) ||
          m.batchNumber.toLowerCase().includes(searchQuery.toLowerCase())
        )
        .slice(0, 6);

  // Check if cart has Schedule H or H1 medicines
  const hasScheduleHDrugs = cartItems.some(item => item.schedule === 'Schedule H' || item.schedule === 'Schedule H1' || item.schedule === 'Schedule X');

  // Add medicine to cart
  const handleAddToCart = (med: MedicineItem) => {
    if (med.stockQuantity <= 0) {
      alert(`Cannot add ${med.name}: Stock is zero!`);
      return;
    }

    const existingIndex = cartItems.findIndex(i => i.medicineId === med.id && i.batchNumber === med.batchNumber);
    if (existingIndex > -1) {
      const current = cartItems[existingIndex];
      if (current.quantity + 1 > med.stockQuantity) {
        alert(`Only ${med.stockQuantity} units available in stock for batch ${med.batchNumber}!`);
        return;
      }
      const updated = [...cartItems];
      const newQty = current.quantity + 1;
      const totalAmount = newQty * current.salePrice * (1 - (current.discountPercent / 100));
      updated[existingIndex] = {
        ...current,
        quantity: newQty,
        totalAmount
      };
      setCartItems(updated);
    } else {
      const newItem: InvoiceItem = {
        medicineId: med.id,
        name: med.name,
        generic: med.generic,
        dosage: med.dosage,
        category: med.category,
        batchNumber: med.batchNumber,
        expiryDate: med.expiryDate,
        quantity: 1,
        unit: med.unit,
        packSize: med.packSize,
        mrp: med.mrp,
        salePrice: med.salePrice,
        discountPercent: overallDiscountPercent,
        gstRate: med.gstRate,
        hsnCode: med.hsnCode,
        schedule: med.schedule,
        totalAmount: med.salePrice * (1 - (overallDiscountPercent / 100))
      };
      setCartItems([newItem, ...cartItems]);
    }

    setSearchQuery('');
    setSelectedMedicine(null);
    searchInputRef.current?.focus();
  };

  const handleUpdateQuantity = (index: number, delta: number) => {
    const item = cartItems[index];
    const med = medicines.find(m => m.id === item.medicineId);
    const maxStock = med ? med.stockQuantity : 999;
    const newQty = item.quantity + delta;

    if (newQty <= 0) {
      handleRemoveItem(index);
      return;
    }
    if (newQty > maxStock) {
      alert(`Max available stock is ${maxStock}`);
      return;
    }

    const updated = [...cartItems];
    const totalAmount = newQty * item.salePrice * (1 - (item.discountPercent / 100));
    updated[index] = {
      ...item,
      quantity: newQty,
      totalAmount
    };
    setCartItems(updated);
  };

  const handleItemDiscountChange = (index: number, disc: number) => {
    const updated = [...cartItems];
    const item = updated[index];
    const discountPercent = Math.min(100, Math.max(0, disc));
    const totalAmount = item.quantity * item.salePrice * (1 - (discountPercent / 100));
    updated[index] = {
      ...item,
      discountPercent,
      totalAmount
    };
    setCartItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    setCartItems(cartItems.filter((_, i) => i !== index));
  };

  // Calculations
  const mrpSubtotal = cartItems.reduce((sum, item) => sum + (item.mrp * item.quantity), 0);
  const itemsSubtotal = cartItems.reduce((sum, item) => sum + (item.salePrice * item.quantity), 0);
  const netAmount = cartItems.reduce((sum, item) => sum + item.totalAmount, 0);
  const totalSavings = mrpSubtotal - netAmount;

  // Approximate GST (assuming sale prices are tax inclusive, calculate reverse tax)
  const taxableAmount = cartItems.reduce((sum, item) => {
    const gstFactor = 1 + (item.gstRate / 100);
    return sum + (item.totalAmount / gstFactor);
  }, 0);
  const totalGst = netAmount - taxableAmount;
  const totalCgst = totalGst / 2;
  const totalSgst = totalGst / 2;

  const grandTotal = Math.round(netAmount);
  const roundOff = Number((grandTotal - netAmount).toFixed(2));

  const changeDue = cashTendered ? Math.max(0, parseFloat(cashTendered) - grandTotal) : 0;

  // Checkout submission
  const handleCheckout = () => {
    if (cartItems.length === 0) {
      alert('Cart is empty! Please add medicines first.');
      return;
    }

    if (hasScheduleHDrugs && !doctorName.trim()) {
      const confirmDoc = window.confirm(
        'Warning: Schedule H/H1 medicine is included. Drug authorities require prescribing Doctor Details. Proceed without doctor info?'
      );
      if (!confirmDoc) return;
    }

    const created = createInvoice({
      date: new Date().toISOString(),
      customerName: customerName.trim() || 'Counter Walk-in',
      customerPhone: customerPhone.trim(),
      customerAge: customerAge.trim() || undefined,
      customerGender: customerGender,
      doctorName: doctorName.trim() || undefined,
      doctorRegNo: doctorRegNo.trim() || undefined,
      items: cartItems,
      subtotal: mrpSubtotal,
      totalDiscount: totalSavings,
      taxableAmount,
      totalCgst,
      totalSgst,
      totalGst,
      roundOff,
      grandTotal,
      paymentMode,
      cashTendered: cashTendered ? parseFloat(cashTendered) : undefined,
      changeDue: cashTendered ? changeDue : undefined,
      status: 'Completed',
      invoiceType: billType,
      notes: notes.trim() || undefined,
      pharmacist: profile.ownerName
    });

    // Reset bill form
    setCartItems([]);
    setCustomerName('Counter Walk-in');
    setCustomerPhone('');
    setCustomerAge('');
    setDoctorName('');
    setDoctorRegNo('');
    setCashTendered('');
    setNotes('');

    // Open print preview modal for newly generated invoice
    onViewInvoice(created);
  };

  // Quick fill customer from Khata
  const handleSelectKhataCustomer = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const kid = e.target.value;
    if (!kid) return;
    const found = khataList.find(k => k.id === kid);
    if (found) {
      setCustomerName(found.name);
      setCustomerPhone(found.phone);
    }
  };

  // UPI payment payload url for QR Code
  const upiQrString = `upi://pay?pa=${profile.upiId}&pn=${encodeURIComponent(profile.storeName)}&am=${grandTotal}&cu=INR&tn=${encodeURIComponent(`Bill at ${profile.storeName}`)}`;
  const qrCodeApiUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(upiQrString)}`;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Top Banner & Quick Key Reference */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
              Pharmacy Counter Billing
            </h1>
            <span className={`text-[11px] font-semibold px-2 py-0.5 rounded ${
              billType === 'NON_GST'
                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                : 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300'
            }`}>
              {billType === 'NON_GST' ? 'Non-GST Retail Cash Memo' : 'GST Tax Invoice'}
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {billType === 'NON_GST' 
              ? 'Non-GST mode: Pure retail cash memo without tax slabs or GST columns' 
              : 'GST mode: Itemized HSN, CGST, SGST tax breakups for GSTR reporting'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Bill Type Switcher */}
          <div className="inline-flex rounded-lg p-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <button
              type="button"
              onClick={() => setBillType('NON_GST')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                billType === 'NON_GST'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              Non-GST Memo
            </button>
            <button
              type="button"
              onClick={() => setBillType('GST')}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                billType === 'GST'
                  ? 'bg-slate-900 dark:bg-slate-700 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              GST Tax Invoice
            </button>
          </div>

          <div className="hidden sm:flex items-center gap-1.5 text-xs font-mono text-slate-500">
            <span className="px-2 py-1 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">F2: Search</span>
            <span className="px-2 py-1 bg-slate-50 dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">F9: Checkout</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Column: Medicine Search & Cart Items (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          
          {/* Medicine Search Box */}
          <div className="relative bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 uppercase tracking-wider mb-2">
              Scan Barcode / Search Medicine by Name, Salt or Batch
            </label>
            
            <div className="relative">
              <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-400" />
              <input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Type brand name (e.g. Augmentin, Pan-D, Dolo, Telma) or Generic Salt..."
                className="w-full pl-10 pr-4 py-2.5 text-sm bg-slate-50 dark:bg-slate-800/80 border border-slate-300 dark:border-slate-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-transparent text-slate-900 dark:text-white placeholder-slate-400"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-xs text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                >
                  Clear
                </button>
              )}
            </div>

            {/* Instant Search Dropdown Results */}
            {searchResults.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 z-30 bg-white dark:bg-slate-900 rounded-xl shadow-xl border border-slate-200 dark:border-slate-800 overflow-hidden divide-y divide-slate-100 dark:divide-slate-800">
                {searchResults.map((med, idx) => {
                  const expInfo = getExpiryStatus(med.expiryDate);
                  const isOutOfStock = med.stockQuantity <= 0;
                  return (
                    <div
                      key={med.id}
                      onClick={() => !isOutOfStock && handleAddToCart(med)}
                      className={`p-3 cursor-pointer transition-colors flex items-center justify-between ${
                        isOutOfStock 
                          ? 'opacity-60 bg-slate-50 dark:bg-slate-950 cursor-not-allowed'
                          : 'hover:bg-slate-50 dark:hover:bg-slate-800/70'
                      }`}
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-sm text-slate-900 dark:text-white">
                            {med.name}
                          </span>
                          <span className="text-xs text-slate-500">
                            {med.dosage}
                          </span>
                          {med.schedule && med.schedule !== 'OTC' && (
                            <span className="text-[10px] font-mono px-1.5 py-0.5 bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400 rounded border border-amber-200 dark:border-amber-900">
                              {med.schedule}
                            </span>
                          )}
                        </div>
                        <div className="text-xs text-slate-500 truncate max-w-md">
                          {med.generic} · {med.manufacturer}
                        </div>
                        <div className="flex items-center gap-3 text-[11px] text-slate-400 font-mono">
                          <span>Batch: {med.batchNumber}</span>
                          <span className={expInfo.textColor}>Exp: {med.expiryDate}</span>
                          <span>Rack: {med.shelfLocation}</span>
                        </div>
                      </div>

                      <div className="text-right shrink-0">
                        <div className="text-sm font-bold font-mono text-slate-900 dark:text-white">
                          ₹{med.salePrice.toFixed(2)}
                        </div>
                        <div className="text-[11px] text-slate-400 line-through font-mono">
                          MRP ₹{med.mrp.toFixed(2)}
                        </div>
                        <div className={`text-xs font-mono font-medium ${isOutOfStock ? 'text-rose-600' : 'text-emerald-700 dark:text-emerald-400'}`}>
                          {isOutOfStock ? 'Out of stock' : `${med.stockQuantity} ${med.unit} left`}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Cart Table */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-600" />
                <h2 className="text-sm font-bold text-slate-900 dark:text-white">
                  Current Bill Items ({cartItems.length})
                </h2>
              </div>
              {cartItems.length > 0 && (
                <button
                  onClick={() => setCartItems([])}
                  className="text-xs text-rose-600 hover:text-rose-700 font-medium"
                >
                  Clear Cart
                </button>
              )}
            </div>

            {cartItems.length === 0 ? (
              <div className="p-12 text-center text-slate-400">
                <Receipt className="w-12 h-12 mx-auto stroke-1 text-slate-300 dark:text-slate-700 mb-3" />
                <p className="text-sm font-medium text-slate-600 dark:text-slate-400">Bill cart is empty</p>
                <p className="text-xs text-slate-400 mt-1">Search medicines above or press F2 to start dispensing</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-50 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-medium">
                      <th className="py-2.5 px-3">Item</th>
                      <th className="py-2.5 px-2">Batch / Exp</th>
                      <th className="py-2.5 px-2 text-center">Qty</th>
                      <th className="py-2.5 px-2 text-right">Price</th>
                      <th className="py-2.5 px-2 text-center">Disc%</th>
                      {billType === 'GST' && (
                        <th className="py-2.5 px-2 text-center">GST</th>
                      )}
                      <th className="py-2.5 px-3 text-right">Total</th>
                      <th className="py-2.5 px-2 text-center"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                    {cartItems.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                        <td className="py-3 px-3">
                          <div className="font-sans font-semibold text-slate-900 dark:text-white text-xs">
                            {item.name}
                          </div>
                          <div className="font-sans text-[11px] text-slate-500 truncate max-w-[180px]">
                            {item.generic}
                          </div>
                          {item.schedule && item.schedule !== 'OTC' && (
                            <span className="font-sans text-[10px] text-amber-700 dark:text-amber-400 font-medium">
                              [{item.schedule}]
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-2 text-[11px] text-slate-500 whitespace-nowrap">
                          <div>{item.batchNumber}</div>
                          <div className="text-[10px] text-slate-400">{item.expiryDate}</div>
                        </td>

                        <td className="py-3 px-2 text-center">
                          <div className="inline-flex items-center border border-slate-200 dark:border-slate-700 rounded-md">
                            <button
                              onClick={() => handleUpdateQuantity(idx, -1)}
                              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="px-2 font-bold text-xs text-slate-900 dark:text-white">
                              {item.quantity}
                            </span>
                            <button
                              onClick={() => handleUpdateQuantity(idx, 1)}
                              className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </td>

                        <td className="py-3 px-2 text-right">
                          <div className="text-slate-900 dark:text-white font-medium">
                            ₹{item.salePrice.toFixed(2)}
                          </div>
                          <div className="text-[10px] text-slate-400 line-through">
                            ₹{item.mrp.toFixed(2)}
                          </div>
                        </td>

                        <td className="py-3 px-2 text-center">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            value={item.discountPercent}
                            onChange={e => handleItemDiscountChange(idx, parseFloat(e.target.value) || 0)}
                            className="w-12 text-center py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-xs focus:ring-1 focus:ring-emerald-500 focus:outline-none"
                          />
                        </td>

                        {billType === 'GST' && (
                          <td className="py-3 px-2 text-center text-slate-500 text-[11px]">
                            {item.gstRate}%
                          </td>
                        )}

                        <td className="py-3 px-3 text-right font-bold text-slate-900 dark:text-white">
                          ₹{item.totalAmount.toFixed(2)}
                        </td>

                        <td className="py-3 px-2 text-center">
                          <button
                            onClick={() => handleRemoveItem(idx)}
                            className="p-1 text-slate-400 hover:text-rose-600 transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Schedule H/H1 Warning Notice if applicable */}
          {hasScheduleHDrugs && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900 rounded-lg flex items-start gap-2.5 text-xs text-amber-800 dark:text-amber-300">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
              <div>
                <span className="font-bold">Drug Compliance Notice:</span> Schedule H / H1 / X medicine present in cart.
                Please ensure patient details and Registered Medical Practitioner (Doctor) name are recorded for Schedule H Register audit.
              </div>
            </div>
          )}

          {/* Recent Invoices Quick-List */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600" /> Recent Sales History
              </span>
              <span className="text-[11px] text-slate-500 font-mono">Today: {invoices.length} Bills</span>
            </div>
            <div className="space-y-2">
              {invoices.slice(0, 3).map(inv => (
                <div
                  key={inv.id}
                  onClick={() => onViewInvoice(inv)}
                  className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/40 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg border border-slate-200 dark:border-slate-700/60 cursor-pointer transition-colors text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-900 dark:text-white flex items-center gap-2">
                      <span>{inv.invoiceNumber}</span>
                      <span className="text-slate-500 font-normal">· {inv.customerName}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      {new Date(inv.date).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · {inv.items.length} items ({inv.paymentMode})
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold font-mono text-slate-900 dark:text-white">
                      ₹{inv.grandTotal.toFixed(2)}
                    </div>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400">View/Print &rarr;</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: Patient Info, Payment, & Summary (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Customer / Patient Details Box */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-600" /> Patient / Customer
              </span>

              {khataList.length > 0 && (
                <select
                  onChange={handleSelectKhataCustomer}
                  defaultValue=""
                  className="text-[11px] bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 text-slate-700 dark:text-slate-300"
                >
                  <option value="">Select Existing Patient / Khata</option>
                  {khataList.map(k => (
                    <option key={k.id} value={k.id}>{k.name} ({k.phone})</option>
                  ))}
                </select>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">Patient Name</label>
                <div className="relative">
                  <input
                    type="text"
                    value={customerName}
                    onChange={e => setCustomerName(e.target.value)}
                    placeholder="Patient Name"
                    className="w-full text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">Mobile No</label>
                <input
                  type="text"
                  value={customerPhone}
                  onChange={e => setCustomerPhone(e.target.value)}
                  placeholder="+91 Mobile No"
                  className="w-full text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">Age / Gender</label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={customerAge}
                    onChange={e => setCustomerAge(e.target.value)}
                    placeholder="Age"
                    className="w-16 text-xs px-2 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                  />
                  <select
                    value={customerGender}
                    onChange={e => setCustomerGender(e.target.value as any)}
                    className="flex-1 text-xs px-2 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-500 mb-1">Prescribing Doctor</label>
                <input
                  type="text"
                  value={doctorName}
                  onChange={e => setDoctorName(e.target.value)}
                  placeholder="Dr. Name (e.g. Dr. Verma)"
                  className="w-full text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-500 mb-1">Doctor Reg No / Clinic (Optional)</label>
              <input
                type="text"
                value={doctorRegNo}
                onChange={e => setDoctorRegNo(e.target.value)}
                placeholder="Doctor Medical Council Reg No"
                className="w-full text-xs px-2.5 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Payment & Checkout Summary */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-xs space-y-4">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider block border-b border-slate-100 dark:border-slate-800 pb-2">
              Payment &amp; Final Settlement
            </span>

            {/* Quick Discount Selector */}
            <div>
              <div className="flex justify-between items-center text-xs mb-1.5">
                <span className="text-slate-600 dark:text-slate-400">Store Flat Discount:</span>
                <span className="font-mono font-semibold text-slate-900 dark:text-white">{overallDiscountPercent}%</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {[0, 5, 10, 15].map(disc => (
                  <button
                    key={disc}
                    type="button"
                    onClick={() => {
                      setOverallDiscountPercent(disc);
                      // Update cart item discounts
                      setCartItems(cartItems.map(item => ({
                        ...item,
                        discountPercent: disc,
                        totalAmount: item.quantity * item.salePrice * (1 - (disc / 100))
                      })));
                    }}
                    className={`py-1 text-xs font-medium rounded-md border transition-colors ${
                      overallDiscountPercent === disc
                        ? 'bg-emerald-600 text-white border-emerald-600 font-bold'
                        : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700'
                    }`}
                  >
                    {disc === 0 ? '0%' : `${disc}% Off`}
                  </button>
                ))}
              </div>
            </div>

            {/* Payment Mode Selection */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-2">
                Payment Method
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                {[
                  { id: 'Cash', label: 'Cash', icon: Banknote },
                  { id: 'UPI', label: 'UPI / QR', icon: QrCode },
                  { id: 'Card', label: 'Card / POS', icon: CreditCard },
                  { id: 'Credit/Khata', label: 'Khata / Credit', icon: User },
                ].map(mode => {
                  const Icon = mode.icon;
                  const isSelected = paymentMode === mode.id;
                  return (
                    <button
                      key={mode.id}
                      type="button"
                      onClick={() => setPaymentMode(mode.id as any)}
                      className={`flex flex-col items-center justify-center p-2 rounded-lg border text-xs font-medium transition-all ${
                        isSelected
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-600 text-emerald-800 dark:text-emerald-300 font-bold'
                          : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4 mb-1" />
                      <span>{mode.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Cash Tendered & Change calculator */}
            {paymentMode === 'Cash' && (
              <div className="bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-200 dark:border-slate-700 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400">Cash Tendered by Patient:</span>
                  <div className="flex items-center gap-1">
                    <span className="text-slate-400 font-mono">₹</span>
                    <input
                      type="number"
                      placeholder={`${grandTotal}`}
                      value={cashTendered}
                      onChange={e => setCashTendered(e.target.value)}
                      className="w-24 text-right px-2 py-1 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-600 rounded text-xs font-mono font-bold text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
                {cashTendered && parseFloat(cashTendered) >= grandTotal && (
                  <div className="flex justify-between items-center text-xs font-semibold text-emerald-700 dark:text-emerald-400 pt-1 border-t border-slate-200 dark:border-slate-700">
                    <span>Return Change:</span>
                    <span className="font-mono text-sm font-bold">₹{changeDue.toFixed(2)}</span>
                  </div>
                )}
              </div>
            )}

            {/* UPI QR Display trigger */}
            {paymentMode === 'UPI' && (
              <div className="bg-emerald-50/70 dark:bg-emerald-950/30 p-3 rounded-lg border border-emerald-200 dark:border-emerald-800 flex items-center justify-between">
                <div>
                  <div className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                    Scan UPI QR to Collect ₹{grandTotal}
                  </div>
                  <div className="text-[11px] text-emerald-700 dark:text-emerald-400 font-mono">
                    VPA: {profile.upiId}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setShowUpiModal(true)}
                  className="px-2.5 py-1.5 text-xs font-semibold text-white bg-emerald-700 hover:bg-emerald-800 rounded-md shadow-xs flex items-center gap-1.5 cursor-pointer"
                >
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Show QR</span>
                </button>
              </div>
            )}

            {/* Bill Financial Breakdown */}
            <div className="space-y-1.5 text-xs border-t border-slate-200 dark:border-slate-800 pt-3">
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>MRP Subtotal:</span>
                <span className="font-mono">₹{mrpSubtotal.toFixed(2)}</span>
              </div>

              {totalSavings > 0 && (
                <div className="flex justify-between text-emerald-700 dark:text-emerald-400">
                  <span>Patient Savings:</span>
                  <span className="font-mono">-₹{totalSavings.toFixed(2)}</span>
                </div>
              )}

              {billType === 'GST' ? (
                <>
                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>Taxable Value:</span>
                    <span className="font-mono">₹{taxableAmount.toFixed(2)}</span>
                  </div>

                  <div className="flex justify-between text-slate-500 text-[11px]">
                    <span>GST (CGST ₹{totalCgst.toFixed(2)} + SGST ₹{totalSgst.toFixed(2)}):</span>
                    <span className="font-mono">₹{totalGst.toFixed(2)}</span>
                  </div>
                </>
              ) : (
                <div className="text-[11px] text-slate-500 italic py-0.5">
                  • Non-GST Retail Cash Memo (No separate tax applied)
                </div>
              )}

              {roundOff !== 0 && (
                <div className="flex justify-between text-slate-400 text-[11px]">
                  <span>Round Off:</span>
                  <span className="font-mono">{roundOff > 0 ? `+₹${roundOff}` : `-₹${Math.abs(roundOff)}`}</span>
                </div>
              )}

              <div className="flex justify-between items-center text-sm font-extrabold text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-800">
                <span>NET TOTAL:</span>
                <span className="text-xl font-mono text-emerald-700 dark:text-emerald-400">
                  {formatCurrency(grandTotal)}
                </span>
              </div>
            </div>

            {/* Finalize & Print Button */}
            <button
              type="button"
              onClick={handleCheckout}
              disabled={cartItems.length === 0}
              className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 disabled:bg-slate-300 dark:disabled:bg-slate-800 disabled:cursor-not-allowed text-white font-bold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
            >
              <CheckCircle2 className="w-5 h-5" />
              <span>Complete Sale &amp; Print {billType === 'NON_GST' ? 'Non-GST Memo' : 'GST Tax Invoice'} (F9)</span>
            </button>
          </div>

        </div>

      </div>

      {/* Dynamic UPI Payment QR Modal */}
      {showUpiModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 p-6 rounded-2xl max-w-sm w-full text-center border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <h3 className="font-bold text-slate-900 dark:text-white text-base">
              Scan &amp; Pay on Any UPI App
            </h3>
            <p className="text-xs text-slate-500">
              GPay, PhonePe, Paytm, BHIM or Cred
            </p>

            <div className="bg-white p-4 rounded-xl border border-slate-200 inline-block shadow-inner">
              <img
                src={qrCodeApiUrl}
                alt="UPI Payment QR Code"
                className="w-48 h-48 mx-auto"
              />
            </div>

            <div className="space-y-1">
              <div className="text-xl font-mono font-black text-emerald-700 dark:text-emerald-400">
                {formatCurrency(grandTotal)}
              </div>
              <div className="text-xs font-mono text-slate-500">
                VPA: {profile.upiId}
              </div>
            </div>

            <button
              onClick={() => setShowUpiModal(false)}
              className="w-full py-2 bg-slate-900 dark:bg-slate-800 text-white rounded-lg text-xs font-semibold"
            >
              Close QR Window
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
