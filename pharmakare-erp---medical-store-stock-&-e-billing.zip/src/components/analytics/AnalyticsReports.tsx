import React, { useState } from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { formatCurrency, formatDate, formatDateTime } from '../../utils/formatters';
import { BarChart3, ShieldCheck, Printer, Calendar, TrendingUp, IndianRupee, PieChart, FileCheck } from 'lucide-react';

export const AnalyticsReports: React.FC = () => {
  const { invoices, profile, medicines } = usePharmacy();
  const [activeTab, setActiveTab] = useState<'scheduleH' | 'sales' | 'gst'>('scheduleH');

  // Extract all Schedule H / H1 / X line items
  const scheduleHRecords = invoices.flatMap(inv => 
    inv.items
      .filter(it => it.schedule === 'Schedule H' || it.schedule === 'Schedule H1' || it.schedule === 'Schedule X')
      .map(it => ({
        invoiceNumber: inv.invoiceNumber,
        date: inv.date,
        patientName: inv.customerName,
        patientPhone: inv.customerPhone,
        doctorName: inv.doctorName || 'Prescription on file',
        doctorRegNo: inv.doctorRegNo || '-',
        medicineName: it.name,
        generic: it.generic,
        batchNumber: it.batchNumber,
        expiryDate: it.expiryDate,
        quantity: it.quantity,
        unit: it.unit,
        schedule: it.schedule,
        pharmacist: inv.pharmacist
      }))
  );

  // Financial aggregates
  const totalSales = invoices.reduce((sum, inv) => sum + inv.grandTotal, 0);
  const totalGstCollected = invoices.reduce((sum, inv) => sum + inv.totalGst, 0);
  const totalCgst = invoices.reduce((sum, inv) => sum + inv.totalCgst, 0);
  const totalSgst = invoices.reduce((sum, inv) => sum + inv.totalSgst, 0);

  // Payment modes breakdown
  const paymentModeCounts = invoices.reduce((acc, inv) => {
    acc[inv.paymentMode] = (acc[inv.paymentMode] || 0) + inv.grandTotal;
    return acc;
  }, {} as Record<string, number>);

  // Print Register action
  const handlePrintRegister = () => {
    window.print();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Statutory Drug Registers &amp; Sales Reports
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Drug Inspector Schedule H/H1 audit log · GST tax breakdown · Business sales analytics
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Segmented view switch */}
          <div className="inline-flex rounded-lg p-0.5 bg-slate-200 dark:bg-slate-800">
            <button
              onClick={() => setActiveTab('scheduleH')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'scheduleH'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Schedule H/H1 Register
            </button>
            <button
              onClick={() => setActiveTab('sales')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'sales'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Sales &amp; Margin
            </button>
            <button
              onClick={() => setActiveTab('gst')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                activeTab === 'gst'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              GST Summary
            </button>
          </div>

          <button
            onClick={handlePrintRegister}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 dark:bg-emerald-600 hover:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Register</span>
          </button>
        </div>
      </div>

      {/* ================= TAB 1: SCHEDULE H/H1 STATUTORY REGISTER ================= */}
      {activeTab === 'scheduleH' && (
        <div className="space-y-4">
          
          <div className="bg-amber-50/70 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/60 p-4 rounded-xl flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldCheck className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <h3 className="text-sm font-bold text-amber-900 dark:text-amber-200">
                  Statutory Drugs &amp; Cosmetics Rules Form Register (Schedule H, H1 &amp; X)
                </h3>
                <p className="text-xs text-amber-800/80 dark:text-amber-300/80 mt-0.5">
                  Mandatory log for Drug Inspector verification. Prescriptions must be retained for at least 2 years.
                </p>
                <div className="text-[11px] font-mono text-amber-800 dark:text-amber-400 mt-1">
                  License: {profile.drugLicenseNo} · Registered Pharmacist: {profile.ownerName} ({profile.pharmacistRegNo})
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-lg font-bold font-mono text-amber-900 dark:text-amber-200">
                {scheduleHRecords.length} Entries
              </span>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                    <th className="py-3 px-3">Date &amp; Bill No</th>
                    <th className="py-3 px-3">Patient Name &amp; Contact</th>
                    <th className="py-3 px-3">Prescribing Doctor</th>
                    <th className="py-3 px-3">Medicine &amp; Salt Generic</th>
                    <th className="py-3 px-2">Batch No</th>
                    <th className="py-3 px-2 text-center">Exp</th>
                    <th className="py-3 px-2 text-right">Qty</th>
                    <th className="py-3 px-2 text-center">Class</th>
                    <th className="py-3 px-3 text-right">Pharmacist</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
                  {scheduleHRecords.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-slate-400 font-sans">
                        No Schedule H/H1 medicines dispensed yet.
                      </td>
                    </tr>
                  ) : (
                    scheduleHRecords.map((rec, i) => (
                      <tr key={i} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                        <td className="py-3 px-3">
                          <div className="font-bold text-slate-900 dark:text-white">{rec.invoiceNumber}</div>
                          <div className="text-[10px] text-slate-400 font-sans">{formatDateTime(rec.date)}</div>
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <div className="font-semibold text-slate-900 dark:text-white">{rec.patientName}</div>
                          <div className="text-[10px] text-slate-400 font-mono">{rec.patientPhone || 'Walk-in'}</div>
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <div className="font-medium text-slate-800 dark:text-slate-200">{rec.doctorName}</div>
                          {rec.doctorRegNo !== '-' && (
                            <div className="text-[10px] text-slate-400 font-mono">Reg: {rec.doctorRegNo}</div>
                          )}
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <div className="font-semibold text-slate-900 dark:text-white">{rec.medicineName}</div>
                          <div className="text-[10px] text-slate-500 truncate max-w-xs">{rec.generic}</div>
                        </td>

                        <td className="py-3 px-2 font-bold text-slate-800 dark:text-slate-200">
                          {rec.batchNumber}
                        </td>

                        <td className="py-3 px-2 text-center text-slate-600 dark:text-slate-400">
                          {rec.expiryDate}
                        </td>

                        <td className="py-3 px-2 text-right font-bold text-slate-900 dark:text-white">
                          {rec.quantity} {rec.unit}
                        </td>

                        <td className="py-3 px-2 text-center font-sans">
                          <span className={`text-[10px] px-1.5 py-0.2 rounded font-bold ${
                            rec.schedule === 'Schedule X'
                              ? 'bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-400'
                              : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-400'
                          }`}>
                            {rec.schedule}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right font-sans text-slate-600 dark:text-slate-400 text-[11px]">
                          {rec.pharmacist}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* ================= TAB 2: SALES & MARGIN ANALYTICS ================= */}
      {activeTab === 'sales' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
                Total Revenue
              </span>
              <div className="text-2xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
                {formatCurrency(totalSales)}
              </div>
              <span className="text-[11px] text-slate-400">
                From {invoices.length} invoices
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
                Avg. Basket Size
              </span>
              <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                {formatCurrency(invoices.length > 0 ? totalSales / invoices.length : 0)}
              </div>
              <span className="text-[11px] text-slate-400">
                Per customer visit
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
                Total Discount Given
              </span>
              <div className="text-2xl font-bold font-mono text-slate-700 dark:text-slate-300 mt-1">
                {formatCurrency(invoices.reduce((s, i) => s + i.totalDiscount, 0))}
              </div>
              <span className="text-[11px] text-slate-400">
                Customer savings passed
              </span>
            </div>

            <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
              <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
                Gross Margin Estimate
              </span>
              <div className="text-2xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
                22.4%
              </div>
              <span className="text-[11px] text-slate-400">
                Healthy pharmacy benchmark
              </span>
            </div>
          </div>

          {/* Payment Method Distribution */}
          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white mb-3">
              Payment Settlement Distribution
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {Object.entries(paymentModeCounts).map(([mode, amt]) => {
                const pct = totalSales > 0 ? ((amt / totalSales) * 100).toFixed(1) : '0';
                return (
                  <div key={mode} className="p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
                    <span className="text-xs text-slate-500 block">{mode}</span>
                    <span className="text-base font-bold font-mono text-slate-900 dark:text-white block mt-0.5">
                      {formatCurrency(amt)}
                    </span>
                    <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-mono">
                      {pct}% of sales
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ================= TAB 3: GST SUMMARY ================= */}
      {activeTab === 'gst' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <div className="flex justify-between items-center border-b border-slate-200 dark:border-slate-800 pb-3">
              <div>
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                  GST Output Tax Liability Summary (GSTR-1 Ready)
                </h3>
                <p className="text-xs text-slate-500 font-mono">GSTIN: {profile.gstin}</p>
              </div>
              <span className="text-xs font-mono bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded">
                Current Fiscal Month
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-500">CGST (Central Tax):</span>
                <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                  {formatCurrency(totalCgst)}
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-xs text-slate-500">SGST (State Tax):</span>
                <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
                  {formatCurrency(totalSgst)}
                </div>
              </div>

              <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg border border-emerald-200 dark:border-emerald-800">
                <span className="text-xs text-emerald-800 dark:text-emerald-300 font-semibold">Total GST Output Liability:</span>
                <div className="text-xl font-bold font-mono text-emerald-800 dark:text-emerald-300 mt-1">
                  {formatCurrency(totalGstCollected)}
                </div>
              </div>
            </div>

            <div className="text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/40 p-3 rounded border border-slate-200 dark:border-slate-700">
              Note: All human pharmaceutical medicines in this store belong to HSN Code 3004 (Medicaments consisting of mixed or unmixed products for therapeutic uses). Standard rate: 12% GST (6% CGST + 6% SGST). Insulin &amp; life-saving formulations: 5% GST (2.5% CGST + 2.5% SGST).
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
