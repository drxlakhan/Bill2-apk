import React, { useState } from 'react';
import { MedicineItem, MedicineCategory, DrugSchedule } from '../../types/pharmacy';
import { X, Save, AlertCircle } from 'lucide-react';

interface MedicineModalProps {
  medicine: MedicineItem | null;
  onClose: () => void;
  onSave: (data: Omit<MedicineItem, 'id'>) => void;
}

const CATEGORIES: MedicineCategory[] = [
  'Tablets',
  'Capsules',
  'Syrup & Suspensions',
  'Injections & Vials',
  'Ointments & Creams',
  'Eye & Ear Drops',
  'Inhalers & Respules',
  'Surgicals & Devices',
  'OTC & Health'
];

const SCHEDULES: DrugSchedule[] = ['OTC', 'Schedule H', 'Schedule H1', 'Schedule X'];

export const MedicineModal: React.FC<MedicineModalProps> = ({ medicine, onClose, onSave }) => {
  const [name, setName] = useState(medicine?.name || '');
  const [generic, setGeneric] = useState(medicine?.generic || '');
  const [category, setCategory] = useState<MedicineCategory>(medicine?.category || 'Tablets');
  const [dosage, setDosage] = useState(medicine?.dosage || '500 mg');
  const [manufacturer, setManufacturer] = useState(medicine?.manufacturer || '');
  const [batchNumber, setBatchNumber] = useState(medicine?.batchNumber || '');
  const [expiryDate, setExpiryDate] = useState(medicine?.expiryDate || '2027-12');
  const [stockQuantity, setStockQuantity] = useState(medicine?.stockQuantity ?? 50);
  const [minStockLevel, setMinStockLevel] = useState(medicine?.minStockLevel ?? 15);
  const [unit, setUnit] = useState<MedicineItem['unit']>(medicine?.unit || 'Strip');
  const [packSize, setPackSize] = useState(medicine?.packSize || '10 Tablets');
  const [costPrice, setCostPrice] = useState(medicine?.costPrice ?? 100);
  const [mrp, setMrp] = useState(medicine?.mrp ?? 150);
  const [salePrice, setSalePrice] = useState(medicine?.salePrice ?? 135);
  const [gstRate, setGstRate] = useState(medicine?.gstRate ?? 12);
  const [hsnCode, setHsnCode] = useState(medicine?.hsnCode || '3004');
  const [schedule, setSchedule] = useState<DrugSchedule>(medicine?.schedule || 'Schedule H');
  const [shelfLocation, setShelfLocation] = useState(medicine?.shelfLocation || 'Rack A-1');
  const [supplierName, setSupplierName] = useState(medicine?.supplierName || 'Apex Pharma Distributors');
  const [barcode, setBarcode] = useState(medicine?.barcode || '');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      alert('Medicine name is required!');
      return;
    }
    if (!batchNumber.trim()) {
      alert('Batch number is required for pharmacy tracking!');
      return;
    }
    if (!expiryDate.trim()) {
      alert('Expiry Date (YYYY-MM) is required!');
      return;
    }

    onSave({
      name: name.trim(),
      generic: generic.trim(),
      category,
      dosage: dosage.trim(),
      manufacturer: manufacturer.trim() || 'Generic Pharma',
      batchNumber: batchNumber.trim().toUpperCase(),
      expiryDate: expiryDate.trim(),
      stockQuantity: Number(stockQuantity) || 0,
      minStockLevel: Number(minStockLevel) || 10,
      unit,
      packSize: packSize.trim() || '1 Unit',
      costPrice: Number(costPrice) || 0,
      mrp: Number(mrp) || 0,
      salePrice: Number(salePrice) || 0,
      gstRate: Number(gstRate) || 12,
      hsnCode: hsnCode.trim() || '3004',
      schedule,
      shelfLocation: shelfLocation.trim() || 'Rack A',
      supplierName: supplierName.trim() || 'Direct Inward',
      barcode: barcode.trim() || undefined,
      requiresPrescription: schedule !== 'OTC'
    });
    onClose();
  };

  // Calculate gross margin %
  const marginPercent = salePrice > 0 && costPrice > 0
    ? (((salePrice - costPrice) / salePrice) * 100).toFixed(1)
    : '0';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-3xl my-6 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              {medicine ? `Edit Medicine: ${medicine.name}` : 'Add New Medicine / Stock Batch'}
            </h2>
            <p className="text-xs text-slate-500">
              Enter complete pharmaceutical specification, batch, GST, and shelf location
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
          
          {/* Row 1: Brand & Generic */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Medicine Brand Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Augmentin 625 Duo, Pan-D, Telma 40"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Generic Composition (Salt Formulation) *
              </label>
              <input
                type="text"
                required
                value={generic}
                onChange={e => setGeneric(e.target.value)}
                placeholder="e.g. Amoxicillin (500mg) + Clavulanic Acid (125mg)"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Row 2: Category, Dosage, Manufacturer */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Form / Category
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as MedicineCategory)}
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Dosage / Strength
              </label>
              <input
                type="text"
                value={dosage}
                onChange={e => setDosage(e.target.value)}
                placeholder="e.g. 625 mg, 40mg/30mg, 100 ml"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Manufacturer / Pharma Co.
              </label>
              <input
                type="text"
                value={manufacturer}
                onChange={e => setManufacturer(e.target.value)}
                placeholder="e.g. Cipla, Sun Pharma, Alkem"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Row 3: Batch Number, Expiry, Schedule */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-lg border border-slate-200 dark:border-slate-700">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Batch Number *
              </label>
              <input
                type="text"
                required
                value={batchNumber}
                onChange={e => setBatchNumber(e.target.value)}
                placeholder="e.g. AUG9421"
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono uppercase text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Expiry Date (YYYY-MM) *
              </label>
              <input
                type="month"
                required
                value={expiryDate}
                onChange={e => setExpiryDate(e.target.value)}
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Drug Schedule Law
              </label>
              <select
                value={schedule}
                onChange={e => setSchedule(e.target.value as DrugSchedule)}
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white font-medium"
              >
                {SCHEDULES.map(sch => (
                  <option key={sch} value={sch}>{sch}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Row 4: Stock, Alert level, Pack Size, Unit */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Stock Quantity (Units)
              </label>
              <input
                type="number"
                min="0"
                value={stockQuantity}
                onChange={e => setStockQuantity(parseInt(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono font-bold text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Min Stock Alert Level
              </label>
              <input
                type="number"
                min="0"
                value={minStockLevel}
                onChange={e => setMinStockLevel(parseInt(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Unit Type
              </label>
              <select
                value={unit}
                onChange={e => setUnit(e.target.value as any)}
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              >
                <option value="Strip">Strip</option>
                <option value="Bottle">Bottle</option>
                <option value="Vial">Vial</option>
                <option value="Tube">Tube</option>
                <option value="Pack">Pack</option>
                <option value="Piece">Piece</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Pack Size Details
              </label>
              <input
                type="text"
                value={packSize}
                onChange={e => setPackSize(e.target.value)}
                placeholder="e.g. 10 Tabs / 100 ml"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Row 5: Pricing, Cost, MRP, Sale, Margin */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 bg-emerald-50/50 dark:bg-emerald-950/20 p-3 rounded-lg border border-emerald-200 dark:border-emerald-900/60">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Cost Price (ex-GST) ₹
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={costPrice}
                onChange={e => setCostPrice(parseFloat(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                MRP (Printed Max Price) ₹
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={mrp}
                onChange={e => setMrp(parseFloat(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Counter Sale Price ₹
              </label>
              <input
                type="number"
                step="0.01"
                min="0"
                value={salePrice}
                onChange={e => setSalePrice(parseFloat(e.target.value) || 0)}
                className="w-full text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono font-bold text-emerald-800 dark:text-emerald-400"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Estimated Margin
              </label>
              <div className="text-xs px-3 py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md font-mono font-bold text-emerald-700 dark:text-emerald-400">
                {marginPercent}% Profit
              </div>
            </div>
          </div>

          {/* Row 6: GST, HSN, Shelf Rack, Supplier */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                GST Rate %
              </label>
              <select
                value={gstRate}
                onChange={e => setGstRate(parseInt(e.target.value) || 12)}
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white font-mono"
              >
                <option value={0}>0% (Exempt)</option>
                <option value={5}>5% (Life-saving)</option>
                <option value={12}>12% (Standard Pharma)</option>
                <option value={18}>18% (Devices/Nutrition)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                HSN Code
              </label>
              <input
                type="text"
                value={hsnCode}
                onChange={e => setHsnCode(e.target.value)}
                placeholder="3004"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Shelf / Rack Location
              </label>
              <input
                type="text"
                value={shelfLocation}
                onChange={e => setShelfLocation(e.target.value)}
                placeholder="Rack A-1, Fridge, etc."
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Distributor / Supplier
              </label>
              <input
                type="text"
                value={supplierName}
                onChange={e => setSupplierName(e.target.value)}
                placeholder="Distributor Name"
                className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
              />
            </div>
          </div>

          {/* Barcode */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Barcode / GTIN / QR (Optional)
            </label>
            <input
              type="text"
              value={barcode}
              onChange={e => setBarcode(e.target.value)}
              placeholder="Scan barcode scanner or enter product code"
              className="w-full text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
            />
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              <span>{medicine ? 'Save Changes' : 'Add to Pharmacy Stock'}</span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};
