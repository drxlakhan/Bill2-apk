import React, { useState } from 'react';
import { MedicineItem } from '../../types/pharmacy';
import { X, Check } from 'lucide-react';

interface StockAdjustModalProps {
  medicine: MedicineItem | null;
  onClose: () => void;
  onAdjust: (id: string, newQty: number, reason: string) => void;
}

export const StockAdjustModal: React.FC<StockAdjustModalProps> = ({ medicine, onClose, onAdjust }) => {
  const [newQuantity, setNewQuantity] = useState(medicine?.stockQuantity ?? 0);
  const [reason, setReason] = useState('Physical Stock Audit / Count Match');
  const [notes, setNotes] = useState('');

  if (!medicine) return null;

  const diff = newQuantity - medicine.stockQuantity;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAdjust(medicine.id, newQuantity, `${reason} - ${notes}`);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden">
        
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">Adjust Stock Count</h3>
            <p className="text-xs text-slate-500">{medicine.name} (Batch: {medicine.batchNumber})</p>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-4 text-xs">
          <div className="flex justify-between items-center p-3 bg-slate-50 dark:bg-slate-800/40 rounded-lg border border-slate-200 dark:border-slate-700">
            <span className="text-slate-500">Current In-Stock:</span>
            <span className="font-mono text-sm font-bold text-slate-900 dark:text-white">
              {medicine.stockQuantity} {medicine.unit}
            </span>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              New Verified Physical Count ({medicine.unit}):
            </label>
            <input
              type="number"
              min="0"
              required
              value={newQuantity}
              onChange={e => setNewQuantity(parseInt(e.target.value) || 0)}
              className="w-full text-sm font-mono font-bold px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
            />
            {diff !== 0 && (
              <span className={`block mt-1 font-mono text-[11px] font-semibold ${diff > 0 ? 'text-emerald-700 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>
                Adjustment: {diff > 0 ? `+${diff}` : diff} {medicine.unit}
              </span>
            )}
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Reason for Adjustment
            </label>
            <select
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
            >
              <option value="Physical Stock Audit / Count Match">Physical Stock Audit / Count Match</option>
              <option value="Damaged / Broken Packaging">Damaged / Broken Packaging</option>
              <option value="Expired Stock Returned to Distributor">Expired Stock Returned to Distributor</option>
              <option value="Doctor Sample / Dispensed Free">Doctor Sample / Dispensed Free</option>
              <option value="Theft or Loss Write-off">Theft or Loss Write-off</option>
            </select>
          </div>

          <div>
            <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Audit Notes (Optional)
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. Verified by Drx. Lakhan"
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
            />
          </div>

          <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-1.5 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs flex items-center gap-1.5"
            >
              <Check className="w-3.5 h-3.5" />
              <span>Apply Adjustment</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
