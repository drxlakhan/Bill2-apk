import React, { useState } from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { MedicineItem, MedicineCategory, DrugSchedule } from '../../types/pharmacy';
import { formatCurrency, getExpiryStatus, exportToCSV } from '../../utils/formatters';
import { MedicineModal } from './MedicineModal';
import { StockAdjustModal } from './StockAdjustModal';
import { 
  Package, 
  Plus, 
  Search, 
  Download, 
  Upload, 
  AlertTriangle, 
  Clock, 
  Edit3, 
  SlidersHorizontal, 
  Trash2, 
  Filter,
  Layers,
  Archive,
  RefreshCw
} from 'lucide-react';

export const InventoryManager: React.FC = () => {
  const { 
    medicines, 
    addMedicine, 
    updateMedicine, 
    deleteMedicine, 
    adjustStock,
    lowStockItems, 
    nearExpiryItems, 
    expiredItems 
  } = usePharmacy();

  // Search & Filter state
  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'low-stock' | 'near-expiry' | 'expired' | 'schedule-h' | 'narcotics'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<MedicineItem | null>(null);
  const [adjustingMedicine, setAdjustingMedicine] = useState<MedicineItem | null>(null);

  // Compute filtered items
  const filteredMedicines = medicines.filter(med => {
    // Search match
    const q = search.toLowerCase();
    const matchesSearch = 
      !search ||
      med.name.toLowerCase().includes(q) ||
      med.generic.toLowerCase().includes(q) ||
      med.batchNumber.toLowerCase().includes(q) ||
      med.manufacturer.toLowerCase().includes(q) ||
      med.shelfLocation.toLowerCase().includes(q);

    if (!matchesSearch) return false;

    // Category match
    if (selectedCategory !== 'all' && med.category !== selectedCategory) {
      return false;
    }

    // Status filter
    if (filterType === 'low-stock') {
      return med.stockQuantity <= med.minStockLevel;
    }
    if (filterType === 'near-expiry') {
      const exp = getExpiryStatus(med.expiryDate);
      return exp.status === 'near-expiry' || exp.status === 'critical';
    }
    if (filterType === 'expired') {
      const exp = getExpiryStatus(med.expiryDate);
      return exp.status === 'expired';
    }
    if (filterType === 'schedule-h') {
      return med.schedule === 'Schedule H' || med.schedule === 'Schedule H1';
    }
    if (filterType === 'narcotics') {
      return med.schedule === 'Schedule X';
    }

    return true;
  });

  // Calculate totals
  const totalStockWorthMRP = medicines.reduce((sum, m) => sum + (m.mrp * m.stockQuantity), 0);
  const totalStockWorthCost = medicines.reduce((sum, m) => sum + (m.costPrice * m.stockQuantity), 0);
  const potentialProfit = totalStockWorthMRP - totalStockWorthCost;

  const handleSaveMedicine = (data: Omit<MedicineItem, 'id'>) => {
    if (editingMedicine) {
      updateMedicine(editingMedicine.id, data);
      setEditingMedicine(null);
    } else {
      addMedicine(data);
      setIsAddModalOpen(false);
    }
  };

  const handleDelete = (med: MedicineItem) => {
    if (window.confirm(`Delete ${med.name} (Batch: ${med.batchNumber}) from inventory?`)) {
      deleteMedicine(med.id);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header and Quick KPIs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Pharmacy Stock &amp; Inventory Management
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Batch-wise tracking · Expiry inspection · Rack locations · Drug Schedule compliance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => exportToCSV(medicines)}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 transition-colors cursor-pointer"
            title="Download CSV spreadsheet"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Medicine Batch</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider block">
            Total Inventory Value
          </span>
          <div className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
            {formatCurrency(totalStockWorthMRP)}
          </div>
          <span className="text-[10px] text-slate-400 font-mono">
            Cost: {formatCurrency(totalStockWorthCost)}
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-medium text-slate-500 uppercase tracking-wider block">
            Stocked Medicines
          </span>
          <div className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
            {medicines.length} <span className="text-xs font-normal text-slate-500">Batches</span>
          </div>
          <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-mono">
            +{formatCurrency(potentialProfit)} margin
          </span>
        </div>

        <button
          onClick={() => setFilterType(filterType === 'low-stock' ? 'all' : 'low-stock')}
          className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
            filterType === 'low-stock'
              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 ring-2 ring-amber-500/20'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <span className="text-[11px] font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wider block">
            Low Stock Alert
          </span>
          <div className="text-lg font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {lowStockItems.length} <span className="text-xs font-normal text-slate-500">Items</span>
          </div>
          <span className="text-[10px] text-slate-400">Needs re-order &rarr;</span>
        </button>

        <button
          onClick={() => setFilterType(filterType === 'near-expiry' ? 'all' : 'near-expiry')}
          className={`text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
            filterType === 'near-expiry'
              ? 'bg-amber-50 dark:bg-amber-950/40 border-amber-300 dark:border-amber-800 ring-2 ring-amber-500/20'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <span className="text-[11px] font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wider block">
            Near Expiry (&lt; 90d)
          </span>
          <div className="text-lg font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {nearExpiryItems.length} <span className="text-xs font-normal text-slate-500">Batches</span>
          </div>
          <span className="text-[10px] text-slate-400">Return or prioritize</span>
        </button>

        <button
          onClick={() => setFilterType(filterType === 'expired' ? 'all' : 'expired')}
          className={`col-span-2 lg:col-span-1 text-left p-3.5 rounded-xl border transition-all cursor-pointer ${
            filterType === 'expired'
              ? 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 ring-2 ring-rose-500/20'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <span className="text-[11px] font-medium text-rose-700 dark:text-rose-400 uppercase tracking-wider block">
            Expired Batches
          </span>
          <div className="text-lg font-bold font-mono text-rose-700 dark:text-rose-400 mt-1">
            {expiredItems.length} <span className="text-xs font-normal text-slate-500">Batches</span>
          </div>
          <span className="text-[10px] text-rose-600 dark:text-rose-400 font-medium">Do not dispense!</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Filter by medicine name, generic composition, batch, manufacturer, rack..."
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>

          {/* Category Dropdown */}
          <div className="flex items-center gap-2">
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="text-xs px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-900 dark:text-white"
            >
              <option value="all">All Formulations / Categories</option>
              <option value="Tablets">Tablets</option>
              <option value="Capsules">Capsules</option>
              <option value="Syrup & Suspensions">Syrup &amp; Suspensions</option>
              <option value="Injections & Vials">Injections &amp; Vials</option>
              <option value="Ointments & Creams">Ointments &amp; Creams</option>
              <option value="Eye & Ear Drops">Eye &amp; Ear Drops</option>
              <option value="Inhalers & Respules">Inhalers &amp; Respules</option>
              <option value="Surgicals & Devices">Surgicals &amp; Devices</option>
              <option value="OTC & Health">OTC &amp; Health</option>
            </select>
          </div>
        </div>

        {/* Filter Segmented Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto pt-1 no-scrollbar text-xs">
          {[
            { id: 'all', label: `All Medicines (${medicines.length})` },
            { id: 'low-stock', label: `Low Stock (${lowStockItems.length})` },
            { id: 'near-expiry', label: `Near Expiry (${nearExpiryItems.length})` },
            { id: 'expired', label: `Expired (${expiredItems.length})` },
            { id: 'schedule-h', label: 'Schedule H / H1' },
            { id: 'narcotics', label: 'Schedule X' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id as any)}
              className={`px-3 py-1.5 rounded-md whitespace-nowrap font-medium transition-colors ${
                filterType === tab.id
                  ? 'bg-slate-900 text-white dark:bg-emerald-600 dark:text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Stock Data Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                <th className="py-3 px-3">Medicine &amp; Composition</th>
                <th className="py-3 px-2">Dosage/Form</th>
                <th className="py-3 px-2">Batch No</th>
                <th className="py-3 px-2 text-center">Expiry</th>
                <th className="py-3 px-2 text-center">Schedule</th>
                <th className="py-3 px-2 text-right">Stock Qty</th>
                <th className="py-3 px-2 text-right">Cost ₹</th>
                <th className="py-3 px-2 text-right">MRP ₹</th>
                <th className="py-3 px-2 text-right">Sale ₹</th>
                <th className="py-3 px-2 text-center">Rack</th>
                <th className="py-3 px-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-mono">
              {filteredMedicines.length === 0 ? (
                <tr>
                  <td colSpan={11} className="py-12 text-center text-slate-400 font-sans">
                    No medicine records found matching your filters.
                  </td>
                </tr>
              ) : (
                filteredMedicines.map(med => {
                  const exp = getExpiryStatus(med.expiryDate);
                  const isLow = med.stockQuantity <= med.minStockLevel;
                  const isOutOfStock = med.stockQuantity <= 0;

                  return (
                    <tr key={med.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40 transition-colors">
                      
                      {/* Name & Generic */}
                      <td className="py-3 px-3 font-sans">
                        <div className="font-semibold text-slate-900 dark:text-white text-xs">
                          {med.name}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-xs" title={med.generic}>
                          {med.generic}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          {med.manufacturer} · {med.packSize}
                        </div>
                      </td>

                      {/* Dosage / Category */}
                      <td className="py-3 px-2 font-sans text-slate-700 dark:text-slate-300">
                        <div>{med.dosage}</div>
                        <div className="text-[10px] text-slate-400">{med.category}</div>
                      </td>

                      {/* Batch */}
                      <td className="py-3 px-2 text-slate-800 dark:text-slate-200 font-bold">
                        {med.batchNumber}
                      </td>

                      {/* Expiry */}
                      <td className="py-3 px-2 text-center">
                        <div className={`text-xs font-semibold ${exp.textColor}`}>
                          {med.expiryDate}
                        </div>
                        <div className={`text-[10px] font-sans ${exp.textColor}`}>
                          {exp.label}
                        </div>
                      </td>

                      {/* Schedule */}
                      <td className="py-3 px-2 text-center font-sans">
                        <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${
                          med.schedule === 'OTC'
                            ? 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                            : med.schedule === 'Schedule X'
                            ? 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-400 font-bold'
                            : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-400'
                        }`}>
                          {med.schedule}
                        </span>
                      </td>

                      {/* Stock Quantity with warning */}
                      <td className="py-3 px-2 text-right">
                        <div className={`font-bold text-xs ${
                          isOutOfStock
                            ? 'text-rose-600'
                            : isLow
                            ? 'text-amber-600'
                            : 'text-slate-900 dark:text-white'
                        }`}>
                          {med.stockQuantity} <span className="font-normal text-[10px] text-slate-400">{med.unit}</span>
                        </div>
                        {isLow && (
                          <div className="text-[10px] font-sans text-amber-600">
                            Min: {med.minStockLevel}
                          </div>
                        )}
                      </td>

                      {/* Cost */}
                      <td className="py-3 px-2 text-right text-slate-500">
                        ₹{med.costPrice.toFixed(2)}
                      </td>

                      {/* MRP */}
                      <td className="py-3 px-2 text-right text-slate-400">
                        ₹{med.mrp.toFixed(2)}
                      </td>

                      {/* Sale Price */}
                      <td className="py-3 px-2 text-right font-bold text-emerald-700 dark:text-emerald-400">
                        ₹{med.salePrice.toFixed(2)}
                      </td>

                      {/* Shelf Rack */}
                      <td className="py-3 px-2 text-center font-sans text-[11px] text-slate-600 dark:text-slate-400">
                        <span className="bg-slate-100 dark:bg-slate-800 px-1.5 py-0.5 rounded border border-slate-200 dark:border-slate-700">
                          {med.shelfLocation}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-right font-sans">
                        <div className="inline-flex items-center gap-1">
                          <button
                            onClick={() => setAdjustingMedicine(med)}
                            title="Adjust physical stock count"
                            className="p-1 text-slate-500 hover:text-emerald-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                          >
                            <SlidersHorizontal className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => setEditingMedicine(med)}
                            title="Edit medicine batch details"
                            className="p-1 text-slate-500 hover:text-blue-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(med)}
                            title="Delete batch"
                            className="p-1 text-slate-400 hover:text-rose-600 hover:bg-slate-100 dark:hover:bg-slate-800 rounded transition-colors"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Medicine Modal */}
      {(isAddModalOpen || editingMedicine) && (
        <MedicineModal
          medicine={editingMedicine}
          onClose={() => {
            setIsAddModalOpen(false);
            setEditingMedicine(null);
          }}
          onSave={handleSaveMedicine}
        />
      )}

      {/* Stock Adjustment Modal */}
      {adjustingMedicine && (
        <StockAdjustModal
          medicine={adjustingMedicine}
          onClose={() => setAdjustingMedicine(null)}
          onAdjust={adjustStock}
        />
      )}

    </div>
  );
};
