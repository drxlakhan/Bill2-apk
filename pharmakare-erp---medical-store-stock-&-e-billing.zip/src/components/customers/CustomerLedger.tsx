import React, { useState } from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { CustomerKhata } from '../../types/pharmacy';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Users, Plus, IndianRupee, MessageSquare, Check, X, Phone, UserCheck, History } from 'lucide-react';

export const CustomerLedger: React.FC = () => {
  const { khataList, recordKhataPayment, addKhataCustomer, profile } = usePharmacy();
  
  // Selected customer for viewing transactions
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(khataList[0]?.id || '');
  
  // Modals
  const [isAddCustomerOpen, setIsAddCustomerOpen] = useState(false);
  const [payingCustomerId, setPayingCustomerId] = useState<string | null>(null);
  const [paymentAmount, setPaymentAmount] = useState<number>(0);
  const [paymentNotes, setPaymentNotes] = useState('UPI Settlement');

  // New customer form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('+91 ');
  const [address, setAddress] = useState('');
  const [creditLimit, setCreditLimit] = useState(5000);
  const [chronicTagInput, setChronicTagInput] = useState('');
  const [initialNotes, setInitialNotes] = useState('');

  const selectedCustomer = khataList.find(c => c.id === selectedCustomerId) || khataList[0];

  const totalOutstanding = khataList.reduce((sum, c) => sum + c.currentBalance, 0);

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) {
      alert('Patient name and phone are required');
      return;
    }

    const tags = chronicTagInput
      ? chronicTagInput.split(',').map(t => t.trim()).filter(Boolean)
      : undefined;

    addKhataCustomer({
      name: name.trim(),
      phone: phone.trim(),
      address: address.trim() || undefined,
      currentBalance: 0,
      creditLimit: Number(creditLimit) || 5000,
      chronicTags: tags,
      lastPurchaseDate: new Date().toISOString().slice(0, 10),
      notes: initialNotes.trim() || undefined
    });

    setIsAddCustomerOpen(false);
    setName('');
    setPhone('+91 ');
    setAddress('');
    setChronicTagInput('');
    setInitialNotes('');
  };

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payingCustomerId || paymentAmount <= 0) return;
    recordKhataPayment(payingCustomerId, paymentAmount, paymentNotes);
    setPayingCustomerId(null);
    setPaymentAmount(0);
  };

  const handleWhatsAppReminder = (customer: CustomerKhata) => {
    const text = `Namaste ${customer.name},\n` +
      `This is a gentle reminder from *${profile.storeName}*.\n` +
      `Your current medicine khata outstanding balance is *₹${customer.currentBalance.toFixed(2)}*.\n` +
      `You can pay via UPI to: *${profile.upiId}* or visit our counter.\n` +
      `Thank you for your trust! Wishing you good health.\n` +
      `Ph: ${profile.phone}`;
    
    const encoded = encodeURIComponent(text);
    const cleanPhone = customer.phone.replace(/[^0-9]/g, '');
    window.open(`https://wa.me/${cleanPhone}?text=${encoded}`, '_blank');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Patient Khata &amp; Chronic Care Ledger
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Credit accounts · Chronic refill patients · Payment collection &amp; WhatsApp reminders
          </p>
        </div>

        <button
          onClick={() => setIsAddCustomerOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Khata Account</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wider block">
            Total Customer Credit Outstanding
          </span>
          <div className="text-xl font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {formatCurrency(totalOutstanding)}
          </div>
          <span className="text-[11px] text-slate-400">
            Across {khataList.filter(c => c.currentBalance > 0).length} debtor accounts
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
            Active Patient Khata Profiles
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {khataList.length} <span className="text-xs font-normal text-slate-500">Registered</span>
          </div>
          <span className="text-[11px] text-slate-400">
            Includes clinic doctors &amp; regular families
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block">
            Store Recovery Health
          </span>
          <div className="text-xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
            94.2%
          </div>
          <span className="text-[11px] text-slate-400">
            Prompt monthly recovery rate
          </span>
        </div>
      </div>

      {/* Split View: Customer List on Left, Detailed Ledger on Right */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Customer Accounts List (5 cols) */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="px-4 py-3 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center bg-slate-50 dark:bg-slate-950">
            <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
              Khata Accounts ({khataList.length})
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[600px] overflow-y-auto">
            {khataList.map(customer => {
              const isSelected = selectedCustomer?.id === customer.id;
              return (
                <div
                  key={customer.id}
                  onClick={() => setSelectedCustomerId(customer.id)}
                  className={`p-3.5 cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-slate-100/80 dark:bg-slate-800'
                      : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="space-y-0.5">
                      <div className="text-xs font-bold text-slate-900 dark:text-white">
                        {customer.name}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono flex items-center gap-1">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{customer.phone}</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <div className={`text-xs font-bold font-mono ${customer.currentBalance > 0 ? 'text-amber-700 dark:text-amber-400' : 'text-emerald-700 dark:text-emerald-400'}`}>
                        {formatCurrency(customer.currentBalance)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {customer.currentBalance > 0 ? 'Due Balance' : 'Zero Due'}
                      </div>
                    </div>
                  </div>

                  {customer.chronicTags && customer.chronicTags.length > 0 && (
                    <div className="mt-2 flex items-center gap-1.5 flex-wrap">
                      {customer.chronicTags.map((tag, i) => (
                        <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-900">
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Customer Detailed Statement (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {selectedCustomer ? (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
              
              {/* Profile Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
                <div>
                  <h2 className="text-base font-bold text-slate-900 dark:text-white">
                    {selectedCustomer.name}
                  </h2>
                  <p className="text-xs text-slate-500 font-mono mt-0.5">
                    Phone: {selectedCustomer.phone} · Credit Limit: ₹{selectedCustomer.creditLimit}
                  </p>
                  {selectedCustomer.address && (
                    <p className="text-xs text-slate-400 mt-0.5">{selectedCustomer.address}</p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  {selectedCustomer.currentBalance > 0 && (
                    <button
                      onClick={() => handleWhatsAppReminder(selectedCustomer)}
                      className="inline-flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg hover:bg-emerald-100 transition-colors cursor-pointer"
                      title="Send WhatsApp payment reminder"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>WhatsApp Due</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setPayingCustomerId(selectedCustomer.id);
                      setPaymentAmount(selectedCustomer.currentBalance);
                    }}
                    disabled={selectedCustomer.currentBalance <= 0}
                    className="inline-flex items-center gap-1 px-3.5 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 disabled:bg-slate-300 dark:disabled:bg-slate-800 rounded-lg shadow-xs transition-colors cursor-pointer"
                  >
                    <IndianRupee className="w-3.5 h-3.5" />
                    <span>Receive Payment</span>
                  </button>
                </div>
              </div>

              {/* Outstanding summary */}
              <div className="p-3.5 bg-slate-50 dark:bg-slate-800/40 rounded-xl border border-slate-200 dark:border-slate-700 flex justify-between items-center text-xs">
                <div>
                  <span className="text-slate-500 block">Total Due Balance:</span>
                  <span className="text-xl font-bold font-mono text-amber-700 dark:text-amber-400">
                    {formatCurrency(selectedCustomer.currentBalance)}
                  </span>
                </div>
                <div className="text-right text-slate-500 text-[11px]">
                  <div>Last Purchase: {formatDate(selectedCustomer.lastPurchaseDate)}</div>
                  {selectedCustomer.notes && <div className="italic text-slate-400 mt-0.5">{selectedCustomer.notes}</div>}
                </div>
              </div>

              {/* Transactions Ledger */}
              <div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider block mb-2 flex items-center gap-1.5">
                  <History className="w-3.5 h-3.5 text-emerald-600" /> Account Passbook History
                </span>

                <div className="border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-slate-50 dark:bg-slate-800/60 font-sans text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                      <tr>
                        <th className="py-2 px-3">Date</th>
                        <th className="py-2 px-3">Type</th>
                        <th className="py-2 px-3">Ref ID / Bill</th>
                        <th className="py-2 px-3">Particulars</th>
                        <th className="py-2 px-3 text-right">Amount ₹</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {selectedCustomer.transactions.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-6 text-center text-slate-400 font-sans">
                            No ledger transactions recorded yet.
                          </td>
                        </tr>
                      ) : (
                        selectedCustomer.transactions.map(tx => (
                          <tr key={tx.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30">
                            <td className="py-2.5 px-3 text-slate-500 font-sans">{formatDate(tx.date)}</td>
                            <td className="py-2.5 px-3 font-sans">
                              <span className={`inline-block text-[10px] px-1.5 py-0.2 rounded font-semibold ${
                                tx.type === 'Payment'
                                  ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300'
                                  : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300'
                              }`}>
                                {tx.type === 'Payment' ? 'Payment (Cr)' : 'Bill (Dr)'}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-bold text-slate-700 dark:text-slate-300">{tx.referenceId}</td>
                            <td className="py-2.5 px-3 font-sans text-slate-500 text-[11px]">{tx.notes || '-'}</td>
                            <td className={`py-2.5 px-3 text-right font-bold ${tx.type === 'Payment' ? 'text-emerald-700 dark:text-emerald-400' : 'text-slate-900 dark:text-white'}`}>
                              {tx.type === 'Payment' ? `-₹${tx.amount.toFixed(2)}` : `+₹${tx.amount.toFixed(2)}`}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 p-8 rounded-xl border border-slate-200 dark:border-slate-800 text-center text-slate-400">
              Select a customer account to view ledger statement
            </div>
          )}
        </div>

      </div>

      {/* Receive Payment Modal */}
      {payingCustomerId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-sm overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Receive Khata Payment</h3>
              <button onClick={() => setPayingCustomerId(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleRecordPayment} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Amount Received ₹ *
                </label>
                <input
                  type="number"
                  step="0.01"
                  min="1"
                  required
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(parseFloat(e.target.value) || 0)}
                  className="w-full text-base font-mono font-bold px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md focus:ring-1 focus:ring-emerald-500 text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Mode &amp; Notes
                </label>
                <select
                  value={paymentNotes}
                  onChange={e => setPaymentNotes(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                >
                  <option value="Cash Settlement at Counter">Cash Settlement at Counter</option>
                  <option value="Google Pay / PhonePe UPI">Google Pay / PhonePe UPI</option>
                  <option value="Bank Transfer (NEFT/IMPS)">Bank Transfer (NEFT/IMPS)</option>
                  <option value="Cheque Cleared">Cheque Cleared</option>
                </select>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setPayingCustomerId(null)}
                  className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs flex items-center gap-1.5"
                >
                  <Check className="w-3.5 h-3.5" />
                  <span>Record Receipt</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Khata Customer Modal */}
      {isAddCustomerOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-md overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Create New Patient Khata Account</h3>
              <button onClick={() => setIsAddCustomerOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="p-5 space-y-3.5 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Patient / Account Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  placeholder="e.g. Ramesh Kulkarni or Dr. Patil Clinic"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Mobile No *</label>
                  <input
                    type="text"
                    required
                    value={phone}
                    onChange={e => setPhone(e.target.value)}
                    placeholder="+91 98200 00000"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Credit Limit ₹</label>
                  <input
                    type="number"
                    value={creditLimit}
                    onChange={e => setCreditLimit(parseInt(e.target.value) || 5000)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Home Address / Ward</label>
                <input
                  type="text"
                  value={address}
                  onChange={e => setAddress(e.target.value)}
                  placeholder="Flat No, Society, Landmark"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Chronic Tags (Comma separated)
                </label>
                <input
                  type="text"
                  value={chronicTagInput}
                  onChange={e => setChronicTagInput(e.target.value)}
                  placeholder="e.g. Diabetes, Hypertension, Cardiac"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">Pharmacist Note</label>
                <input
                  type="text"
                  value={initialNotes}
                  onChange={e => setInitialNotes(e.target.value)}
                  placeholder="e.g. Regular monthly customer since 2023"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddCustomerOpen(false)}
                  className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Create Account</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
