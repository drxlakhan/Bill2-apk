import React, { useState } from 'react';
import { usePharmacy } from '../../context/PharmacyContext';
import { DistributorPurchase } from '../../types/pharmacy';
import { formatCurrency, formatDate } from '../../utils/formatters';
import { Truck, Plus, CheckCircle, Clock, AlertCircle, X, Save, FileText } from 'lucide-react';

export const PurchasesManager: React.FC = () => {
  const { purchases, addPurchase, updatePurchaseStatus } = usePharmacy();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // Form states
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [supplierName, setSupplierName] = useState('');
  const [supplierGstin, setSupplierGstin] = useState('');
  const [supplierContact, setSupplierContact] = useState('');
  const [itemsCount, setItemsCount] = useState(10);
  const [totalAmount, setTotalAmount] = useState<number>(15000);
  const [gstAmount, setGstAmount] = useState<number>(1800);
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Pending' | 'Partial'>('Paid');
  const [dueDate, setDueDate] = useState('');

  const totalPurchasesAmount = purchases.reduce((sum, p) => sum + p.totalAmount, 0);
  const totalPendingAmount = purchases
    .filter(p => p.paymentStatus !== 'Paid')
    .reduce((sum, p) => sum + p.totalAmount, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!invoiceNumber || !supplierName) {
      alert('Invoice number and Supplier name are required!');
      return;
    }

    addPurchase({
      invoiceNumber: invoiceNumber.trim().toUpperCase(),
      date,
      supplierName: supplierName.trim(),
      supplierGstin: supplierGstin.trim().toUpperCase() || '27AAAAA0000A1Z5',
      supplierContact: supplierContact.trim() || '+91 98000 00000',
      itemsCount: Number(itemsCount) || 1,
      totalAmount: Number(totalAmount) || 0,
      gstAmount: Number(gstAmount) || 0,
      paymentStatus,
      dueDate: dueDate || undefined
    });

    setIsAddModalOpen(false);
    // Reset
    setInvoiceNumber('');
    setSupplierName('');
    setSupplierGstin('');
    setSupplierContact('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white">
            Distributor Inward Purchases &amp; Bills
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Log supplier purchase invoices · Track accounts payable · Input tax credit (ITC) records
          </p>
        </div>

        <button
          onClick={() => setIsAddModalOpen(true)}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm transition-colors cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Record Inward Bill</span>
        </button>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-slate-500 uppercase tracking-wider block">
            Total Inward Purchases
          </span>
          <div className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {formatCurrency(totalPurchasesAmount)}
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            Across {purchases.length} distributor invoices
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-amber-700 dark:text-amber-400 uppercase tracking-wider block">
            Outstanding Distributor Payable
          </span>
          <div className="text-xl font-bold font-mono text-amber-700 dark:text-amber-400 mt-1">
            {formatCurrency(totalPendingAmount)}
          </div>
          <span className="text-[11px] text-slate-400">
            Pending supplier clearing
          </span>
        </div>

        <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs font-medium text-emerald-700 dark:text-emerald-400 uppercase tracking-wider block">
            Claimable GST Input (ITC)
          </span>
          <div className="text-xl font-bold font-mono text-emerald-700 dark:text-emerald-400 mt-1">
            {formatCurrency(purchases.reduce((s, p) => s + p.gstAmount, 0))}
          </div>
          <span className="text-[11px] text-slate-400">
            Eligible for GST offset
          </span>
        </div>
      </div>

      {/* Purchases Invoices Table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex justify-between items-center">
          <span className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-emerald-600" /> Distributor Purchase Registers
          </span>
          <span className="text-xs text-slate-500 font-mono">{purchases.length} Bills logged</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse font-mono">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 text-slate-600 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-sans font-semibold">
                <th className="py-3 px-4">Invoice No</th>
                <th className="py-3 px-3">Date</th>
                <th className="py-3 px-3">Distributor / Stockist</th>
                <th className="py-3 px-2">GSTIN</th>
                <th className="py-3 px-2 text-center">Items</th>
                <th className="py-3 px-3 text-right">Tax (GST)</th>
                <th className="py-3 px-3 text-right">Total Bill ₹</th>
                <th className="py-3 px-3 text-center">Payment Status</th>
                <th className="py-3 px-4 text-right font-sans">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {purchases.map(pur => (
                <tr key={pur.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                  <td className="py-3.5 px-4 font-bold text-slate-900 dark:text-white">
                    {pur.invoiceNumber}
                  </td>
                  <td className="py-3.5 px-3 text-slate-500 font-sans">
                    {formatDate(pur.date)}
                  </td>
                  <td className="py-3.5 px-3 font-sans font-semibold text-slate-800 dark:text-slate-200">
                    <div>{pur.supplierName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{pur.supplierContact}</div>
                  </td>
                  <td className="py-3.5 px-2 text-slate-500 text-[11px]">
                    {pur.supplierGstin}
                  </td>
                  <td className="py-3.5 px-2 text-center text-slate-700 dark:text-slate-300">
                    {pur.itemsCount} SKUs
                  </td>
                  <td className="py-3.5 px-3 text-right text-slate-500">
                    ₹{pur.gstAmount.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-3 text-right font-bold text-slate-900 dark:text-white">
                    ₹{pur.totalAmount.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-3 text-center font-sans">
                    <span className={`inline-block text-[11px] font-medium px-2 py-0.5 rounded ${
                      pur.paymentStatus === 'Paid'
                        ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                        : pur.paymentStatus === 'Pending'
                        ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400'
                        : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                    }`}>
                      {pur.paymentStatus}
                    </span>
                    {pur.dueDate && pur.paymentStatus !== 'Paid' && (
                      <div className="text-[10px] text-slate-400 mt-0.5">Due: {formatDate(pur.dueDate)}</div>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-right font-sans">
                    {pur.paymentStatus !== 'Paid' ? (
                      <button
                        onClick={() => updatePurchaseStatus(pur.id, 'Paid')}
                        className="px-2.5 py-1 text-[11px] font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded hover:bg-emerald-100 transition-colors cursor-pointer"
                      >
                        Mark Settled
                      </button>
                    ) : (
                      <span className="text-[11px] text-slate-400 flex items-center justify-end gap-1">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" /> Settled
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record Purchase Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 rounded-xl shadow-2xl border border-slate-200 dark:border-slate-800 w-full max-w-lg overflow-hidden">
            
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Record Inward Distributor Purchase Bill
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-5 space-y-3.5 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Invoice / Bill Number *
                  </label>
                  <input
                    type="text"
                    required
                    value={invoiceNumber}
                    onChange={e => setInvoiceNumber(e.target.value)}
                    placeholder="e.g. APX-9921"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white uppercase"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Invoice Date *
                  </label>
                  <input
                    type="date"
                    required
                    value={date}
                    onChange={e => setDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Supplier / Distributor Name *
                </label>
                <input
                  type="text"
                  required
                  value={supplierName}
                  onChange={e => setSupplierName(e.target.value)}
                  placeholder="e.g. Apex Pharma Distributors, Sun Medico"
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Supplier GSTIN
                  </label>
                  <input
                    type="text"
                    value={supplierGstin}
                    onChange={e => setSupplierGstin(e.target.value)}
                    placeholder="27AAACA9982E1ZX"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white uppercase"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Contact Phone
                  </label>
                  <input
                    type="text"
                    value={supplierContact}
                    onChange={e => setSupplierContact(e.target.value)}
                    placeholder="+91 Phone"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Items Count
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={itemsCount}
                    onChange={e => setItemsCount(parseInt(e.target.value) || 1)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    GST Included ₹
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={gstAmount}
                    onChange={e => setGstAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Total Inward Bill ₹ *
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    required
                    value={totalAmount}
                    onChange={e => setTotalAmount(parseFloat(e.target.value) || 0)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md font-mono font-bold text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Payment Status
                  </label>
                  <select
                    value={paymentStatus}
                    onChange={e => setPaymentStatus(e.target.value as any)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                  >
                    <option value="Paid">Paid in Full</option>
                    <option value="Partial">Partial Paid</option>
                    <option value="Pending">Pending on Credit</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1">
                    Credit Due Date
                  </label>
                  <input
                    type="date"
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-md text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-md shadow-xs flex items-center gap-1.5"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Inward Bill</span>
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
