export type MedicineCategory = 
  | 'Tablets'
  | 'Capsules'
  | 'Syrup & Suspensions'
  | 'Injections & Vials'
  | 'Ointments & Creams'
  | 'Eye & Ear Drops'
  | 'Inhalers & Respules'
  | 'Surgicals & Devices'
  | 'OTC & Health';

export type DrugSchedule = 'OTC' | 'Schedule H' | 'Schedule H1' | 'Schedule X';

export interface MedicineItem {
  id: string;
  name: string;
  generic: string;
  category: MedicineCategory;
  dosage: string;
  manufacturer: string;
  batchNumber: string;
  expiryDate: string; // YYYY-MM
  stockQuantity: number;
  minStockLevel: number;
  unit: 'Strip' | 'Bottle' | 'Vial' | 'Tube' | 'Piece' | 'Pack';
  packSize: string; // e.g., "10 Tabs", "100 ml", "15 gm"
  costPrice: number; // Purchase price ex-GST
  mrp: number;
  salePrice: number;
  gstRate: number; // 0, 5, 12, 18
  hsnCode: string; // e.g. "3004"
  schedule: DrugSchedule;
  shelfLocation: string; // e.g. "Rack A-3", "Fridge"
  supplierName: string;
  barcode?: string;
  requiresPrescription: boolean;
}

export interface InvoiceItem {
  medicineId: string;
  name: string;
  generic: string;
  dosage: string;
  category: MedicineCategory;
  batchNumber: string;
  expiryDate: string;
  quantity: number;
  unit: string;
  packSize: string;
  mrp: number;
  salePrice: number;
  discountPercent: number;
  gstRate: number;
  hsnCode: string;
  schedule: DrugSchedule;
  totalAmount: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string; // ISO string
  customerName: string;
  customerPhone: string;
  customerAge?: string;
  customerGender?: 'Male' | 'Female' | 'Other';
  doctorName?: string;
  doctorRegNo?: string;
  items: InvoiceItem[];
  subtotal: number;
  totalDiscount: number;
  taxableAmount: number;
  totalCgst: number;
  totalSgst: number;
  totalGst: number;
  roundOff: number;
  grandTotal: number;
  paymentMode: 'Cash' | 'UPI' | 'Card' | 'Credit/Khata';
  cashTendered?: number;
  changeDue?: number;
  status: 'Completed' | 'Returned' | 'Draft';
  invoiceType?: 'NON_GST' | 'GST';
  notes?: string;
  pharmacist: string;
}

export interface DistributorPurchase {
  id: string;
  invoiceNumber: string;
  date: string;
  supplierName: string;
  supplierGstin: string;
  supplierContact: string;
  itemsCount: number;
  totalAmount: number;
  gstAmount: number;
  paymentStatus: 'Paid' | 'Pending' | 'Partial';
  dueDate?: string;
}

export interface CustomerKhata {
  id: string;
  name: string;
  phone: string;
  address?: string;
  currentBalance: number; // positive = customer owes store
  creditLimit: number;
  chronicTags?: string[]; // e.g., ["Diabetes Type-2", "Hypertension"]
  lastPurchaseDate: string;
  notes?: string;
  transactions: KhataTransaction[];
}

export interface KhataTransaction {
  id: string;
  date: string;
  type: 'Bill' | 'Payment';
  amount: number;
  referenceId: string; // Invoice number or receipt no
  notes?: string;
}

export interface PharmacyProfile {
  storeName: string;
  tagline: string;
  ownerName: string;
  pharmacistRegNo: string;
  drugLicenseNo: string;
  gstin: string;
  fssai: string;
  addressLine1: string;
  addressLine2: string;
  cityStateZip: string;
  phone: string;
  alternatePhone?: string;
  email: string;
  upiId: string;
  billTerms: string[];
  defaultInvoiceType: 'NON_GST' | 'GST';
  showGstinOnBill: boolean;
}
