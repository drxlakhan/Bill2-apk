import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  MedicineItem,
  Invoice,
  DistributorPurchase,
  CustomerKhata,
  PharmacyProfile,
  InvoiceItem
} from '../types/pharmacy';
import {
  INITIAL_MEDICINES,
  INITIAL_INVOICES,
  INITIAL_PURCHASES,
  INITIAL_KHATA,
  INITIAL_PHARMACY_PROFILE
} from '../data/initialData';

interface PharmacyContextType {
  medicines: MedicineItem[];
  invoices: Invoice[];
  purchases: DistributorPurchase[];
  khataList: CustomerKhata[];
  profile: PharmacyProfile;
  darkMode: boolean;
  toggleDarkMode: () => void;
  // Inventory actions
  addMedicine: (medicine: Omit<MedicineItem, 'id'>) => void;
  updateMedicine: (id: string, updates: Partial<MedicineItem>) => void;
  deleteMedicine: (id: string) => void;
  adjustStock: (id: string, newQty: number, reason: string) => void;
  // Invoice & POS actions
  createInvoice: (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'>) => Invoice;
  returnInvoiceItem: (invoiceId: string, medicineId: string, returnQty: number) => void;
  // Purchases actions
  addPurchase: (purchase: Omit<DistributorPurchase, 'id'>) => void;
  updatePurchaseStatus: (id: string, status: 'Paid' | 'Pending' | 'Partial') => void;
  // Khata actions
  recordKhataPayment: (khataId: string, amount: number, notes: string) => void;
  addKhataCustomer: (customer: Omit<CustomerKhata, 'id' | 'transactions'>) => void;
  // Profile & Backup
  updateProfile: (profile: PharmacyProfile) => void;
  exportDatabaseBackup: () => void;
  importDatabaseBackup: (jsonString: string) => boolean;
  resetToDefaultData: () => void;
  // Metrics & alerts
  lowStockItems: MedicineItem[];
  nearExpiryItems: MedicineItem[];
  expiredItems: MedicineItem[];
  todayRevenue: number;
  todayInvoicesCount: number;
}

const PharmacyContext = createContext<PharmacyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  MEDICINES: 'pk_meds_v1',
  INVOICES: 'pk_invoices_v1',
  PURCHASES: 'pk_purchases_v1',
  KHATA: 'pk_khata_v1',
  PROFILE: 'pk_profile_v1',
  THEME: 'pk_theme_mode'
};

export const PharmacyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [medicines, setMedicines] = useState<MedicineItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.MEDICINES);
      return saved ? JSON.parse(saved) : INITIAL_MEDICINES;
    } catch {
      return INITIAL_MEDICINES;
    }
  });

  const [invoices, setInvoices] = useState<Invoice[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.INVOICES);
      return saved ? JSON.parse(saved) : INITIAL_INVOICES;
    } catch {
      return INITIAL_INVOICES;
    }
  });

  const [purchases, setPurchases] = useState<DistributorPurchase[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PURCHASES);
      return saved ? JSON.parse(saved) : INITIAL_PURCHASES;
    } catch {
      return INITIAL_PURCHASES;
    }
  });

  const [khataList, setKhataList] = useState<CustomerKhata[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.KHATA);
      return saved ? JSON.parse(saved) : INITIAL_KHATA;
    } catch {
      return INITIAL_KHATA;
    }
  });

  const [profile, setProfile] = useState<PharmacyProfile>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.PROFILE);
      return saved ? JSON.parse(saved) : INITIAL_PHARMACY_PROFILE;
    } catch {
      return INITIAL_PHARMACY_PROFILE;
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.THEME);
      return saved ? saved === 'dark' : false;
    } catch {
      return false;
    }
  });

  // Keep dark class synced on <html>
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem(STORAGE_KEYS.THEME, 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem(STORAGE_KEYS.THEME, 'light');
    }
  }, [darkMode]);

  const toggleDarkMode = () => setDarkMode(prev => !prev);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.MEDICINES, JSON.stringify(medicines));
  }, [medicines]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.INVOICES, JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PURCHASES, JSON.stringify(purchases));
  }, [purchases]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.KHATA, JSON.stringify(khataList));
  }, [khataList]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
  }, [profile]);

  // Inventory actions
  const addMedicine = (med: Omit<MedicineItem, 'id'>) => {
    const newMed: MedicineItem = {
      ...med,
      id: `med-${Date.now()}`
    };
    setMedicines(prev => [newMed, ...prev]);
  };

  const updateMedicine = (id: string, updates: Partial<MedicineItem>) => {
    setMedicines(prev =>
      prev.map(item => (item.id === id ? { ...item, ...updates } : item))
    );
  };

  const deleteMedicine = (id: string) => {
    setMedicines(prev => prev.filter(item => item.id !== id));
  };

  const adjustStock = (id: string, newQty: number, reason: string) => {
    setMedicines(prev =>
      prev.map(item => (item.id === id ? { ...item, stockQuantity: Math.max(0, newQty) } : item))
    );
    // Optionally log adjustment
    console.info(`Stock adjusted for ${id} to ${newQty}. Reason: ${reason}`);
  };

  // Billing & Invoice actions
  const createInvoice = (invoiceData: Omit<Invoice, 'id' | 'invoiceNumber'>): Invoice => {
    const nextInvoiceSeq = invoices.length + 1001;
    const invNo = `INV-2026-${nextInvoiceSeq}`;
    const newInvoice: Invoice = {
      ...invoiceData,
      id: `inv-${Date.now()}`,
      invoiceNumber: invNo
    };

    // Decrement stock for billed items
    setMedicines(prev => {
      const stockMap = new Map<string, number>();
      invoiceData.items.forEach(item => {
        const cur = stockMap.get(item.medicineId) || 0;
        stockMap.set(item.medicineId, cur + item.quantity);
      });

      return prev.map(med => {
        const qtyToDeduct = stockMap.get(med.id);
        if (qtyToDeduct) {
          return {
            ...med,
            stockQuantity: Math.max(0, med.stockQuantity - qtyToDeduct)
          };
        }
        return med;
      });
    });

    // If Khata payment mode, record to customer ledger
    if (invoiceData.paymentMode === 'Credit/Khata') {
      setKhataList(prev => {
        const existing = prev.find(k => k.phone === invoiceData.customerPhone || k.name.toLowerCase() === invoiceData.customerName.toLowerCase());
        const tx = {
          id: `tx-${Date.now()}`,
          date: new Date().toISOString().slice(0, 10),
          type: 'Bill' as const,
          amount: invoiceData.grandTotal,
          referenceId: invNo,
          notes: `Billed items (${invoiceData.items.length})`
        };

        if (existing) {
          return prev.map(k =>
            k.id === existing.id
              ? {
                  ...k,
                  currentBalance: k.currentBalance + invoiceData.grandTotal,
                  lastPurchaseDate: new Date().toISOString().slice(0, 10),
                  transactions: [tx, ...k.transactions]
                }
              : k
          );
        } else {
          const newKhata: CustomerKhata = {
            id: `khata-${Date.now()}`,
            name: invoiceData.customerName,
            phone: invoiceData.customerPhone,
            currentBalance: invoiceData.grandTotal,
            creditLimit: 5000,
            lastPurchaseDate: new Date().toISOString().slice(0, 10),
            transactions: [tx]
          };
          return [newKhata, ...prev];
        }
      });
    }

    setInvoices(prev => [newInvoice, ...prev]);
    return newInvoice;
  };

  const returnInvoiceItem = (invoiceId: string, medicineId: string, returnQty: number) => {
    // Restock returned medicine
    setMedicines(prev =>
      prev.map(med => (med.id === medicineId ? { ...med, stockQuantity: med.stockQuantity + returnQty } : med))
    );

    // Update invoice note
    setInvoices(prev =>
      prev.map(inv => {
        if (inv.id === invoiceId) {
          return {
            ...inv,
            notes: (inv.notes ? inv.notes + '; ' : '') + `Returned ${returnQty} qty on ${new Date().toLocaleDateString()}`
          };
        }
        return inv;
      })
    );
  };

  // Purchases
  const addPurchase = (purchase: Omit<DistributorPurchase, 'id'>) => {
    const newPur: DistributorPurchase = {
      ...purchase,
      id: `pur-${Date.now()}`
    };
    setPurchases(prev => [newPur, ...prev]);
  };

  const updatePurchaseStatus = (id: string, status: 'Paid' | 'Pending' | 'Partial') => {
    setPurchases(prev =>
      prev.map(p => (p.id === id ? { ...p, paymentStatus: status } : p))
    );
  };

  // Khata
  const recordKhataPayment = (khataId: string, amount: number, notes: string) => {
    setKhataList(prev =>
      prev.map(k => {
        if (k.id === khataId) {
          const newBal = Math.max(0, k.currentBalance - amount);
          const tx = {
            id: `tx-${Date.now()}`,
            date: new Date().toISOString().slice(0, 10),
            type: 'Payment' as const,
            amount: amount,
            referenceId: `REC-${Date.now().toString().slice(-4)}`,
            notes: notes || 'Cash/UPI settlement'
          };
          return {
            ...k,
            currentBalance: newBal,
            transactions: [tx, ...k.transactions]
          };
        }
        return k;
      })
    );
  };

  const addKhataCustomer = (customer: Omit<CustomerKhata, 'id' | 'transactions'>) => {
    const newCustomer: CustomerKhata = {
      ...customer,
      id: `khata-${Date.now()}`,
      transactions: []
    };
    setKhataList(prev => [newCustomer, ...prev]);
  };

  // Profile & Backup
  const updateProfile = (newProfile: PharmacyProfile) => {
    setProfile(newProfile);
  };

  const exportDatabaseBackup = () => {
    const backupData = {
      version: '1.0',
      exportedAt: new Date().toISOString(),
      storeProfile: profile,
      medicines,
      invoices,
      purchases,
      khataList
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pharmakare_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const importDatabaseBackup = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.medicines && Array.isArray(data.medicines)) {
        setMedicines(data.medicines);
      }
      if (data.invoices && Array.isArray(data.invoices)) {
        setInvoices(data.invoices);
      }
      if (data.purchases && Array.isArray(data.purchases)) {
        setPurchases(data.purchases);
      }
      if (data.khataList && Array.isArray(data.khataList)) {
        setKhataList(data.khataList);
      }
      if (data.storeProfile) {
        setProfile(data.storeProfile);
      }
      return true;
    } catch (e) {
      console.error('Failed to import backup:', e);
      return false;
    }
  };

  const resetToDefaultData = () => {
    setMedicines(INITIAL_MEDICINES);
    setInvoices(INITIAL_INVOICES);
    setPurchases(INITIAL_PURCHASES);
    setKhataList(INITIAL_KHATA);
    setProfile(INITIAL_PHARMACY_PROFILE);
    localStorage.clear();
  };

  // Computed alert items
  const lowStockItems = medicines.filter(m => m.stockQuantity <= m.minStockLevel);

  const now = new Date();
  const nearExpiryItems = medicines.filter(m => {
    if (!m.expiryDate) return false;
    const parts = m.expiryDate.split('-');
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const lastDay = new Date(year, month, 0);
    const diffDays = Math.ceil((lastDay.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return diffDays > 0 && diffDays <= 90;
  });

  const expiredItems = medicines.filter(m => {
    if (!m.expiryDate) return false;
    const parts = m.expiryDate.split('-');
    const year = parseInt(parts[0], 10);
    const month = parseInt(parts[1], 10);
    const lastDay = new Date(year, month, 0);
    return lastDay.getTime() <= now.getTime();
  });

  // Today metrics
  const todayDateStr = new Date().toISOString().slice(0, 10);
  const todayInvoices = invoices.filter(inv => inv.date.startsWith(todayDateStr));
  const todayRevenue = todayInvoices.reduce((sum, inv) => sum + inv.grandTotal, 0);
  const todayInvoicesCount = todayInvoices.length;

  return (
    <PharmacyContext.Provider
      value={{
        medicines,
        invoices,
        purchases,
        khataList,
        profile,
        darkMode,
        toggleDarkMode,
        addMedicine,
        updateMedicine,
        deleteMedicine,
        adjustStock,
        createInvoice,
        returnInvoiceItem,
        addPurchase,
        updatePurchaseStatus,
        recordKhataPayment,
        addKhataCustomer,
        updateProfile,
        exportDatabaseBackup,
        importDatabaseBackup,
        resetToDefaultData,
        lowStockItems,
        nearExpiryItems,
        expiredItems,
        todayRevenue,
        todayInvoicesCount
      }}
    >
      {children}
    </PharmacyContext.Provider>
  );
};

export const usePharmacy = () => {
  const context = useContext(PharmacyContext);
  if (!context) {
    throw new Error('usePharmacy must be used within a PharmacyProvider');
  }
  return context;
};
